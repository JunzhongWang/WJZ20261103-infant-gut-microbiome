#!/usr/bin/env python3
"""Fetch curatedMetagenomicData abundance tables straight from ExperimentHub.

    python3 pipeline/fetch_cmd3_direct.py --study VatanenT_2016 ShaoY_2019

No R package installation, no ExperimentHub client, no Bioconductor. The chain
is three HTTP requests plus one base-R call:

  1. download the hub catalogue (experimenthub.sqlite3, ~10 MB, resumable)
  2. SQL: newest resource whose title matches <study>.relative_abundance
         -> location_prefix + rdatapath  (a plain object-storage URL)
  3. download that .rda (resumable; single big responses get truncated here,
     so this retries with HTTP range resume until the size matches)
  4. Rscript pipeline/rda_extract.R  -> species.tsv + pheno.tsv

Runs are idempotent: files are cached under data/cache/.
"""
import argparse
import os
import re
import sqlite3
import subprocess
import sys
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "data", "cache")
HUB = "https://experimenthub.bioconductor.org"
HUB_DB = f"{HUB}/metadata/experimenthub.sqlite3"


def fetch_resumable(url, dest, tries=40):
    """Download with HTTP Range resume.

    A single response from this sandbox gets cut off well before the declared
    Content-Length, so we keep asking for the remainder and stop only when the
    byte count matches what the server advertised.
    """
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req, timeout=60) as r:
        total = int(r.headers.get("Content-Length", 0))
    if os.path.exists(dest) and total and os.path.getsize(dest) == total:
        return dest, total
    for _ in range(tries):
        have = os.path.getsize(dest) if os.path.exists(dest) else 0
        if total and have >= total:
            return dest, total
        cmd = ["curl", "-sL", "--max-time", "120", "-C", "-", url, "-o", dest]
        subprocess.run(cmd, capture_output=True)
        now = os.path.getsize(dest) if os.path.exists(dest) else 0
        if now <= have:
            break
    size = os.path.getsize(dest) if os.path.exists(dest) else 0
    if total and size != total:
        raise RuntimeError(f"incomplete: {size}/{total} bytes for {url}")
    return dest, size


def ensure_hub():
    dest = os.path.join(CACHE, "experimenthub.sqlite3")
    fetch_resumable(HUB_DB, dest)
    con = sqlite3.connect(dest)
    n = con.execute("SELECT COUNT(*) FROM resources").fetchone()[0]
    print(f"hub catalogue: {n} resources")
    return con


def newest_resource(con, study, pattern="relative_abundance"):
    q = """
    SELECT r.title, p.rdatapath, lp.location_prefix
      FROM resources r
      JOIN rdatapaths p       ON p.resource_id = r.id
      JOIN location_prefixes lp ON lp.id = r.location_prefix_id
     WHERE r.title LIKE ? AND r.title LIKE ?
    """
    rows = con.execute(q, (f"%{study}.{pattern}%", f"%{study}%")).fetchall()
    if not rows:
        return None
    # newest date prefix wins
    def datekey(row):
        m = re.match(r"(\d{4})-?(\d{2})-?(\d{2})", row[0])
        return m.groups() if m else ("0", "0", "0")
    rows.sort(key=datekey, reverse=True)
    return rows[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--study", nargs="+", required=True)
    ap.add_argument("--pattern", default="relative_abundance")
    ap.add_argument("--infants-only", action="store_true", default=True)
    ap.add_argument("--all-ages", dest="infants_only", action="store_false")
    args = ap.parse_args()

    con = ensure_hub()
    for study in args.study:
        hit = newest_resource(con, study, args.pattern)
        if hit is None:
            print(f"{study}: no '{args.pattern}' resource in the hub")
            continue
        title, rdatapath, prefix = hit
        url = prefix.rstrip("/") + "/" + rdatapath.lstrip("/")
        print(f"\n{study}\n  title: {title}\n  url:   {url}")
        rda = os.path.join(CACHE, f"{study}.{args.pattern}.rda")
        try:
            _, size = fetch_resumable(url, rda)
        except RuntimeError as exc:
            print(f"  download failed: {exc}")
            continue
        print(f"  downloaded {size/1e6:.2f} MB")

        outdir = os.path.join(ROOT, "data", study)
        r = subprocess.run(["Rscript", os.path.join(ROOT, "pipeline", "rda_extract.R"),
                            rda, outdir, study], capture_output=True, text=True)
        sys.stdout.write("  " + (r.stdout.strip() or r.stderr.strip()[:300]) + "\n")
        if r.returncode != 0:
            continue
        build_pipeline_tables(outdir, study, args.infants_only)


def build_pipeline_tables(outdir, study, infants_only):
    """pheno.tsv + species.tsv -> meta.csv + species.csv (pipeline format).

    Newer cMD3 resources ship as a bare matrix, so the sample table is taken
    from the curator's sampleMetadata export instead when pheno.tsv is absent.
    """
    import csv
    ph = {}
    ph_path = os.path.join(outdir, "pheno.tsv")
    if os.path.exists(ph_path):
        with open(ph_path, newline="") as f:
            for r in csv.DictReader(f, delimiter="\t"):
                ph[r["sample_id"]] = r
    else:
        meta_csv = os.path.join(CACHE, "sample_metadata.csv")
        if not os.path.exists(meta_csv):
            raise SystemExit("missing sample metadata; run the sampleMetadata export")
        with open(meta_csv, newline="") as f:
            for r in csv.DictReader(f):
                if r["study_name"] != study:
                    continue
                r["abx_raw"] = r.get("antibiotics_current_use")
                r["days"] = r.get("days_from_first_collection")
                ph[r["sample_id"]] = r

    with open(os.path.join(outdir, "species.tsv"), newline="") as f:
        rd = list(csv.reader(f, delimiter="\t"))
    header, rows = rd[0], [r for r in rd[1:] if r and r[0]]

    def keep(r):
        p = ph.get(r[0])
        if not p:
            return False
        if p.get("body_site") not in ("stool", "", None):
            return False
        if infants_only:
            cat = (p.get("age_category") or "").lower()
            age = p.get("age")
            try:
                a = float(age) if age not in ("NA", "", None) else None
            except ValueError:
                a = None
            if not (cat == "newborn" or (a is not None and a < 2)):
                return False
        days = p.get("days")
        return days not in ("NA", "", None)

    rows = [r for r in rows if keep(r)]
    with open(os.path.join(outdir, "species.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)
    with open(os.path.join(outdir, "meta.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["sample_id", "subject_id", "study", "days", "abx"])
        for r in rows:
            p = ph[r[0]]
            abx = 1 if str(p.get("abx_raw", "")).strip().lower() in ("true", "yes", "1") else 0
            w.writerow([r[0], f"{study}::{p['subject_id']}", study, p["days"], abx])

    subj = {}
    for r in rows:
        subj.setdefault(ph[r[0]]["subject_id"], 0)
        subj[ph[r[0]]["subject_id"]] += 1
    print(f"  -> {len(rows)} samples, {len(subj)} subjects, "
          f"{sum(1 for v in subj.values() if v >= 2)} with >=2 visits")


if __name__ == "__main__":
    main()
