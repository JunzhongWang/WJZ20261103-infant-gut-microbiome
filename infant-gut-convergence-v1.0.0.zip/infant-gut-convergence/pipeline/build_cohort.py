#!/usr/bin/env python3
"""Build the analysis tables for one cohort from the extracted leaf table.

    python3 pipeline/build_cohort.py --study VatanenT_2016 ShaoY_2019

Inputs (written by rda_extract.R + fetch_cmd3_direct.py)
    data/<study>/species.tsv   samples x leaf taxa, percent, rows sum to 100
    data/cache/sample_metadata.csv

Outputs
    data/<study>/community.csv  samples x taxa, proportions (rows sum to 1)
    data/<study>/meta.csv       sample_id,subject_id,study,days,abx,dffc,condition,country

Age axis. `days_from_first_collection` is time since that subject's first
sample, not age: in VatanenT_2016 it sits a median of 139 days away from the
true age. cMD3's `infant_age` is the age at sampling in days, and that is what
`days` holds here. The offset between the two is a per-subject constant
(see rebuild_meta.py / the manuscript) and is kept in `dffc` for sensitivity
analyses only.
"""
import argparse
import csv
import os
import statistics
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "data", "cache", "sample_metadata.csv")
MAX_AGE = 1095.0          # 3 years; the infant/early-childhood window


def num(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return None if v != v else v


def anchor_ages(meta, study):
    """Recover missing `infant_age` from the per-subject sampling offset.

    For every subject the gap between age and time-since-first-sample is a
    constant k = infant_age - days_from_first_collection, because both clocks
    start at birth. Samples that lack `infant_age` but carry
    `days_from_first_collection` therefore have age = dffc + k. Leave-one-out
    over the samples that do have both fields reproduces the held-out age
    exactly (median absolute error 0 d), which is what licenses the recovery.
    Returns (offsets, n_recovered, loo_mae).
    """
    by = {}
    for r in meta.values():
        if r.get("study_name") != study:
            continue
        a = num(r.get("infant_age"))
        d = num(r.get("days_from_first_collection"))
        if a is not None and d is not None:
            by.setdefault(r["subject_id"], []).append(a - d)
    offsets = {s: statistics.median(v) for s, v in by.items()}

    err = []
    for s, v in by.items():
        if len(v) >= 2:
            for i in range(len(v)):
                rest = [x for j, x in enumerate(v) if j != i]
                err.append(abs(v[i] - statistics.median(rest)))
    loo = statistics.median(err) if err else 0.0

    n = 0
    for r in meta.values():
        if r.get("study_name") != study:
            continue
        if num(r.get("infant_age")) is not None:
            continue
        d = num(r.get("days_from_first_collection"))
        if d is not None and r["subject_id"] in offsets:
            n += 1
    return offsets, n, loo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--study", nargs="+", required=True)
    ap.add_argument("--no-anchor", action="store_true",
                    help="do not reconstruct ages from the per-subject offset")
    args = ap.parse_args()

    meta = {}
    with open(CACHE, newline="") as f:
        for r in csv.DictReader(f):
            meta[r["sample_id"]] = r

    for study in args.study:
        d = os.path.join(ROOT, "data", study)
        with open(os.path.join(d, "species.tsv"), newline="") as f:
            rd = list(csv.reader(f, delimiter="\t"))
        header, rows = rd[0], [r for r in rd[1:] if r and r[0]]
        taxa = header[1:]

        offsets, n_recover, loo = anchor_ages(meta, study)
        recovered = 0
        kept, drop = [], {"no_meta": 0, "body": 0, "age": 0, "old": 0}
        for r in rows:
            m = meta.get(r[0])
            if m is None:
                drop["no_meta"] += 1
                continue
            if (m.get("body_site") or "stool") not in ("stool", ""):
                drop["body"] += 1
                continue
            a = num(m.get("infant_age"))
            if a is None and not args.no_anchor:
                dfc = num(m.get("days_from_first_collection"))
                if dfc is not None and m["subject_id"] in offsets:
                    a = dfc + offsets[m["subject_id"]]
                    recovered += 1
            if a is None:
                drop["age"] += 1
                continue
            if a < 0 or a > MAX_AGE:
                drop["old"] += 1
                continue
            kept.append((r, m, a))

        if not kept:
            print(f"{study}: nothing usable (drops: {drop})", file=sys.stderr)
            continue

        # taxa with zero variance carry no distance information; drop all-zero
        n = len(kept)
        sums = [0.0] * len(taxa)
        for r, _, _ in kept:
            for j, v in enumerate(r[1:]):
                sums[j] += float(v)
        keep_taxa = [j for j in range(len(taxa)) if sums[j] > 0]

        with open(os.path.join(d, "community.csv"), "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["sample_id"] + [taxa[j] for j in keep_taxa])
            for r, _, _ in kept:
                vals = [float(r[1 + j]) for j in keep_taxa]
                tot = sum(vals) or 1.0
                w.writerow([r[0]] + [f"{v / tot:.6g}" for v in vals])

        with open(os.path.join(d, "meta.csv"), "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["sample_id", "subject_id", "study", "days", "abx",
                        "dffc", "condition", "country"])
            for r, m, a in kept:
                abx = 1 if str(m.get("antibiotics_current_use", "")).strip().lower() \
                    in ("true", "yes", "1") else 0
                w.writerow([r[0], f"{study}::{m['subject_id']}", study, f"{a:.0f}", abx,
                            m.get("days_from_first_collection", ""),
                            m.get("study_condition", ""), m.get("country", "")])

        by = {}
        for _, m, a in kept:
            by.setdefault(m["subject_id"], []).append(a)
        spans = [max(v) - min(v) for v in by.values() if len(v) > 1]
        visits = [len(v) for v in by.values()]
        print(f"{study:<16} {n:4d} samples {len(by):4d} subjects "
              f"taxa={len(keep_taxa):4d} visits med={statistics.median(visits):4.0f} "
              f"max={max(visits):3d} span med={statistics.median(spans) if spans else 0:5.0f}d "
              f"age {min(a for _, _, a in kept):.0f}-{max(a for _, _, a in kept):.0f}d "
              f"| anchored +{recovered} (LOO {loo:.0f}d) | dropped {drop}")


if __name__ == "__main__":
    main()
