#!/usr/bin/env python3
"""Functional-level robustness of R: pathway (HUMAnN) instead of species.

Repeats the matched-strata analysis on cMD3 pathway_abundance profiles
(2021-03-31 resources): R(age, dt) with the same age x interval edges, the
same minimum-count rule (12 within / 60 between pairs) and the same cluster
bootstrap over infants.  Pathways are compositional too, so rows are
normalised to sum 1 and Bray-Curtis is computed on the sparse vectors
(Bray = 1 - 2*sum(min) when both rows sum to 1).

    python3 pipeline/functional_R.py --boot 500

Outputs
    results/real/functional_R.json   cells with CI + band-level comparison
    results/real/figS1_functional.svg/.png
"""
import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decay_model import load, bray, STUDIES  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AGE_EDGES = [(0, 30), (30, 90), (90, 180), (180, 365), (365, 800), (800, 1e9)]
DT_EDGES = [(1, 7), (7, 14), (14, 30), (30, 60), (60, 120), (120, 240),
            (240, 500), (500, 1e9)]
BAND_BINS = [(1, 14), (14, 60), (60, 1e9)]
MIN_W, MIN_B = 12, 60
N_BETWEEN_DRAWS = 60000


def band(x, edges):
    for lo, hi in edges:
        if lo <= x < hi:
            return (lo, hi)
    return None


def load_pathway(study):
    """Sparse pathway profiles restricted to the anchored infant sample set."""
    d = os.path.join(ROOT, "data", study)
    meta = {}
    with open(os.path.join(d, "meta.csv"), newline="") as f:
        for r in csv.DictReader(f):
            meta[r["sample_id"]] = r
    rel, age, subj = [], [], []
    with open(os.path.join(d, "pathway.tsv"), newline="") as f:
        rd = csv.reader(f, delimiter="\t")
        header = next(rd)
        names = header[1:]
        for row in rd:
            m = meta.get(row[0])
            if not m:
                continue
            try:
                a = float(m["days"])
            except (KeyError, TypeError, ValueError):
                continue
            vec = {}
            tot = 0.0
            for k, v in enumerate(row[1:], start=0):
                try:
                    x = float(v)
                except ValueError:
                    x = 0.0
                if x > 0 and not names[k].startswith("UN"):
                    # drop UNMAPPED / UNINTEGRATED catch-alls: near-constant
                    # rows that would dilute distances like the nested-taxa
                    # rows do in the species table
                    vec[names[k]] = x
                    tot += x
            if tot <= 0:
                continue
            for k in vec:
                vec[k] /= tot
            rel.append(vec)
            age.append(a)
            subj.append(m["subject_id"])
    return rel, age, subj


def bray_sparse(p, q):
    """Bray-Curtis on rows normalised to sum 1: D = 1 - sum(min(x, y))."""
    if len(p) > len(q):
        p, q = q, p
    s = 0.0
    for k, v in p.items():
        w = q.get(k)
        if w is not None:
            s += v if v < w else w
    return 1.0 - s


def collect(study, loader, dist, min_dt=1, seed0=31):
    rel, age, subj = loader(study)
    by = {}
    for i, s in enumerate(subj):
        by.setdefault(s, []).append(i)
    si = STUDIES.index(study)
    within = []
    for s, ii in by.items():
        ii = sorted(ii, key=lambda k: age[k])
        for a in range(len(ii)):
            for b in range(a + 1, len(ii)):
                i, j = ii[a], ii[b]
                dt = age[j] - age[i]
                if dt < min_dt:
                    continue
                ab, db = band(age[j], AGE_EDGES), band(dt, DT_EDGES)
                if ab is None or db is None:
                    continue
                d = dist(rel[i], rel[j])
                if d <= 0:
                    continue
                within.append(((ab, db), s, math.log(d)))
    rng = random.Random(seed0 + si)
    keys = list(by)
    between = []
    for _ in range(N_BETWEEN_DRAWS):
        s1, s2 = rng.sample(keys, 2)
        i, j = rng.choice(by[s1]), rng.choice(by[s2])
        if age[i] > age[j]:
            i, j = j, i
        dt = age[j] - age[i]
        if dt < min_dt:
            continue
        ab, db = band(age[j], AGE_EDGES), band(dt, DT_EDGES)
        if ab is None or db is None:
            continue
        d = dist(rel[i], rel[j])
        if d <= 0:
            continue
        between.append(((ab, db), s1, s2, math.log(d)))
    return within, between, {"n_samples": len(age), "n_subjects": len(by)}


def band_R(within, between, bins):
    """R with ages pooled, per interval bin. Bins are unions of DT_EDGES
    bands, so each bin aggregates the log distances of all dt bands fully
    contained in it (open-ended bins take the open-ended dt bands)."""
    accw, accb = {}, {}
    for cell, s, y in within:
        accw.setdefault(cell[1], []).append(y)
    for cell, s1, s2, y in between:
        accb.setdefault(cell[1], []).append(y)

    def inside(dlo, dhi, lo, hi):
        if dlo < lo:
            return False
        if hi < 1e8:
            return dhi <= hi
        return dhi >= 1e8

    out = []
    for lo, hi in bins:
        w, b = [], []
        for (dlo, dhi), ys in accw.items():
            if inside(dlo, dhi, lo, hi):
                w += ys
        for (dlo, dhi), ys in accb.items():
            if inside(dlo, dhi, lo, hi):
                b += ys
        if len(w) >= 15 and len(b) >= 100:
            out.append({"dt_lo": lo, "dt_hi": None if hi >= 1e8 else hi,
                        "n_within": len(w), "n_between": len(b),
                        "within": math.exp(statistics.fmean(w)),
                        "between": math.exp(statistics.fmean(b)),
                        "R": math.exp(statistics.fmean(b) - statistics.fmean(w))})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--boot", type=int, default=500)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    func_within, func_between, info = [], [], {}
    for study in STUDIES:
        w, b, inf = collect(study, load_pathway, bray_sparse)
        func_within += w
        func_between += b
        info[study] = inf
        print(f"  {study:<16} {len(w):5d} within {len(b):6d} between (pathway)",
              flush=True)

    # ---- matched-strata cells with cluster bootstrap
    cells_set = sorted({r[0] for r in func_within} & {r[0] for r in func_between})
    W_by, B_by = {}, {}
    for cell, s, y in func_within:
        W_by.setdefault(cell, []).append(y)
    for cell, a, b, y in func_between:
        B_by.setdefault(cell, []).append(y)
    rows = []
    for cell in cells_set:
        w, b = W_by[cell], B_by[cell]
        if len(w) < MIN_W or len(b) < MIN_B:
            continue
        rows.append({"age_lo": cell[0][0], "age_hi": cell[0][1],
                     "dt_lo": cell[1][0], "dt_hi": cell[1][1],
                     "n_within": len(w), "n_between": len(b),
                     "log_ratio": statistics.fmean(b) - statistics.fmean(w),
                     "ratio": math.exp(statistics.fmean(b) - statistics.fmean(w)),
                     "within": math.exp(statistics.fmean(w)),
                     "between": math.exp(statistics.fmean(b))})

    subs = list(dict.fromkeys([s for cell, s, _ in func_within] +
                              [x for cell, a, b, _ in func_between for x in (a, b)]))
    pos = {s: i for i, s in enumerate(subs)}
    k = len(subs)
    Wrec = [(cell, (pos[s],), y) for cell, s, y in func_within]
    Brec = [(cell, (pos[a], pos[b]), y) for cell, a, b, y in func_between]

    def estimate(mult):
        sw, nw, sb, nb = {}, {}, {}, {}
        for cell, (i,), y in Wrec:
            m = mult[i]
            if m:
                sw[cell] = sw.get(cell, 0.0) + m * y
                nw[cell] = nw.get(cell, 0) + m
        for cell, (i, j), y in Brec:
            m = mult[i] * mult[j]
            if m:
                sb[cell] = sb.get(cell, 0.0) + m * y
                nb[cell] = nb.get(cell, 0) + m
        out = {}
        for cell in cells_set:
            if nw.get(cell, 0) >= MIN_W and nb.get(cell, 0) >= MIN_B:
                out[cell] = (sb[cell] / nb[cell] - sw[cell] / nw[cell],)
        return out

    point = estimate([1] * k)
    rng = random.Random(20260211)
    boots = []
    for it in range(args.boot):
        m = [0] * k
        for _ in range(k):
            m[rng.randrange(k)] += 1
        boots.append(estimate(m))
        if (it + 1) % 100 == 0:
            print(f"  bootstrap {it + 1}/{args.boot}", flush=True)

    for r in rows:
        cell = ((r["age_lo"], r["age_hi"]), (r["dt_lo"], r["dt_hi"]))
        lr = [b[cell][0] for b in boots if cell in b]
        if len(lr) > 20:
            q = statistics.quantiles(lr, n=40)
            r["lo"] = math.exp(q[0])
            r["hi"] = math.exp(q[-1])
        else:
            r["lo"] = r["hi"] = None

    # ---- band-level functional vs taxonomic comparison
    print("band-level taxonomic ...", flush=True)
    tax_within, tax_between = [], []
    for study in STUDIES:
        w, b, _ = collect(study, load, bray)
        tax_within += w
        tax_between += b
    func_bands = band_R(func_within, func_between, BAND_BINS)
    tax_bands = band_R(tax_within, tax_between, BAND_BINS)

    out = {"cohorts": info, "cells": rows, "n_subjects": k,
           "n_boot": args.boot, "func_bands": func_bands, "tax_bands": tax_bands}
    with open(os.path.join(args.out_dir, "functional_R.json"), "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    print("\nFunctional R (pathway, Bray-Curtis), matched on age and interval")
    for r in rows:
        ci = f"[{r['lo']:.2f}, {r['hi']:.2f}]" if r["lo"] else "--"
        print(f"  {r['age_lo']:>4.0f}-{r['age_hi']:<6.0f} "
              f"{r['dt_lo']:>5.0f}-{r['dt_hi']:<6.0f} "
              f"{r['n_within']:>5d} {r['n_between']:>7d} "
              f"R={r['ratio']:>5.2f}  {ci}")
    print("\nBand-level: interval   functional R   taxonomic R")
    fb = {b["dt_lo"]: b for b in func_bands}
    tb = {b["dt_lo"]: b for b in tax_bands}
    for lo in sorted(set(fb) & set(tb)):
        print(f"  {lo:>5}-{fb[lo]['dt_hi'] or 'open':<5} "
              f"{fb[lo]['R']:>12.2f}   {tb[lo]['R']:>11.2f}")
    print(f"\nwrote {args.out_dir}/functional_R.json")


if __name__ == "__main__":
    main()
