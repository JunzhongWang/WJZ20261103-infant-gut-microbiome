#!/usr/bin/env python3
"""Design-based identification of the age and interval effects.

The pair-level regression in decay_model.py has to separate two predictors that
are almost collinear: inside any one cohort the gap between two samples is
bounded by the age of the older sample, so `log(age)` and `log(dt)` move
together (r = 0.93 for within-subject pairs). Pooling cohorts with different
visit schedules helps, but the estimate still leans on the model.

Dense cohorts allow a design-based check that needs no extrapolation. If a
subject is sampled every few days, the same later age is observed at many
intervals, so the interval slope can be read off *within* a narrow age stratum.
Symmetrically, within a stratum of fixed interval one can read the age slope
across subjects.

    python3 pipeline/identify.py --out-dir results/real

Outputs
    identify.json   per-cohort and pooled stratified slopes
    identify.csv    long form for plotting
"""
import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decay_model import load, bray, STUDIES, DENSE  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AGE_EDGES = [(0, 14), (14, 30), (30, 60), (60, 90), (90, 180), (180, 365), (365, 1e9)]
DT_EDGES = [(1, 4), (4, 8), (8, 16), (16, 32), (32, 64), (64, 1e9)]
MIN_CELL = 25


def slope(rows):
    """OLS slope of y on x with intercept; rows = [(y, x)]."""
    n = len(rows)
    if n < 3:
        return None
    mx = statistics.fmean(r[1] for r in rows)
    my = statistics.fmean(r[0] for r in rows)
    sxx = sum((r[1] - mx) ** 2 for r in rows)
    if sxx <= 1e-12:
        return None
    sxy = sum((r[1] - mx) * (r[0] - my) for r in rows)
    return sxy / sxx


def stratum_slope(rows, xkey, ykey="y"):
    return slope([(r[ykey], r[xkey]) for r in rows])


def within_pairs(rel, age, subj, rng, min_dt=1):
    by = {}
    for i, s in enumerate(subj):
        by.setdefault(s, []).append(i)
    out = []
    for s, ii in by.items():
        ii = sorted(ii, key=lambda k: age[k])
        for a in range(len(ii)):
            for b in range(a + 1, len(ii)):
                i, j = ii[a], ii[b]
                dt = age[j] - age[i]
                if dt < min_dt:
                    continue
                d = bray(rel[i], rel[j])
                if d <= 0:
                    continue
                out.append({"y": math.log(d), "age": math.log(max(age[j], 1.0)),
                            "dt": math.log(dt), "dt_raw": dt, "age_raw": age[j],
                            "subject": s})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", default=STUDIES)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    per_cohort, pooled_rows, rows_csv = {}, [], []
    for study in args.studies:
        rel, age, subj = load(study)
        rng = random.Random(11)
        P = within_pairs(rel, age, subj, rng)
        pooled_rows.extend([dict(r, study=study) for r in P])

        # --- interval slope at (approximately) fixed age -------------------
        by_age = {}
        for r in P:
            for lo, hi in AGE_EDGES:
                if lo <= r["age_raw"] < hi:
                    by_age.setdefault((lo, hi), []).append(r)
                    break
        a_strata = []
        for (lo, hi), rs in sorted(by_age.items()):
            sl = stratum_slope(rs, "dt")
            if sl is None or len(rs) < MIN_CELL:
                continue
            a_strata.append({"lo": lo, "hi": hi, "slope_dt": sl, "n": len(rs),
                             "dt_med": statistics.median(x["dt_raw"] for x in rs)})

        # --- age slope at (approximately) fixed interval -------------------
        by_dt = {}
        for r in P:
            for lo, hi in DT_EDGES:
                if lo <= r["dt_raw"] < hi:
                    by_dt.setdefault((lo, hi), []).append(r)
                    break
        d_strata = []
        for (lo, hi), rs in sorted(by_dt.items()):
            sl = stratum_slope(rs, "age")
            if sl is None or len(rs) < MIN_CELL:
                continue
            d_strata.append({"lo": lo, "hi": hi, "slope_age": sl, "n": len(rs),
                             "age_med": statistics.median(x["age_raw"] for x in rs)})

        per_cohort[study] = {"n_within": len(P), "age_strata": a_strata,
                             "dt_strata": d_strata,
                             "dense": study in DENSE}
        for s in a_strata:
            rows_csv.append([study, "interval_at_fixed_age", f"{s['lo']:g}-{s['hi']:g}d",
                             round(s["slope_dt"], 4), s["n"], round(s["dt_med"], 1)])
        for s in d_strata:
            rows_csv.append([study, "age_at_fixed_interval", f"{s['lo']:g}-{s['hi']:g}d",
                             round(s["slope_age"], 4), s["n"], round(s["age_med"], 1)])
        print(f"{study:<16} within pairs {len(P):5d}  "
              f"strata: age {len(a_strata)}, interval {len(d_strata)}", flush=True)

    # ---- pooled: same stratification, with study fixed effects inside each
    # stratum (a partial slope, not a mean of means)
    study_idx = {st: i for i, st in enumerate(args.studies)}

    def fe_slope(rs, xkey):
        present = sorted({r["study"] for r in rs})
        local = {st: i for i, st in enumerate(present)}
        nS = len(present)
        X, y = [], []
        for r in rs:
            x = [1.0, r[xkey]] + [0.0] * (nS - 1)
            si = local[r["study"]]
            if si > 0:
                x[1 + si] = 1.0
            X.append(x)
            y.append(r["y"])
        p = len(X[0])
        A = [[0.0] * p for _ in range(p)]
        b = [0.0] * p
        for xi, yi in zip(X, y):
            for a in range(p):
                if xi[a] == 0.0:
                    continue
                b[a] += xi[a] * yi
                for c in range(a, p):
                    if xi[c]:
                        A[a][c] += xi[a] * xi[c]
        for a in range(p):
            for c in range(a):
                A[a][c] = A[c][a]
        # gaussian elimination
        M = [row[:] + [b[i]] for i, row in enumerate(A)]
        for c in range(p):
            piv = max(range(c, p), key=lambda r: abs(M[r][c]))
            if abs(M[piv][c]) < 1e-10:
                return None
            M[c], M[piv] = M[piv], M[c]
            for r in range(c + 1, p):
                f = M[r][c] / M[c][c]
                if f:
                    for k in range(c, p + 1):
                        M[r][k] -= f * M[c][k]
        x = [0.0] * p
        for r in range(p - 1, -1, -1):
            x[r] = (M[r][p] - sum(M[r][k] * x[k] for k in range(r + 1, p))) / M[r][r]
        return x[1]

    def pooled_strata(key, edges, xkey):
        out = []
        for lo, hi in edges:
            rs = [r for r in pooled_rows if lo <= r[key] < hi]
            if len(rs) < 100:
                continue
            sl = fe_slope(rs, xkey)
            if sl is None:
                continue
            out.append({"lo": lo, "hi": hi, "slope": sl, "n": len(rs),
                        "n_studies": len({r["study"] for r in rs})})
        return out

    pooled_age = pooled_strata("age_raw", AGE_EDGES, "dt")
    pooled_dt = pooled_strata("dt_raw", DT_EDGES, "age")

    print("\npooled within-subject pairs (study fixed effects inside each stratum):")
    print("  interval slope by age stratum")
    for s in pooled_age:
        print(f"    age {s['lo']:g}-{s['hi']:g}d : b_dt = {s['slope']:+.3f} "
              f"(n={s['n']}, {s['n_studies']} cohorts)")
    print("  age slope by interval stratum")
    for s in pooled_dt:
        print(f"    dt  {s['lo']:g}-{s['hi']:g}d : b_age = {s['slope']:+.3f} "
              f"(n={s['n']}, {s['n_studies']} cohorts)")

    out = {"per_cohort": per_cohort,
           "pooled_interval_by_age": pooled_age,
           "pooled_age_by_interval": pooled_dt,
           "n_within": len(pooled_rows)}
    with open(os.path.join(args.out_dir, "identify.json"), "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out_dir, "identify.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["study", "analysis", "stratum", "slope", "n_pairs", "median_axis"])
        w.writerows(rows_csv)
        for s in pooled_age:
            w.writerow(["POOLED", "interval_at_fixed_age", f"{s['lo']:g}-{s['hi']:g}d",
                        round(s["slope"], 4), s["n"], ""])
        for s in pooled_dt:
            w.writerow(["POOLED", "age_at_fixed_interval", f"{s['lo']:g}-{s['hi']:g}d",
                        round(s["slope"], 4), s["n"], ""])
    print(f"\nwrote {args.out_dir}/identify.json and identify.csv")


if __name__ == "__main__":
    main()
