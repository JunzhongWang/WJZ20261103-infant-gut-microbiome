#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# rda_extract.R - turn a curatedMetagenomicData relative_abundance object into
# a plain, mass-preserving *leaf* table, using base R only.
#
#   Rscript pipeline/rda_extract.R <file.rda> <outdir> <study_name>
#
# Writes into <outdir>:
#   species.tsv   sample_id + leaf relative abundances (percent, rows sum to 100)
#   pheno.tsv     sample metadata, only for ExpressionSet layouts
#
# Why leaves. cMD3 stores every rank of the MetaPhlAn tree, so each sample has
# 7 nested copies of the same community (k, p, c, o, f, g, s) and the columns
# sum to 700, not 100. Computing a compositional distance on that table is
# wrong twice over: ancestors are counted as if they were separate organisms,
# and coarse ranks (which differ less between samples) are over-weighted. Only
# rows with no descendants form a partition, and those are the ones kept here.
#
# Why base R. The .rda holds a plain matrix (>= 2021 resources) or a Biobase
# ExpressionSet whose every slot is just an attribute, reachable with attr().
# ---------------------------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3) stop("usage: rda_extract.R <file.rda> <outdir> <study>")
rda <- args[[1]]; outdir <- args[[2]]; study <- args[[3]]
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

e <- new.env()
load(rda, e)
objs <- ls(e)
if (length(objs) != 1L) stop("expected exactly one object, got: ", paste(objs, collapse = ","))
obj <- get(objs[[1]], e)

if (is.matrix(obj)) {
  m <- obj
  d <- NULL
} else {
  m <- get("exprs", envir = attr(obj, "assayData"))
  d <- attributes(attr(obj, "phenoData"))$data
}

# --- keep only leaves of the taxonomy tree ---------------------------------
# A row is an ancestor exactly when its path is a strict prefix of another
# row's path. Leaves partition each sample's community, so they sum to 100.
key <- rownames(m)
isleaf <- !vapply(seq_along(key), function(i) {
  any(startsWith(key[-i], paste0(key[i], "|")))
}, logical(1), USE.NAMES = FALSE)
if (!any(isleaf)) stop("no leaf rows recognised; check the row-name format")
m <- m[isleaf, , drop = FALSE]
key <- key[isleaf]

# --- readable, unique taxon labels -----------------------------------------
parts <- strsplit(key, "|", fixed = TRUE)
pick <- function(pref) vapply(parts, function(p) {
  hit <- p[startsWith(p, pref)]
  if (length(hit)) sub(pref, "", hit[[1]], fixed = TRUE) else ""
}, character(1), USE.NAMES = FALSE)
genus <- pick("g__")
species <- pick("s__")

label <- species                                   # the common case
has_no_species <- !nzchar(species)
if (any(has_no_species)) {
  # unclassified at species level: name it by genus, or by the deepest rank
  rank_pref <- c("f__", "o__", "c__", "p__", "k__")
  lab <- rep("", sum(has_no_species))
  idx <- which(has_no_species)
  g <- genus[idx]
  lab[nzchar(g)] <- paste0(g[nzchar(g)], " (genus)")
  rest <- idx[!nzchar(g)]
  for (rp in rank_pref) {
    if (!length(rest)) break
    tag <- vapply(parts[rest], function(p) {
      hit <- p[startsWith(p, rp)]
      if (length(hit)) sub(rp, "", hit[[1]], fixed = TRUE) else ""
    }, character(1), USE.NAMES = FALSE)
    ok <- nzchar(tag)
    lab[match(rest[ok], idx)] <- paste0(tag[ok], " [", substr(rp, 1, 1), "]")
    rest <- rest[!ok]
  }
  label[idx] <- lab
}
label <- gsub("_", " ", label)
label <- make.unique(label, sep = " #")
rownames(m) <- label

# --- sample x taxon table --------------------------------------------------
if (is.null(d)) {
  sid <- colnames(m)
} else {
  sid <- if ("sample_id" %in% colnames(d)) as.character(d$sample_id) else rownames(d)
  if (any(!nzchar(sid))) sid <- colnames(m)
}
tab <- as.data.frame(t(m), check.names = FALSE)
tab <- cbind(sample_id = sid, tab)
write.table(tab, file.path(outdir, "species.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

if (!is.null(d)) {
  getc <- function(nm) if (nm %in% colnames(d)) d[[nm]] else rep(NA, nrow(d))
  ph <- data.frame(
    sample_id      = sid,
    subject_id     = getc("subjectID"),
    days           = getc("days_from_first_collection"),
    abx_raw        = getc("antibiotics_current_use"),
    age            = getc("age"),
    age_category   = getc("age_category"),
    body_site      = getc("body_site"),
    condition      = getc("study_condition"),
    disease        = getc("disease"),
    country        = getc("country"),
    ncbi_accession = getc("NCBI_accession"),
    stringsAsFactors = FALSE
  )
  write.table(ph, file.path(outdir, "pheno.tsv"), sep = "\t",
              quote = FALSE, row.names = FALSE, na = "NA")
}

rs <- colSums(m[, seq_len(min(20, ncol(m))), drop = FALSE])
cat(sprintf("%s: %d samples x %d leaf taxa; column sums %.2f-%.2f%s\n",
            study, nrow(tab), ncol(tab) - 1, min(rs), max(rs),
            if (is.null(d)) " (matrix layout, metadata external)" else ""))
