#!/usr/bin/env python3
"""Two new submission figures added in revision.

fig3_agetrends.svg   (A) the two distances fall together with age at a matched
                         interval; (B) age slopes of both distances and of R,
                         per interval band, with the random-effects pooled value
fig4_cohortmetric.svg the interval dependence of R inside every cohort, and
                         under three different distances
"""
import json
import math
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from make_figs_v3 import (OUT, INK, MUTED, GRID, PAPER, FONT, ORDER, NAME,
                          COLOR, head)  # noqa: E402

AGE_MID = {(0, 30): 15, (30, 90): 52, (90, 180): 127, (180, 365): 256,
           (365, 800): 540, (800, 1e9): 1000}
AGE_TICK = [(15, "0.5"), (52, "1.7"), (127, "4.2"), (256, "8.4"), (540, "18"),
            (1000, "33")]


def px(x0, w, lo, hi, v):
    a, b = math.log10(lo), math.log10(hi)
    return x0 + (math.log10(max(v, lo)) - a) / (b - a) * w


def fig3():
    strata = json.load(open(os.path.join(OUT, "strata.json")))
    trend = json.load(open(os.path.join(OUT, "age_trends_primary.json")))
    W, H = 680, 330
    s = head(W, H, "Figure 3. Both distances fall with age at a matched interval",
             "Panel A: between- and within-infant Bray-Curtis distance against "
             "infant age at a 60-120 day interval. Panel B: age slopes with 95% "
             "confidence intervals, per interval band and pooled.")
    # ---------------- panel A
    x0, y0, w, h = 56, 34, 258, 214
    xr, yr = (30, 1100), (0.4, 1.0)
    f = lambda v: px(x0, w, *xr, v)
    g = lambda v: y0 + h - (v - yr[0]) / (yr[1] - yr[0]) * h
    s.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y0+h}" stroke="{MUTED}" stroke-width="0.8"/>')
    for t in (0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0):
        s.append(f'<line x1="{x0}" y1="{g(t):.1f}" x2="{x0+w}" y2="{g(t):.1f}" stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x0-6}" y="{g(t)+3:.1f}" font-size="8" fill="{MUTED}" text-anchor="end">{t:g}</text>')
    for v, lab in AGE_TICK:
        if xr[0] <= v <= xr[1]:
            s.append(f'<text x="{f(v):.1f}" y="{y0+h+13}" font-size="8" fill="{MUTED}" text-anchor="middle">{lab}</text>')
    s.append(f'<text x="{x0+w/2}" y="{y0+h+27}" font-size="8.5" fill="{MUTED}" text-anchor="middle">age (months, log scale)</text>')
    s.append(f'<text x="14" y="{y0+h/2}" font-size="8.5" fill="{MUTED}" text-anchor="middle" transform="rotate(-90 14 {y0+h/2})">Bray-Curtis distance</text>')
    s.append(f'<text x="{x0}" y="{y0-16}" font-size="9.5" fill="{INK}">A  at a 60–120 day interval</text>')

    def series(key, lo_k, hi_k, col, dash):
        pts = []
        for c in strata["cells"]:
            if (c["dt_lo"], c["dt_hi"]) != (60, 120):
                continue
            am = AGE_MID.get((c["age_lo"], c["age_hi"]))
            if am is None or not c.get(lo_k):
                continue
            pts.append((am, c[key], c[lo_k], c[hi_k]))
        pts.sort()
        for a, y, lo, hi in pts:
            s.append(f'<line x1="{f(a):.1f}" y1="{g(hi):.1f}" x2="{f(a):.1f}" y2="{g(lo):.1f}" stroke="{col}" stroke-width="1.1" opacity="0.55"/>')
        d = " ".join(f'{"M" if i == 0 else "L"}{f(a):.1f},{g(y):.1f}' for i, (a, y, _, _) in enumerate(pts))
        s.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.8" {dash}/>')
        for a, y, _, _ in pts:
            s.append(f'<circle cx="{f(a):.1f}" cy="{g(y):.1f}" r="2.6" fill="{col}"/>')
        return pts

    series("between", "between_lo", "between_hi", "#3C6E9F", "")
    series("within", "within_lo", "within_hi", "#C2703A", 'stroke-dasharray="5 3"')
    s.append(f'<text x="{x0+w-4}" y="{g(0.83):.1f}" font-size="8.5" fill="#3C6E9F" text-anchor="end">between infants</text>')
    s.append(f'<text x="{x0+w-4}" y="{g(0.47):.1f}" font-size="8.5" fill="#C2703A" text-anchor="end">within infant</text>')

    # ---------------- panel B
    x1, y1, w1, h1 = 388, 34, 250, 214
    rows = trend["rows"]
    xs = [math.log10(r["dt_lo"] + 8) for r in rows]
    xlo, xhi = min(xs) - 0.12, max(xs) + 0.30
    yr2 = (-0.36, 0.34)
    f2 = lambda v: x1 + (v - xlo) / (xhi - xlo) * w1
    g2 = lambda v: y1 + h1 - (v - yr2[0]) / (yr2[1] - yr2[0]) * h1
    s.append(f'<line x1="{x1}" y1="{y1+h1}" x2="{x1+w1}" y2="{y1+h1}" stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x1}" y1="{y1}" x2="{x1}" y2="{y1+h1}" stroke="{MUTED}" stroke-width="0.8"/>')
    for t in (-0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3):
        s.append(f'<line x1="{x1}" y1="{g2(t):.1f}" x2="{x1+w1}" y2="{g2(t):.1f}" stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x1-6}" y="{g2(t)+3:.1f}" font-size="8" fill="{MUTED}" text-anchor="end">{t:+.1f}</text>')
    s.append(f'<line x1="{x1}" y1="{g2(0):.1f}" x2="{x1+w1}" y2="{g2(0):.1f}" stroke="{INK}" stroke-width="0.9"/>')
    for r in rows:
        lab = f'{r["dt_lo"]:g}–{r["dt_hi"]:g}' if r["dt_hi"] < 1e8 else f'>{r["dt_lo"]:g}'
        s.append(f'<text x="{f2(math.log10(r["dt_lo"]+8)):.1f}" y="{y1+h1+13}" font-size="8" fill="{MUTED}" text-anchor="middle">{lab}</text>')
    s.append(f'<text x="{x1+w1/2}" y="{y1+h1+27}" font-size="8.5" fill="{MUTED}" text-anchor="middle">sampling interval (days, log scale)</text>')
    s.append(f'<text x="{x1-40}" y="{y1+h1/2}" font-size="8.5" fill="{MUTED}" text-anchor="middle" transform="rotate(-90 {x1-40} {y1+h1/2})">age slope (per e-fold)</text>')
    s.append(f'<text x="{x1}" y="{y1-16}" font-size="9.5" fill="{INK}">B  age slope at matched interval</text>')
    s.append(f'<defs><clipPath id="clipB"><rect x="{x1}" y="{y1}" width="{w1}" height="{h1}"/></clipPath></defs>')

    offs = {"between_slope": -0.055, "within_slope": 0.0, "R_slope": 0.055}
    cols = {"between_slope": "#3C6E9F", "within_slope": "#C2703A", "R_slope": "#0F6E56"}
    s.append('<g clip-path="url(#clipB)">')
    for key in ("between_slope", "within_slope", "R_slope"):
        pts = []
        for r in rows:
            x = f2(math.log10(r["dt_lo"] + 8)) + offs[key] * w1 / 3.2
            skey = {"between_slope": "between_se", "within_slope": "within_se",
                    "R_slope": "R_se"}[key]
            pts.append((x, r[key], r[skey]))
        d = " ".join(f'{"M" if i == 0 else "L"}{x:.1f},{g2(y):.1f}' for i, (x, y, _) in enumerate(pts))
        s.append(f'<path d="{d}" fill="none" stroke="{cols[key]}" stroke-width="1.1" opacity="0.45"/>')
        for x, y, se in pts:
            s.append(f'<line x1="{x:.1f}" y1="{g2(y+1.96*se):.1f}" x2="{x:.1f}" y2="{g2(y-1.96*se):.1f}" stroke="{cols[key]}" stroke-width="1.2"/>')
            s.append(f'<circle cx="{x:.1f}" cy="{g2(y):.1f}" r="2.6" fill="{cols[key]}"/>')
    s.append('</g>')
    # pooled diamonds at the right edge
    xd = x1 + w1 - 26
    for key, pk in (("between_slope", "pooled_between"), ("within_slope", "pooled_within"),
                    ("R_slope", "pooled_R")):
        p = trend[pk]
        y, se = p["effect"], p["se"]
        s.append(f'<line x1="{xd:.1f}" y1="{g2(y+1.96*se):.1f}" x2="{xd:.1f}" y2="{g2(y-1.96*se):.1f}" stroke="{cols[key]}" stroke-width="1.4"/>')
        s.append(f'<path d="M{xd:.1f},{g2(y)-3.4:.1f} L{xd+4:.1f},{g2(y):.1f} L{xd:.1f},{g2(y)+3.4:.1f} L{xd-4:.1f},{g2(y):.1f} Z" fill="{cols[key]}"/>')
    s.append(f'<text x="{xd:.1f}" y="{y1+h1+13}" font-size="7.5" fill="{MUTED}" text-anchor="middle">pooled</text>')
    for k, (key, col, lab) in enumerate((
            ("R_slope", "#0F6E56", "R = between / within"),
            ("between_slope", "#3C6E9F", "between infants"),
            ("within_slope", "#C2703A", "within infant"))):
        yy = y1 + 10 + k * 12
        s.append(f'<line x1="{x1+6}" y1="{yy-3:.1f}" x2="{x1+18}" y2="{yy-3:.1f}" stroke="{col}" stroke-width="1.6"/>')
        s.append(f'<text x="{x1+22}" y="{yy}" font-size="8" fill="{col}">{lab}</text>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig3_agetrends.svg"), "w").write("\n".join(s))
    print("wrote fig3_agetrends.svg")


def fig4():
    rev = json.load(open(os.path.join(OUT, "revision.json")))
    W, H = 680, 300
    s = head(W, H, "Figure 4. The interval dependence holds in every cohort and every distance",
             "Panel A: R against interval inside each cohort. Panel B: the same "
             "comparison under Bray-Curtis, Jaccard and Aitchison distance.")
    x0, y0, w, h = 58, 32, 268, 196
    xr, yr = (0.9, 300), (0.85, 2.4)
    f = lambda v: px(x0, w, *xr, v)
    g = lambda v: y0 + h - (v - yr[0]) / (yr[1] - yr[0]) * h
    s.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y0+h}" stroke="{MUTED}" stroke-width="0.8"/>')
    for t in (1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2):
        s.append(f'<line x1="{x0}" y1="{g(t):.1f}" x2="{x0+w}" y2="{g(t):.1f}" stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x0-6}" y="{g(t)+3:.1f}" font-size="8" fill="{MUTED}" text-anchor="end">{t:.1f}</text>')
    for v in (1, 3, 10, 30, 100):
        s.append(f'<text x="{f(v):.1f}" y="{y0+h+13}" font-size="8" fill="{MUTED}" text-anchor="middle">{v}</text>')
    s.append(f'<text x="{x0+w/2}" y="{y0+h+27}" font-size="8.5" fill="{MUTED}" text-anchor="middle">sampling interval (days, log scale)</text>')
    s.append(f'<text x="15" y="{y0+h/2}" font-size="8.5" fill="{MUTED}" text-anchor="middle" transform="rotate(-90 15 {y0+h/2})">R = between / within</text>')
    s.append(f'<text x="{x0}" y="{y0-14}" font-size="9.5" fill="{INK}">A  one line per cohort</text>')
    s.append(f'<line x1="{x0}" y1="{g(1.0):.1f}" x2="{x0+w}" y2="{g(1.0):.1f}" stroke="{INK}" stroke-width="0" />')
    for st in ORDER:
        rows = rev["cohort_R"].get(st) or []
        if len(rows) < 2:
            continue
        pts = [(math.sqrt(r["dt_lo"] * min(r["dt_hi"] or 300.0, 300.0)), r["R"]) for r in rows]
        pts.sort()
        d = " ".join(f'{"M" if i == 0 else "L"}{f(x):.1f},{g(y):.1f}' for i, (x, y) in enumerate(pts))
        s.append(f'<path d="{d}" fill="none" stroke="{COLOR[st]}" stroke-width="1.5" opacity="0.9"/>')
        for x, y in pts:
            s.append(f'<circle cx="{f(x):.1f}" cy="{g(y):.1f}" r="2.4" fill="{COLOR[st]}"/>')
    # legend
    for i, st in enumerate(ORDER):
        yy = y0 + 4 + i * 13
        s.append(f'<line x1="{x0+w-88}" y1="{yy:.1f}" x2="{x0+w-74}" y2="{yy:.1f}" stroke="{COLOR[st]}" stroke-width="1.6"/>')
        s.append(f'<text x="{x0+w-70}" y="{yy+3:.1f}" font-size="7.6" fill="{MUTED}">{NAME[st].split(" (")[0]}</text>')

    # panel B: metrics, averaged over cohorts
    x1, y1, w1, h1 = 392, 32, 246, 196
    s.append(f'<line x1="{x1}" y1="{y1+h1}" x2="{x1+w1}" y2="{y1+h1}" stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x1}" y1="{y1}" x2="{x1}" y2="{y1+h1}" stroke="{MUTED}" stroke-width="0.8"/>')
    for t in (1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2):
        s.append(f'<line x1="{x1}" y1="{g(t):.1f}" x2="{x1+w1}" y2="{g(t):.1f}" stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x1-6}" y="{g(t)+3:.1f}" font-size="8" fill="{MUTED}" text-anchor="end">{t:.1f}</text>')
    bins = [(1, 14, "1–14"), (14, 60, "14–60"), (60, 1e9, ">60")]
    for i, (lo, hi, lab) in enumerate(bins):
        cx = x1 + 44 + i * 74
        s.append(f'<text x="{cx}" y="{y1+h1+13}" font-size="8" fill="{MUTED}" text-anchor="middle">{lab}</text>')
    s.append(f'<text x="{x1+w1/2}" y="{y1+h1+27}" font-size="8.5" fill="{MUTED}" text-anchor="middle">sampling interval (days)</text>')
    s.append(f'<text x="{x1}" y="{y1-14}" font-size="9.5" fill="{INK}">B  three distances</text>')
    mk = {"bray": ("#1a1a18", 0), "jac": ("#3C6E9F", 1), "ait": ("#7A8B2F", 2)}
    lbl = {"bray": "Bray-Curtis", "jac": "Jaccard", "ait": "Aitchison"}
    rob = rev.get("metric_robustness") or {}
    for m, (col, k) in mk.items():
        vals = []
        for lo, hi, _ in bins:
            xs = []
            for st, rows in rob.items():
                for r in rows:
                    if r["metric"] == m and r["dt_lo"] == lo and r["dt_hi"] == (None if hi > 1e8 else hi):
                        xs.append(r["R"])
            vals.append(statistics.fmean(xs) if xs else None)
        pts = [(x1 + 44 + i * 74 + (k - 1) * 13, v) for i, v in enumerate(vals) if v]
        d = " ".join(f'{"M" if i == 0 else "L"}{x:.1f},{g(y):.1f}' for i, (x, y) in enumerate(pts))
        s.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.4" opacity="0.5"/>')
        for x, y in pts:
            s.append(f'<circle cx="{x:.1f}" cy="{g(y):.1f}" r="3" fill="{col}"/>')
        s.append(f'<text x="{x1+w1-84}" y="{y1+12+k*13}" font-size="7.8" fill="{col}">{lbl[m]}</text>')
    s.append(f'<line x1="{x1}" y1="{g(1.0):.1f}" x2="{x1+w1}" y2="{g(1.0):.1f}" stroke="#8a8a86" stroke-width="0.8" stroke-dasharray="3 3"/>')
    s.append(f'<text x="{x1+w1-4}" y="{g(1.0)-4:.1f}" font-size="7.5" fill="{MUTED}" text-anchor="end">R = 1</text>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig4_cohortmetric.svg"), "w").write("\n".join(s))
    print("wrote fig4_cohortmetric.svg")


if __name__ == "__main__":
    fig3()
    fig4()
