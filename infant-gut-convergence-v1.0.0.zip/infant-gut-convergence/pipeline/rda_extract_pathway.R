#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# rda_extract_pathway.R - turn a curatedMetagenomicData pathway_abundance
# object into a plain sample x pathway TSV, using base R only.
#
#   Rscript pipeline/rda_extract_pathway.R <file.rda> <outdir> <study_name>
#
# Writes <outdir>/pathway.tsv with sample_id in column 1.  No leaf filtering:
# UniRef pathway rows form a flat table, not a nested tree.
# ---------------------------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3) stop("usage: rda_extract_pathway.R <file.rda> <outdir> <study>")
rda <- args[[1]]; outdir <- args[[2]]; study <- args[[3]]
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

e <- new.env()
load(rda, e)
objs <- ls(e)
if (length(objs) != 1L) stop("expected exactly one object, got: ", paste(objs, collapse = ","))
obj <- get(objs[[1]], e)

if (is.matrix(obj)) {
  m <- obj
  d <- NULL
} else {
  m <- get("exprs", envir = attr(obj, "assayData"))
  d <- attributes(attr(obj, "phenoData"))$data
}

key <- rownames(m)
if (anyDuplicated(key)) key <- make.unique(key, sep = " #")
rownames(m) <- key

if (is.null(d)) {
  sid <- colnames(m)
} else {
  sid <- if ("sample_id" %in% colnames(d)) as.character(d$sample_id) else rownames(d)
  if (any(!nzchar(sid))) sid <- colnames(m)
}

tab <- as.data.frame(t(m), check.names = FALSE)
tab <- cbind(sample_id = sid, tab)
write.table(tab, file.path(outdir, "pathway.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

rs <- colSums(m[, seq_len(min(20, ncol(m))), drop = FALSE], na.rm = TRUE)
cat(sprintf("%s: %d samples x %d pathways; col sums %.1f-%.1f%s\n",
            study, nrow(tab), ncol(tab) - 1, min(rs), max(rs),
            if (is.null(d)) " (matrix layout)" else ""))
