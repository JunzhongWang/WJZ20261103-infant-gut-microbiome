#!/usr/bin/env python3
"""Age trends of the three quantities that matter, inside matched strata.

The first draft collapsed the two distances into R and then said "between-
infant distance is nearly invariant".  That is a property of the ratio, not of
the data: at a fixed interval both distances fall as infants age, and they fall
by similar amounts.  This script estimates the three age trends separately,
each one from the matched cells produced by strata.py, weighted by the
bootstrap variance of the cell mean.

    python3 pipeline/strata.py --boot 1000 --out-dir results/real   (first)
    python3 pipeline/revision_trends.py --strata results/real/strata.json

Outputs results/real/age_trends.csv and age_trends.json
"""
import argparse
import csv
import json
import math
import os
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# representative age of each band; the open-ended band is excluded from trend
# fitting because it has no midpoint
AGE_MID = {(0, 30): 15.0, (30, 90): 52.0, (90, 180): 127.0,
           (180, 365): 256.0, (365, 800): 540.0, (800, 1e9): None}


def wls(points):
    """Weighted least squares of y on x with weights 1/var(y)."""
    if len(points) < 3:
        return None
    sw = sum(1.0 / v for _, _, v in points)
    mx = sum(x / v for x, _, v in points) / sw
    my = sum(y / v for _, y, v in points) / sw
    sxx = sum((x - mx) ** 2 / v for x, _, v in points)
    sxy = sum((x - mx) * (y - my) / v for x, y, v in points)
    if sxx <= 0:
        return None
    b = sxy / sxx
    msw = sum((y - my - b * (x - mx)) ** 2 / v for x, y, v in points)
    dof = len(points) - 2
    scale = max(1.0, msw / dof) if dof > 0 else 1.0
    se = math.sqrt(scale / sxx)
    return {"slope": b, "se": se, "k": len(points),
            "p": math.erfc(abs(b / se) / math.sqrt(2))}


def log_ci(est, lo, hi):
    """Log-scale SE implied by a 95% percentile interval."""
    if not (est > 0 and lo > 0 and hi > 0) or hi <= lo:
        return None
    return (math.log(hi) - math.log(lo)) / (2 * 1.96)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strata", default=os.path.join(ROOT, "results", "real",
                                                    "strata.json"))
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    ap.add_argument("--tag", default="primary")
    args = ap.parse_args()

    with open(args.strata) as f:
        data = json.load(f)
    cells = data["cells"]

    rows = []
    by_dt = {}
    for c in cells:
        key = (c["dt_lo"], c["dt_hi"])
        by_dt.setdefault(key, []).append(c)

    print(f"{'interval':>12} {'n':>3} {'d log(between)/d log(age)':>27} "
          f"{'d log(within)':>22} {'d log(R)':>20}")
    for dt in sorted(by_dt):
        pts_b, pts_w, pts_r = [], [], []
        for c in by_dt[dt]:
            age_mid = AGE_MID.get((c["age_lo"], c["age_hi"]))
            if age_mid is None:
                continue
            x = math.log(age_mid)
            for pts, est, lo, hi in (
                    (pts_b, c["between"], c.get("between_lo"), c.get("between_hi")),
                    (pts_w, c["within"], c.get("within_lo"), c.get("within_hi")),
                    (pts_r, c["ratio"], c["lo"], c["hi"])):
                se = log_ci(est, lo, hi) if lo else None
                if se and se > 0:
                    pts.append((x, math.log(est), se * se))
        fb, fw, fr = wls(pts_b), wls(pts_w), wls(pts_r)
        if not (fb and fw and fr):
            continue
        rows.append({"dt_lo": dt[0], "dt_hi": dt[1], "k_cells": fb["k"],
                     "between_slope": fb["slope"], "between_se": fb["se"],
                     "between_p": fb["p"],
                     "within_slope": fw["slope"], "within_se": fw["se"],
                     "within_p": fw["p"],
                     "R_slope": fr["slope"], "R_se": fr["se"], "R_p": fr["p"]})
        print(f"{dt[0]:>5g}-{dt[1]:<6g} {fb['k']:>3d} "
              f"{fb['slope']:>+10.3f} (se {fb['se']:.3f}, p={fb['p']:.2g}) "
              f"{fw['slope']:>+10.3f} (se {fw['se']:.3f}, p={fw['p']:.2g}) "
              f"{fr['slope']:>+8.3f} (se {fr['se']:.3f})")

    def pool(key, se_key):
        eff = [r[key] for r in rows]
        se = [r[se_key] for r in rows]
        if not eff:
            return None
        w = [1.0 / s ** 2 for s in se]
        mu = sum(a * b for a, b in zip(w, eff)) / sum(w)
        s = math.sqrt(1.0 / sum(w))
        q = sum(x * (e - mu) ** 2 for x, e in zip(w, eff))
        c = sum(w) - sum(x ** 2 for x in w) / sum(w)
        tau2 = max(0.0, (q - (len(eff) - 1)) / c) if c > 1e-12 and len(eff) > 1 else 0.0
        wr = [1.0 / (t ** 2 + tau2) for t in se]
        mu = sum(a * b for a, b in zip(wr, eff)) / sum(wr)
        s = math.sqrt(1.0 / sum(wr))
        i2 = max(0.0, (q - (len(eff) - 1)) / q) * 100 if q > 1e-12 else 0.0
        return {"effect": mu, "se": s, "p": math.erfc(abs(mu / s) / math.sqrt(2)),
                "I2": i2, "tau2": tau2, "k": len(eff)}

    out = {"rows": rows,
           "pooled_between": pool("between_slope", "between_se"),
           "pooled_within": pool("within_slope", "within_se"),
           "pooled_R": pool("R_slope", "R_se")}
    print("\npooled over interval bands (random effects):")
    for name, key in (("between", "pooled_between"), ("within", "pooled_within"),
                      ("R", "pooled_R")):
        v = out[key]
        if v:
            print(f"   {name:<8} {v['effect']:+.3f} (se {v['se']:.3f}, "
                  f"p={v['p']:.2g}, I2={v['I2']:.0f}%, k={v['k']})")

    with open(os.path.join(args.out_dir, f"age_trends_{args.tag}.json"), "w") as f:
        json.dump(out, f, indent=2)
    with open(os.path.join(args.out_dir, f"age_trends_{args.tag}.csv"), "w",
              newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(list(rows[0].keys()))
        for r in rows:
            w.writerow([round(v, 4) if isinstance(v, float) else v
                        for v in r.values()])
    print(f"wrote {args.out_dir}/age_trends_{args.tag}.json/.csv")


if __name__ == "__main__":
    main()
