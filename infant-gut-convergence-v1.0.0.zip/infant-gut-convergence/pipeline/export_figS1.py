#!/usr/bin/env python3
"""Export Supplementary Figure S1 as a standalone deliverable set:
   - SVG (vector)
   - PNG (high resolution, 2800 px wide)
   - HTML (figure + caption, single page)
   - PDF  (single page, caption included)
   - caption .txt (for submission systems)
"""
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC_SVG = ROOT / "results/real/figS1_functional.svg"
OUT = ROOT / "figures_tables_standalone"
if not OUT.is_dir():
    OUT.mkdir()

STEM = "FigureS1_functional_robustness"
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
PROFILE = "/tmp/chrome-pdf-profile"

TITLE = "Supplementary Figure S1"
CAPTION = (
    "Functional-level robustness of R. (A) R against the interval between samples, "
    "computed on pathway (HUMAnN) profiles, one line per age band; dashed line: R = 1; "
    "shadows: 95% cluster-bootstrap CI over infants (500 replicates). (B) Age-pooled R "
    "per interval band under the species (MetaPhlAn) and the pathway (HUMAnN) profile."
)

# ---------------------------------------------------------------- SVG (copy)
svg_text = SRC_SVG.read_text()
# give the standalone copy an explicit intrinsic size so it opens at natural scale
svg_standalone = svg_text.replace(
    'viewBox="0 0 680 300" xmlns="http://www.w3.org/2000/svg" role="img" width="100%"',
    'viewBox="0 0 680 300" xmlns="http://www.w3.org/2000/svg" role="img" width="1360" height="600"',
    1,
)
(OUT / f"{STEM}.svg").write_text(svg_standalone)

# ---------------------------------------------------------------- HTML page
html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>{TITLE}</title>
<style>
  @page {{ size: 760px 500px; margin: 0; }}
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; padding: 26px 30px 20px; background: #fff;
         font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
         color: #1a1a1a; -webkit-font-smoothing: antialiased; }}
  .eyebrow {{ font-size: 10px; letter-spacing: .12em; text-transform: uppercase;
              color: #6b7280; margin: 0 0 8px; }}
  .fig {{ width: 100%; display: block; }}
  figcaption {{ margin-top: 12px; font-size: 10.5px; line-height: 1.55; color: #262626;
                text-align: justify; }}
  figcaption strong {{ color: #111; }}
</style></head>
<body>
  <p class="eyebrow">Gut Microbes &middot; supplementary material</p>
  <figure>
    <img class="fig" src="{STEM}.svg" alt="Functional-level robustness of R">
    <figcaption><strong>{TITLE}.</strong> {CAPTION}</figcaption>
  </figure>
</body></html>
"""
(OUT / f"{STEM}.html").write_text(html)

# ------------------------------------------------------- HTML -> PDF -> PNG
def chrome_pdf(src_html: Path, dst_pdf: Path):
    if dst_pdf.exists():
        dst_pdf.unlink()
    subprocess.run(
        [CHROME, "--headless=new", "--disable-gpu", "--in-process-gpu",
         f"--user-data-dir={PROFILE}", "--no-first-run", "--no-sandbox",
         "--no-pdf-header-footer", "--virtual-time-budget=6000",
         f"--print-to-pdf={dst_pdf}", f"file://{src_html}"],
        capture_output=True, timeout=180,
    )
    if not dst_pdf.exists() or dst_pdf.stat().st_size < 2000:
        raise RuntimeError(f"PDF render failed for {src_html.name}")

pdf_path = OUT / f"{STEM}.pdf"
# the print page references the SVG by relative name -> render from that dir
chrome_pdf(OUT / f"{STEM}.html", pdf_path)

png_path = OUT / f"{STEM}.png"
r = subprocess.run(["sips", "-s", "format", "png",
                    "--resampleWidth", "2800", str(pdf_path), "--out", str(png_path)],
                   capture_output=True, text=True)
if r.returncode != 0:
    raise RuntimeError(r.stderr.strip()[:300])

# ---------------------------------------------------------------- caption txt
(OUT / f"{STEM}_caption.txt").write_text(
    f"{TITLE}. {CAPTION}\n", encoding="utf-8"
)

# ---------------------------------------------------------------- report
for p in sorted(OUT.glob(f"{STEM}*")):
    print(f"{p.name:52s} {p.stat().st_size/1024:8.1f} KB")
