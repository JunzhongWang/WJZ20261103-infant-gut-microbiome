#!/usr/bin/env python3
"""Join an MGnify species table with the curated cMD3 sample metadata.

    python3 pipeline/join_meta.py --study BackhedF_2015

Reads  data/<study>/species.tsv                (from mgnify_fetch.py)
       infant_samples.csv                      (from cMD3, keyed by run accession)
Writes data/<study>/species.csv  and  data/<study>/meta.csv  (pipeline format:
       sample_id, subject_id, study, days, abx)

Only samples that appear in both are kept, so every downstream statistic is
computed on samples whose age and subject identity are curator-verified.
"""
import argparse
import csv
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--study", required=True)
    ap.add_argument("--meta-csv", default=os.path.join(ROOT, "infant_samples.csv"))
    args = ap.parse_args()

    d = os.path.join(ROOT, "data", args.study)
    sp_path = os.path.join(d, "species.tsv")
    with open(sp_path, newline="") as f:
        rd = list(csv.reader(f, delimiter="\t"))
    header = rd[0]
    rows = [r for r in rd[1:] if r and r[0]]

    meta_rows = {}
    with open(args.meta_csv, newline="") as f:
        for r in csv.DictReader(f):
            if r["study_name"] != args.study:
                continue
            acc = (r.get("NCBI_accession") or "").strip()
            if acc:
                meta_rows[acc] = r

    keep = [r for r in rows if r[0] in meta_rows]
    print(f"{args.study}: {len(rows)} samples in MGnify, "
          f"{len(meta_rows)} in cMD3, {len(keep)} matched")

    # write species.csv with the matched subset
    with open(os.path.join(d, "species.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        for r in keep:
            w.writerow(r)

    subj = {}
    n_no_age = 0
    with open(os.path.join(d, "meta.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["sample_id", "subject_id", "study", "days", "abx"])
        for r in keep:
            m = meta_rows[r[0]]
            days = (m.get("days_from_first_collection") or "").strip()
            if days in ("", "NA"):
                n_no_age += 1
                continue
            abx_raw = (m.get("antibiotics_current_use") or "").strip().lower()
            abx = 1 if abx_raw in ("true", "yes", "1") else 0
            sid = f"{args.study}::{m['subject_id']}"
            subj.setdefault(sid, 0)
            subj[sid] += 1
            w.writerow([r[0], sid, args.study, days, abx])

    multi = sum(1 for v in subj.values() if v >= 2)
    print(f"  usable with age: {sum(subj.values())} samples, "
          f"{len(subj)} subjects, {multi} with >=2 visits "
          f"(dropped {n_no_age} without days)")


if __name__ == "__main__":
    main()
