#!/usr/bin/env python3
"""Model-free estimate of R, the between/within distance ratio, in matched strata.

R(age, dt) is the quantity that "microbial individuality" claims rest on: how
much farther an infant sits from a stranger than from itself. Estimating it
from a regression means extrapolating; estimating it inside matched strata does
not.

A within-subject pair and a between-subject pair land in the same cell when
they share (i) the age of the older sample and (ii) the gap between the two
samples. Both quantities are observed, not modelled, so the cell means are
direct comparisons at matched age and matched interval. Cells with too few
pairs of either kind are dropped rather than smoothed over.

    python3 pipeline/strata.py --boot 1000

Outputs
    strata.json   R per cell with bootstrap CI
    strata.csv    long form
    strata_curve.csv  R against interval, one row per age band
"""
import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decay_model import load, bray, STUDIES  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AGE_EDGES = [(0, 30), (30, 90), (90, 180), (180, 365), (365, 800), (800, 1e9)]
DT_EDGES = [(1, 7), (7, 14), (14, 30), (30, 60), (60, 120), (120, 240),
            (240, 500), (500, 1e9)]
MIN_W = 12
MIN_B = 60
N_BETWEEN_DRAWS = 60000


def band(x, edges):
    for lo, hi in edges:
        if lo <= x < hi:
            return (lo, hi)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", default=STUDIES)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--min-dt", type=int, default=1)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    # one record per pair: (cell, subject(s), log distance)
    within, between = [], []
    cohort_info = {}
    for si, study in enumerate(args.studies):
        rel, age, subj = load(study)
        by = {}
        for i, s in enumerate(subj):
            by.setdefault(s, []).append(i)
        nw = nb = 0
        for s, ii in by.items():
            ii = sorted(ii, key=lambda k: age[k])
            for a in range(len(ii)):
                for b in range(a + 1, len(ii)):
                    i, j = ii[a], ii[b]
                    dt = age[j] - age[i]
                    if dt < args.min_dt:
                        continue
                    ab, db = band(age[j], AGE_EDGES), band(dt, DT_EDGES)
                    if ab is None or db is None:
                        continue
                    d = bray(rel[i], rel[j])
                    if d <= 0:
                        continue
                    within.append(((ab, db), (si, s), math.log(d)))
                    nw += 1
        rng = random.Random(31 + si)
        keys = list(by)
        for _ in range(N_BETWEEN_DRAWS):
            s1, s2 = rng.sample(keys, 2)
            i, j = rng.choice(by[s1]), rng.choice(by[s2])
            if age[i] > age[j]:
                i, j = j, i
            dt = age[j] - age[i]
            if dt < args.min_dt:
                continue
            ab, db = band(age[j], AGE_EDGES), band(dt, DT_EDGES)
            if ab is None or db is None:
                continue
            d = bray(rel[i], rel[j])
            if d <= 0:
                continue
            between.append(((ab, db), (si, s1), (si, s2), math.log(d)))
            nb += 1
        cohort_info[study] = {"n_samples": len(age), "n_subjects": len(by),
                              "n_within_pairs": nw, "n_between_pairs": nb,
                              "age_min": min(age), "age_max": max(age)}
        print(f"  {study:<16} {nw:5d} within  {nb:6d} between pairs", flush=True)

    cells = sorted({r[0] for r in within} & {r[0] for r in between})
    W_by = {}
    for cell, lab, y in within:
        W_by.setdefault(cell, []).append(y)
    B_by = {}
    for cell, a, b, y in between:
        B_by.setdefault(cell, []).append(y)

    rows = []
    for cell in cells:
        w, b = W_by[cell], B_by[cell]
        if len(w) < MIN_W or len(b) < MIN_B:
            continue
        rows.append({"age_lo": cell[0][0], "age_hi": cell[0][1],
                     "dt_lo": cell[1][0], "dt_hi": cell[1][1],
                     "n_within": len(w), "n_between": len(b),
                     "within": statistics.fmean(w), "between": statistics.fmean(b),
                     "log_ratio": statistics.fmean(b) - statistics.fmean(w)})
        rows[-1]["ratio"] = math.exp(rows[-1]["log_ratio"])

    # ---- cluster bootstrap over subjects
    subs = list(dict.fromkeys([l for cell, l, _ in within] +
                              [x for cell, a, b, _ in between for x in (a, b)]))
    pos = {s: i for i, s in enumerate(subs)}
    k = len(subs)
    Wrec = [((cell), (pos[lab],), y) for cell, lab, y in within]
    Brec = [(cell, (pos[a], pos[b]), y) for cell, a, b, y in between]
    cell_idx = {c: i for i, c in enumerate(cells)}

    def estimate(mult):
        sw = {}
        nw = {}
        sb = {}
        nb = {}
        for cell, (i,), y in Wrec:
            m = mult[i]
            if m:
                sw[cell] = sw.get(cell, 0.0) + m * y
                nw[cell] = nw.get(cell, 0) + m
        for cell, (i, j), y in Brec:
            m = mult[i] * mult[j]
            if m:
                sb[cell] = sb.get(cell, 0.0) + m * y
                nb[cell] = nb.get(cell, 0) + m
        out = {}
        for cell in cells:
            if nw.get(cell, 0) >= MIN_W and nb.get(cell, 0) >= MIN_B:
                mw = sw[cell] / nw[cell]
                mb = sb[cell] / nb[cell]
                out[cell] = (mb - mw, mw, mb)
        return out

    point = estimate([1] * k)
    rng = random.Random(4242)
    boots = []
    for it in range(args.boot):
        m = [0] * k
        for _ in range(k):
            m[rng.randrange(k)] += 1
        boots.append(estimate(m))
        if (it + 1) % 200 == 0:
            print(f"  bootstrap {it + 1}/{args.boot}", flush=True)

    def ci(vals):
        if len(vals) < 20:
            return float("nan"), float("nan"), float("nan")
        q = statistics.quantiles(vals, n=40)
        sd = statistics.pstdev(vals)
        return math.exp(q[0]), math.exp(q[-1]), sd

    for r in rows:
        cell = ((r["age_lo"], r["age_hi"]), (r["dt_lo"], r["dt_hi"]))
        lr = [b[cell][0] for b in boots if cell in b]
        lw = [b[cell][1] for b in boots if cell in b]
        lb = [b[cell][2] for b in boots if cell in b]
        if len(lr) > 20:
            r["lo"], r["hi"], sd = ci(lr)
            r["p"] = math.erfc(abs(point[cell][0] / sd) / math.sqrt(2)) if sd else 1.0
            r["within_lo"], r["within_hi"], _ = ci(lw)
            r["between_lo"], r["between_hi"], _ = ci(lb)
        else:
            r["lo"] = r["hi"] = float("nan")
            r["p"] = float("nan")
            r["within_lo"] = r["within_hi"] = float("nan")
            r["between_lo"] = r["between_hi"] = float("nan")

    for r in rows:
        r["within"] = math.exp(r["within"])
        r["between"] = math.exp(r["between"])
        r["within_sd"] = r["within"] * math.log(r["within_hi"] / r["within"]) if r["within_hi"] > 0 else float("nan")
        r["between_sd"] = r["between"] * math.log(r["between_hi"] / r["between"]) if r["between_hi"] > 0 else float("nan")

    print("\nR = between/within, matched on age and interval")
    print(f"{'age band':>12} {'interval':>12} {'n_w':>5} {'n_b':>7} "
          f"{'within':>7} {'between':>8} {'R':>6} {'95% CI':>16}")
    for r in rows:
        print(f"{r['age_lo']:>5.0f}-{r['age_hi']:<6.0f} "
              f"{r['dt_lo']:>5.0f}-{r['dt_hi']:<6.0f} "
              f"{r['n_within']:>5d} {r['n_between']:>7d} "
              f"{r['within']:>7.3f} {r['between']:>8.3f} "
              f"{r['ratio']:>6.2f}  [{r['lo']:.2f}, {r['hi']:.2f}]")

    with open(os.path.join(args.out_dir, "strata.json"), "w") as f:
        json.dump({"cohorts": cohort_info, "cells": rows,
                   "n_subjects": k, "n_boot": args.boot}, f, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out_dir, "strata.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["age_lo", "age_hi", "dt_lo", "dt_hi", "n_within", "n_between",
                    "within_dist", "between_dist", "R", "lo95", "hi95", "p",
                    "within_lo95", "within_hi95", "between_lo95", "between_hi95"])
        for r in rows:
            w.writerow([r["age_lo"], r["age_hi"], r["dt_lo"], r["dt_hi"],
                        r["n_within"], r["n_between"],
                        round(r["within"], 4), round(r["between"], 4),
                        round(r["ratio"], 4), round(r["lo"], 4), round(r["hi"], 4),
                        round(r["p"], 4),
                        round(r["within_lo"], 4), round(r["within_hi"], 4),
                        round(r["between_lo"], 4), round(r["between_hi"], 4)])
    print(f"\nwrote {args.out_dir}/strata.json and strata.csv")


if __name__ == "__main__":
    main()
