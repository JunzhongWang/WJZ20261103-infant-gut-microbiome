#!/usr/bin/env Rscript
# ---------------------------------------------------------------------------
# fetch_cmd3.R — export cMD3 study abundance matrices to plain TSV
#
# Run this on a machine with unrestricted internet access (the sandbox that
# produced this project could not resolve bioconductorhubs.blob.core.windows.net,
# which is where ExperimentHub stores the assay data).
#
#   Rscript fetch_cmd3.R            # all cohorts below
#   Rscript fetch_cmd3.R VatanenT_2016
#
# Output, per study, under ./data/<study>/ :
#   species.tsv   samples x species, relative abundance, first column sample_id
#   meta.tsv      sample_id, subject_id, study, days, abx
#
# Then:  python3 pipeline/infant_pipeline.py analyze --dir data/<study>
# ---------------------------------------------------------------------------

suppressPackageStartupMessages({
  if (!requireNamespace("BiocManager", quietly = TRUE)) {
    install.packages("BiocManager", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("curatedMetagenomicData", quietly = TRUE)) {
    BiocManager::install("curatedMetagenomicData", update = FALSE, ask = FALSE)
  }
  library(curatedMetagenomicData)
})

args     <- commandArgs(trailingOnly = TRUE)
default  <- c("VatanenT_2016", "BackhedF_2015", "ShaoY_2019", "YassourM_2018")
studies  <- if (length(args) > 0) args else default
INFANTS_ONLY <- TRUE     # keep age_category == "newborn" or age < 2 years
OUTDIR   <- "data"

dir.create(OUTDIR, showWarnings = FALSE, recursive = TRUE)

for (study in studies) {
  message("\n=== ", study, " ===")
  res <- try(
    curatedMetagenomicData(paste0(study, ".relative_abundance"), dryrun = FALSE),
    silent = TRUE
  )
  if (inherits(res, "try-error") || length(res) == 0) {
    message("  could not fetch: ", conditionMessage(attr(res, "condition")))
    next
  }
  x  <- res[[1]]
  m  <- as.matrix(SummarizedExperiment::assay(x))
  cd <- as.data.frame(SummarizedExperiment::colData(x))

  # MetaPhlAn3 row names look like "k__Bacteria|p__...|s__Bifidobacterium_longum"
  sp <- sub(".*\\|s__", "", rownames(m))
  sp <- sub(".*\\|g__", "g__", sp)          # species-unresolved rows keep genus
  rownames(m) <- make.unique(sp)

  sid_col <- if ("sample_id" %in% names(cd)) cd$sample_id else rownames(cd)
  get_col <- function(nm, default = NA) if (nm %in% names(cd)) cd[[nm]] else rep(default, nrow(cd))

  meta <- data.frame(
    sample_id  = sid_col,
    subject_id = get_col("subject_id"),
    study      = study,
    days       = get_col("days_from_first_collection"),
    abx        = ifelse(tolower(as.character(get_col("antibiotics_current_use", "no"))) == "yes", 1L, 0L),
    age        = get_col("age"),
    age_cat    = get_col("age_category"),
    stringsAsFactors = FALSE
  )

  if (INFANTS_ONLY) {
    keep <- (!is.na(meta$age_cat) & meta$age_cat == "newborn") |
            (!is.na(meta$age) & meta$age < 2)
    keep[is.na(keep)] <- FALSE
    meta <- meta[keep, , drop = FALSE]
  }
  meta <- meta[!is.na(meta$days), , drop = FALSE]
  if (nrow(meta) < 3) {
    message("  only ", nrow(meta), " usable samples after filtering, skipped")
    next
  }

  m  <- m[, meta$sample_id, drop = FALSE]
  df <- as.data.frame(t(m), check.names = FALSE)
  df <- cbind(sample_id = rownames(df), df)

  out <- file.path(OUTDIR, study)
  dir.create(out, showWarnings = FALSE, recursive = TRUE)
  write.table(df,   file.path(out, "species.tsv"), sep = "\t",
              quote = FALSE, row.names = FALSE)
  write.table(meta[, c("sample_id", "subject_id", "study", "days", "abx")],
              file.path(out, "meta.tsv"), sep = "\t",
              quote = FALSE, row.names = FALSE)

  message(sprintf("  wrote %d samples x %d taxa  ->  %s",
                  nrow(df), ncol(df) - 1, out))
  message(sprintf("  subjects: %d | with >=3 visits: %d",
                  length(unique(meta$subject_id)),
                  sum(table(meta$subject_id) >= 3)))
}

message("\nDone. Next: python3 pipeline/infant_pipeline.py analyze --dir data/<study>")
