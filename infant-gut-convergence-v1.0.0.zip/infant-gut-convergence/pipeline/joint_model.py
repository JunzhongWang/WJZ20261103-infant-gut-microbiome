#!/usr/bin/env python3
"""Joint model for age and sampling interval in infant gut microbiome distances.

DESIGN
------
Every pair of samples contributes one row. Strictly within-subject pairs and
between-subject pairs are fitted separately, each with

    log D = b0 + b_study
            + b1 log(age) + b2 log(age)^2
            + b3 log(dt) + b4 log(age) log(dt)

`dt` is the gap between the two samples and `age` the age of the older one. The
squared term is not decoration: the age profile of within-subject distance is
U-shaped in log age (steep decline through the first months, minimum around five
to six months, slow rise afterwards), and a linear term forces the two limbs to
share one slope. identify.py, which stratifies instead of modelling, shows the
same shape.

The quantity of interest is the ratio

    R(age, dt) = exp[ f_between(age, dt) - f_within(age, dt) ]

i.e. how much farther an infant sits from a stranger than from itself. R is
what "individual signature" claims are about, and it is a function of both
arguments. Because f is linear in log(dt) given age, R is monotone in dt and we
can solve R = 1 for the interval at which an infant becomes indistinguishable
from its peers: the self-recognition horizon.

A naive model that drops log(dt) is also fitted. It is what a cross-sectional
comparison does implicitly, and the contrast between the two is the point of
the paper.

INFERENCE
---------
Pairs that share a subject are not independent, so uncertainty comes from a
cluster bootstrap over subjects; both models are refitted in the same replicate
and the covariance propagates into R. Leave-one-cohort-out refits, and separate
fits to the dense and sparse cohort subsets, test whether one sampling design
drives the answer.

    python3 pipeline/joint_model.py --boot 1000
"""
import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decay_model import load, bray, STUDIES  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N_BETWEEN = 40000
AGE_GRID = [14, 30, 60, 90, 120, 180, 270, 365, 545, 730]
DT_GRID = [7, 14, 30, 90, 180, 365]
AGE_CURVE = [7, 14, 21, 30, 45, 60, 90, 120, 180, 240, 300, 365, 450, 545, 640, 730]
MIN_CELL = 30
HORIZON_DT = [3650, 1825, 1095, 730, 365, 180, 90, 60, 30, 21, 14]


# --------------------------------------------------------------- linear algebra
def solve(A, b):
    n = len(b)
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[p][c]) < 1e-10:
            return None
        M[c], M[p] = M[p], M[c]
        piv = M[c][c]
        for r in range(c + 1, n):
            f = M[r][c] / piv
            if f:
                for k in range(c, n + 1):
                    M[r][k] -= f * M[c][k]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        acc = M[r][n] - sum(M[r][k] * x[k] for k in range(r + 1, n))
        x[r] = acc / M[r][r]
    return x


def wls(X, y, w):
    p = len(X[0])
    A = [[0.0] * p for _ in range(p)]
    b = [0.0] * p
    for xi, yi, wi in zip(X, y, w):
        if not wi:
            continue
        for a in range(p):
            if xi[a] == 0.0:
                continue
            wa = wi * xi[a]
            b[a] += wa * yi
            for c in range(a, p):
                if xi[c]:
                    A[a][c] += wa * xi[c]
    for a in range(p):
        for c in range(a):
            A[a][c] = A[c][a]
    return solve(A, b)


# ------------------------------------------------------------------- pair sets
def build(si, rel, age, subj, seed, min_dt, n_between=N_BETWEEN):
    by = {}
    for i, s in enumerate(subj):
        by.setdefault(s, []).append(i)
    W, Wlab = [], []
    for s, ii in by.items():
        ii = sorted(ii, key=lambda k: age[k])
        for a in range(len(ii)):
            for b in range(a + 1, len(ii)):
                i, j = ii[a], ii[b]
                dt = age[j] - age[i]
                if dt < min_dt:
                    continue
                d = bray(rel[i], rel[j])
                if d <= 0:
                    continue
                W.append((math.log(d), math.log(max(age[j], 1.0)), math.log(dt), si))
                Wlab.append((si, s))
    rng = random.Random(seed)
    keys = list(by)
    B, Ba, Bb = [], [], []
    for _ in range(n_between):
        s1, s2 = rng.sample(keys, 2)
        i, j = rng.choice(by[s1]), rng.choice(by[s2])
        if age[i] > age[j]:
            i, j = j, i
        dt = age[j] - age[i]
        if dt < min_dt:
            continue
        d = bray(rel[i], rel[j])
        if d <= 0:
            continue
        B.append((math.log(d), math.log(max(age[j], 1.0)), math.log(dt), si))
        Ba.append((si, s1))
        Bb.append((si, s2))
    return W, Wlab, B, Ba, Bb, len(by)


def design(rows, n_study, quad=True, interval=True):
    """[1, la, ld, la^2, la*ld, study dummies]; unrequested terms are omitted so
    the reduced models stay full rank."""
    X = []
    for _, la, ld, si in rows:
        x = [1.0, la]
        if interval:
            x.append(ld)
        if quad:
            x.append(la * la)
        if interval:
            x.append(la * ld)
        base = len(x)
        x += [0.0] * (n_study - 1)
        if si > 0:
            x[base - 1 + si] = 1.0
        X.append(x)
    return X


def fval(c, la, ld, quad=True, interval=True):
    v = c[0] + c[1] * la
    k = 2
    if interval:
        v += c[k] * ld
        k += 1
    if quad:
        v += c[k] * la * la
        k += 1
    if interval:
        v += c[k] * la * ld
    return v


def age_slope(c, la, ld, quad=True, interval=True):
    """d log D / d log(age) at this age and interval."""
    s = c[1]
    k = 2
    if interval:
        k += 1
    if quad:
        s += 2 * c[k] * la
        k += 1
    if interval:
        s += c[k] * ld
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", default=STUDIES)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--min-dt", type=int, default=7)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    studies = args.studies
    nS = len(studies)
    print(f"building pairs (minimum interval {args.min_dt} d)")
    W, Wlab, B, Ba, Bb = [], [], [], [], []
    cohorts = {}
    for si, study in enumerate(studies):
        rel, age, subj = load(study)
        w, wl, b, ba, bb, nsub = build(si, rel, age, subj, 17 + si, args.min_dt)
        W += w; Wlab += wl; B += b; Ba += ba; Bb += bb
        cohorts[study] = {"n_samples": len(age), "n_subjects": nsub,
                          "n_within": len(w), "n_between": len(b),
                          "age_min": min(age), "age_max": max(age)}
        print(f"  {study:<16} {len(age):5d} samples {nsub:4d} subjects "
              f"{len(w):5d} within {len(b):6d} between", flush=True)

    Xw, Xb = design(W, nS), design(B, nS)
    yw, yb = [r[0] for r in W], [r[0] for r in B]
    cw = wls(Xw, yw, [1.0] * len(W))
    cb = wls(Xb, yb, [1.0] * len(B))
    # reduced models, for the model-selection table
    lin_w = wls(design(W, nS, quad=False), yw, [1.0] * len(W))
    lin_b = wls(design(B, nS, quad=False), yb, [1.0] * len(B))
    add_w = wls(design(W, nS, quad=False, interval=False), yw, [1.0] * len(W))
    add_b = wls(design(B, nS, quad=False, interval=False), yb, [1.0] * len(B))
    # naive: age only (quadratic), interval dropped
    nv_w = wls(design(W, nS, interval=False), yw, [1.0] * len(W))
    nv_b = wls(design(B, nS, interval=False), yb, [1.0] * len(B))
    if None in (cw, cb, lin_w, lin_b, add_w, add_b, nv_w, nv_b):
        raise SystemExit("a model did not converge")

    print("\nprimary model (age quadratic + age x interval, study fixed effects)")
    print(f"  within : b_age {cw[1]:+.3f}  b_dt {cw[2]:+.3f}  b_age2 {cw[3]:+.3f}"
          f"  b_age*dt {cw[4]:+.3f}")
    print(f"  between: b_age {cb[1]:+.3f}  b_dt {cb[2]:+.3f}  b_age2 {cb[3]:+.3f}"
          f"  b_age*dt {cb[4]:+.3f}")
    print(f"  naive   : within b_age {nv_w[1]:+.3f} b_age2 {nv_w[2]:+.3f} | "
          f"between b_age {nv_b[1]:+.3f} b_age2 {nv_b[2]:+.3f}")

    # ---- cluster bootstrap
    subs = list(dict.fromkeys([l for l in Wlab] + list(Ba) + list(Bb)))
    pos = {s: i for i, s in enumerate(subs)}
    k = len(subs)
    wi = [pos[l] for l in Wlab]
    bi = [pos[a] for a in Ba]
    bj = [pos[b] for b in Bb]
    rng = random.Random(2027)

    cells = [(a, d) for a in AGE_GRID for d in DT_GRID]
    curve = [(a, d) for a in AGE_CURVE for d in (7, 30, 90)]
    grid = [(math.log(a), math.log(d)) for a, d in cells]
    cgrid = [(math.log(a), math.log(d)) for a, d in curve]

    def surface(cw_, cb_):
        return [fval(cb_, la, ld) - fval(cw_, la, ld) for la, ld in grid]

    def curves(cw_, cb_):
        return [fval(cb_, la, ld) - fval(cw_, la, ld) for la, ld in cgrid]

    def horizon(cw_, cb_):
        """Interval at which R = 1, for each age in AGE_GRID."""
        out = []
        for a in AGE_GRID:
            la = math.log(a)
            found = None
            for d in HORIZON_DT:
                ld = math.log(d)
                if fval(cb_, la, ld) - fval(cw_, la, ld) <= 0:
                    found = d
                    break
            out.append(found)
        return out

    point = surface(cw, cb)
    point_curve = curves(cw, cb)
    point_h = horizon(cw, cb)
    boots, boot_curve, boot_h, boot_slopes = [], [], [], {}
    for it in range(args.boot):
        m = [0] * k
        for _ in range(k):
            m[rng.randrange(k)] += 1
        rw = wls(Xw, yw, [m[i] for i in wi])
        rb = wls(Xb, yb, [m[i] * m[j] for i, j in zip(bi, bj)])
        if rw and rb:
            boots.append(surface(rw, rb))
            boot_curve.append(curves(rw, rb))
            boot_h.append(horizon(rw, rb))
            boot_slopes.setdefault("within", []).append(
                [age_slope(rw, math.log(a), math.log(30)) for a in AGE_GRID])
            boot_slopes.setdefault("between", []).append(
                [age_slope(rb, math.log(a), math.log(30)) for a in AGE_GRID])
        if (it + 1) % 200 == 0:
            print(f"  bootstrap {it + 1}/{args.boot}", flush=True)
    if len(boots) < 50:
        raise SystemExit("too few bootstrap replicates")

    def support(a, d):
        la, ld = math.log(a), math.log(d)
        return sum(1 for _, x, y, _ in W
                   if abs(x - la) < 0.4 and abs(y - ld) < 0.4)

    rows = []
    for idx, (a, d) in enumerate(cells):
        v = [b[idx] for b in boots]
        lo, hi = statistics.quantiles(v, n=40)[0], statistics.quantiles(v, n=40)[-1]
        rows.append({"age": a, "dt": d, "feasible": d <= a, "support": support(a, d),
                     "log_ratio": point[idx], "ratio": math.exp(point[idx]),
                     "lo": math.exp(lo), "hi": math.exp(hi),
                     "p": math.erfc(abs(point[idx] / statistics.pstdev(v)) / math.sqrt(2))
                     if statistics.pstdev(v) > 0 else 1.0})

    print("\nR = between/within Bray-Curtis distance  (rows age, cols interval)")
    print("   age\\dt " + "".join(f"{d:>9}d" for d in DT_GRID))
    for a in AGE_GRID:
        out = []
        for c in rows:
            if c["age"] != a:
                continue
            if not c["feasible"]:
                out.append(f"{'--':>9} ")
            else:
                out.append(f"{c['ratio']:>8.2f}"
                           f"{'*' if c['support'] < MIN_CELL else ' '} ")
        print(f"   {a:>5}d " + "".join(out))

    cw_curve = []
    for idx, (a, d) in enumerate(curve):
        v = [b[idx] for b in boot_curve]
        cw_curve.append({"age": a, "dt": d, "ratio": math.exp(point_curve[idx]),
                         "lo": math.exp(statistics.quantiles(v, n=40)[0]),
                         "hi": math.exp(statistics.quantiles(v, n=40)[-1])})

    print("\nself-recognition horizon (interval at which R falls through 1):")
    hor = {}
    for idx, a in enumerate(AGE_GRID):
        vals = [h[idx] for h in boot_h if h[idx] is not None]
        hor[a] = {"point": point_h[idx],
                  "lo": min(vals) if vals else None,
                  "hi": max(vals) if vals else None,
                  "n_boot": len(vals)}
        pt = point_h[idx] if point_h[idx] else ">3650"
        print(f"   age {a:>4}d : {pt} d  (bootstrap {hor[a]['lo']}-{hor[a]['hi']} d)")

    print("\nage slope of log distance at a 30-day interval")
    for j, a in enumerate(AGE_GRID):
        wv = [s[j] for s in boot_slopes["within"]]
        bv = [s[j] for s in boot_slopes["between"]]
        print(f"   age {a:>4}d  within {age_slope(cw, math.log(a), math.log(30)):+.3f} "
              f"[{statistics.quantiles(wv, n=40)[0]:+.2f},"
              f"{statistics.quantiles(wv, n=40)[-1]:+.2f}]   "
              f"between {age_slope(cb, math.log(a), math.log(30)):+.3f}")

    # ---- subset fits
    def refit(keep_studies):
        idx = {studies.index(name): j for j, name in enumerate(keep_studies)}
        kw = [(r[0], r[1], r[2], idx[r[3]]) for r in W if r[3] in idx]
        kb = [(r[0], r[1], r[2], idx[r[3]]) for r in B if r[3] in idx]
        if not kw or not kb:
            return None
        rw = wls(design(kw, len(idx)), [r[0] for r in kw], [1.0] * len(kw))
        rb = wls(design(kb, len(idx)), [r[0] for r in kb], [1.0] * len(kb))
        if not rw or not rb:
            return None
        return {"b_dt_within": rw[2], "b_age_at_30d_18m": age_slope(rw, math.log(545), math.log(30)),
                "b_age_at_30d_1m": age_slope(rw, math.log(30), math.log(30)),
                "decay_30d_1m": age_slope(rb, math.log(30), math.log(30))
                - age_slope(rw, math.log(30), math.log(30)),
                "decay_30d_18m": age_slope(rb, math.log(545), math.log(30))
                - age_slope(rw, math.log(545), math.log(30))}

    loo = {}
    print("\nleave-one-cohort-out:")
    for si, study in enumerate(studies):
        r = refit([s for j, s in enumerate(studies) if j != si])
        if r:
            loo[study] = r
            print(f"   -{study:<16} b_dt_within {r['b_dt_within']:+.3f}  "
                  f"age slope at 1 mo {r['b_age_at_30d_1m']:+.3f}  "
                  f"at 18 mo {r['b_age_at_30d_18m']:+.3f}")

    from decay_model import DENSE
    dense = [s for s in studies if s in DENSE]
    sparse = [s for s in studies if s not in DENSE]
    design_sets = {}
    print("\ndesign subsets:")
    for tag, subset in (("all", studies), ("dense_only", dense), ("sparse_only", sparse)):
        r = refit(subset)
        if r:
            design_sets[tag] = r
            print(f"   [{tag:<11}] b_dt_within {r['b_dt_within']:+.3f}  "
                  f"age slope at 1 mo {r['b_age_at_30d_1m']:+.3f}  "
                  f"at 18 mo {r['b_age_at_30d_18m']:+.3f}")

    out = {"cohorts": cohorts, "n_within": len(W), "n_between": len(B),
           "n_subjects": k, "n_boot": len(boots), "min_dt": args.min_dt,
           "primary": {"within": {"b_age": cw[1], "b_dt": cw[2],
                                  "b_age2": cw[3], "b_axd": cw[4]},
                       "between": {"b_age": cb[1], "b_dt": cb[2],
                                   "b_age2": cb[3], "b_axd": cb[4]}},
           "reduced": {"linear_interval": {"within": lin_w[1:5], "between": lin_b[1:5]},
                       "age_quadratic_only": {"within": add_w[1:4], "between": add_b[1:4]}},
           "naive": {"within_b_age": nv_w[1], "within_b_age2": nv_w[2],
                     "between_b_age": nv_b[1], "between_b_age2": nv_b[2],
                     "decay_at_30d_1m": age_slope(nv_b, math.log(30), math.log(30), True, False)
                     - age_slope(nv_w, math.log(30), math.log(30), True, False),
                     "decay_at_30d_18m": age_slope(nv_b, math.log(545), math.log(545), True, False)
                     - age_slope(nv_w, math.log(545), math.log(545), True, False)},
           "surface": rows, "curve": cw_curve, "horizon": hor,
           "leave_one_out": loo, "design_sets": design_sets}
    with open(os.path.join(args.out_dir, "joint_model.json"), "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    with open(os.path.join(args.out_dir, "joint_surface.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["age_days", "dt_days", "feasible", "n_support",
                    "ratio", "lo95", "hi95", "p"])
        for c in rows:
            w.writerow([c["age"], c["dt"], c["feasible"], c["support"],
                        round(c["ratio"], 4), round(c["lo"], 4), round(c["hi"], 4),
                        round(c["p"], 4)])
    with open(os.path.join(args.out_dir, "joint_curve.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["age_days", "dt_days", "ratio", "lo95", "hi95"])
        for c in cw_curve:
            w.writerow([c["age"], c["dt"], round(c["ratio"], 4),
                        round(c["lo"], 4), round(c["hi"], 4)])
    print(f"\nwrote {args.out_dir}/joint_model.json, joint_surface.csv, joint_curve.csv")

    # naive decay for the contrast figure
    print(f"\nnaive (interval-blind) decay at 1 mo: {out['naive']['decay_at_30d_1m']:+.3f}; "
          f"at 18 mo: {out['naive']['decay_at_30d_18m']:+.3f}")


if __name__ == "__main__":
    main()
