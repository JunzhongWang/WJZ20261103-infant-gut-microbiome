#!/usr/bin/env python3
"""Submission figures (English labels, 680 px wide vector panels).

fig1_cohorts.svg   sampling design of the seven cohorts
fig2_ratio.svg     R, the between/within distance ratio, against sampling interval
fig3_dist.svg      within- and between-subject distance against interval
fig4_icc.svg       species-level individual signature across cohorts
"""
import csv
import json
import math
import os
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "real")
INK, MUTED, GRID, PAPER = "#1a1a18", "#6b6a65", "#e6e8e6", "#ffffff"
FONT = "'Helvetica Neue', Arial, sans-serif"

ORDER = ["ShaoY_2019", "VatanenT_2016", "BackhedF_2015", "YassourM_2018",
         "KosticAD_2015", "FerrettiP_2018", "BrooksB_2017"]
NAME = {
    "ShaoY_2019": "Shao 2019",
    "VatanenT_2016": "Vatanen 2016 (DIABIMMUNE)",
    "BackhedF_2015": "Bäckhed 2015",
    "YassourM_2018": "Yassour 2018",
    "KosticAD_2015": "Kostic 2015 (TEDDY)",
    "FerrettiP_2018": "Ferretti 2018",
    "BrooksB_2017": "Brooks 2017",
}
COLOR = {
    "ShaoY_2019": "#C2703A",
    "VatanenT_2016": "#0F6E56",
    "BackhedF_2015": "#3C6E9F",
    "YassourM_2018": "#8A6FA8",
    "KosticAD_2015": "#B03A48",
    "FerrettiP_2018": "#7A8B2F",
    "BrooksB_2017": "#4C4C4C",
}
BANDS = [(0, 30, "0–1 mo"), (30, 90, "1–3 mo"), (90, 180, "3–6 mo"),
         (180, 365, "6–12 mo"), (365, 800, "1–2 y"), (800, 1e9, ">2 y")]
BAND_COLOR = ["#0F6E56", "#3C6E9F", "#7A8B2F", "#C2703A", "#8A6FA8", "#4C4C4C"]


def head(w, h, title, desc):
    return [f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
            f'role="img" width="100%">',
            f'<rect width="{w}" height="{h}" fill="{PAPER}"/>',
            f'<title>{title}</title><desc>{desc}</desc>',
            f'<g font-family="{FONT}">']


def axis(x0, y0, w, h, xticks, yticks, xlab, ylab, logx=False, xr=(1, 1000),
         yr=(0, 1)):
    s = []
    s.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" '
             f'stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y0+h}" '
             f'stroke="{MUTED}" stroke-width="0.8"/>')
    if logx:
        a, b = math.log10(xr[0]), math.log10(xr[1])
        f = lambda v: x0 + (math.log10(max(v, xr[0])) - a) / (b - a) * w
    else:
        f = lambda v: x0 + (v - xr[0]) / (xr[1] - xr[0]) * w
    g = lambda v: y0 + h - (v - yr[0]) / (yr[1] - yr[0]) * h
    for t in yticks:
        s.append(f'<line x1="{x0}" y1="{g(t):.1f}" x2="{x0+w}" y2="{g(t):.1f}" '
                 f'stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x0-7}" y="{g(t)+3:.1f}" font-size="8.5" '
                 f'fill="{MUTED}" text-anchor="end">{t:g}</text>')
    for t, lab in xticks:
        s.append(f'<line x1="{f(t):.1f}" y1="{y0+h}" x2="{f(t):.1f}" '
                 f'y2="{y0+h+3.5}" stroke="{MUTED}" stroke-width="0.8"/>')
        s.append(f'<text x="{f(t):.1f}" y="{y0+h+15}" font-size="8.5" '
                 f'fill="{MUTED}" text-anchor="middle">{lab}</text>')
    s.append(f'<text x="{x0+w/2}" y="{y0+h+32}" font-size="9.5" fill="{INK}" '
             f'text-anchor="middle">{xlab}</text>')
    s.append(f'<text transform="translate({x0-42},{y0+h/2}) rotate(-90)" '
             f'font-size="9.5" fill="{INK}" text-anchor="middle">{ylab}</text>')
    return s, f, g


# ---------------------------------------------------------------- figure 1
def fig_cohorts():
    rows = list(csv.DictReader(open(os.path.join(OUT, "table1.csv"))))
    rows.sort(key=lambda r: ORDER.index(r["study"]))
    W, H = 680, 300
    x0, y0, w, h = 168, 46, 448, 204
    s = head(W, H, "Figure 1. Sampling design of the seven infant cohorts",
             "Each dot is one stool sample placed at the infant's age on a log "
             "axis; cohorts sorted by median interval between visits.")
    s.append(f'<text x="30" y="24" font-size="11.5" font-weight="600" '
             f'fill="{INK}">Seven cohorts, 3,142 samples, 947 infants</text>')
    s.append(f'<text x="30" y="38" font-size="8.8" fill="{MUTED}">'
             f'Dot = one sample at that age; bar = interquartile range of ages; '
             f'right labels give samples / infants / median interval</text>')

    ticks = [(0, "birth"), (7, "1 wk"), (30, "1 mo"), (90, "3 mo"),
             (180, "6 mo"), (365, "1 y"), (730, "2 y"), (1100, "3 y")]
    sx, fx, fy = axis(x0, y0, w, h, ticks, [], "Age at sampling (log scale)",
                      "", logx=True, xr=(1, 1200))
    s += sx
    step = h / len(rows)
    for i, r in enumerate(rows):
        cy = y0 + step * (i + 0.5)
        col = COLOR[r["study"]]
        s.append(f'<text x="{x0-10}" y="{cy+3:.1f}" font-size="9" fill="{INK}" '
                 f'text-anchor="end">{NAME[r["study"]]}</text>')
        s.append(f'<text x="{x0-10}" y="{cy+13:.1f}" font-size="7.6" '
                 f'fill="{MUTED}" text-anchor="end">{r["country"]}</text>')
        lo, hi = float(r["age_min_d"]), float(r["age_max_d"])
        s.append(f'<rect x="{fx(max(lo,1)):.1f}" y="{cy-7:.1f}" '
                 f'width="{max(fx(hi)-fx(max(lo,1)),1):.1f}" height="14" '
                 f'fill="{col}" opacity="0.14" rx="2"/>')
        # sample rug: deterministic spread inside the band
        n = int(r["n_samples"])
        k = min(n, 110)
        for j in range(k):
            v = lo + (hi - lo) * ((j + 0.5) / k)
            yy = cy + (-3.5 if j % 2 == 0 else 3.5) * 0.85
            s.append(f'<circle cx="{fx(max(v,1)):.1f}" cy="{yy:.1f}" r="1.15" '
                     f'fill="{col}" opacity="0.62"/>')
        s.append(f'<text x="{x0+w+14}" y="{cy+1:.1f}" font-size="8.2" '
                 f'fill="{INK}">{r["n_samples"]} / {r["n_subjects"]}</text>')
        s.append(f'<text x="{x0+w+14}" y="{cy+11:.1f}" font-size="7.6" '
                 f'fill="{MUTED}">gap {r["gap_median_d"]} d</text>')
    s.append(f'<text x="{x0+w+14}" y="{y0-6}" font-size="7.6" fill="{MUTED}">'
             f'n / infants</text>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig1_cohorts.svg"), "w").write("\n".join(s))


# ---------------------------------------------------------------- figure 2
def fig_ratio():
    cells = json.load(open(os.path.join(OUT, "strata.json")))["cells"]
    W, H = 680, 340
    x0, y0, w, h = 66, 52, 372, 224
    s = head(W, H, "Figure 2. Individual distinctiveness falls with the interval, "
                   "not with age",
             "R = mean between-subject Bray-Curtis distance divided by mean "
             "within-subject distance, in strata matched on age and interval.")
    s.append(f'<text x="30" y="26" font-size="11.5" font-weight="600" '
             f'fill="{INK}">R against the interval between two samples</text>')
    s.append(f'<text x="30" y="40" font-size="8.8" fill="{MUTED}">'
             f'R = 1 means an infant is no closer to itself than to a stranger; '
             f'one line per age band, shadow = 95% bootstrap CI</text>')
    ticks = [(1, "1"), (7, "7"), (30, "30"), (90, "90"), (180, "180"),
             (365, "365"), (730, "730")]
    yticks = [1.0, 1.5, 2.0, 2.5, 3.0]
    sx, fx, fy = axis(x0, y0, w, h, ticks, yticks,
                      "Interval between samples (days, log scale)",
                      "R (between ÷ within)", logx=True, xr=(1, 760),
                      yr=(0.9, 3.2))
    s += sx
    for bi, (lo, hi, lab) in enumerate(BANDS):
        pts = [c for c in cells if (c["age_lo"], c["age_hi"]) == (lo, hi)]
        if not pts:
            continue
        pts.sort(key=lambda c: math.sqrt(c["dt_lo"] * min(c["dt_hi"], 800)))
        # CI ribbon
        up = [(fx(math.sqrt(c["dt_lo"] * min(c["dt_hi"], 800))), fy(min(c["hi"], 3.2)))
              for c in pts]
        dn = [(fx(math.sqrt(c["dt_lo"] * min(c["dt_hi"], 800))), fy(max(c["lo"], 0.9)))
              for c in reversed(pts)]
        path = " ".join(f"{'M' if i == 0 else 'L'}{x:.1f},{y:.1f}"
                        for i, (x, y) in enumerate(up + dn))
        s.append(f'<path d="{path} Z" fill="{BAND_COLOR[bi]}" opacity="0.13"/>')
        for c in pts:
            cx = fx(math.sqrt(c["dt_lo"] * min(c["dt_hi"], 800)))
            s.append(f'<circle cx="{cx:.1f}" cy="{fy(min(c["ratio"], 3.2)):.1f}" '
                     f'r="2.7" fill="{BAND_COLOR[bi]}"/>')
    # legend
    lx, ly = x0 + w + 34, y0 + 8
    s.append(f'<text x="{lx}" y="{ly-4}" font-size="8.6" font-weight="600" '
             f'fill="{INK}">Age band</text>')
    for bi, (lo, hi, lab) in enumerate(BANDS):
        yy = ly + 12 + bi * 17
        s.append(f'<line x1="{lx}" y1="{yy}" x2="{lx+14}" y2="{yy}" '
                 f'stroke="{BAND_COLOR[bi]}" stroke-width="2"/>')
        s.append(f'<circle cx="{lx+7}" cy="{yy}" r="2.7" fill="{BAND_COLOR[bi]}"/>')
        s.append(f'<text x="{lx+20}" y="{yy+3}" font-size="8.4" fill="{INK}">'
                 f'{lab}</text>')
    s.append(f'<line x1="{x0}" y1="{fy(1):.1f}" x2="{x0+w}" y2="{fy(1):.1f}" '
             f'stroke="{INK}" stroke-width="0.7" stroke-dasharray="3 3"/>')
    s.append(f'<text x="{x0+4}" y="{fy(1)-5:.1f}" font-size="8" fill="{MUTED}">'
             f'R = 1 (no self-recognition)</text>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig2_ratio.svg"), "w").write("\n".join(s))


# ---------------------------------------------------------------- figure 3
def fig_dist():
    cells = json.load(open(os.path.join(OUT, "strata.json")))["cells"]
    W, H = 680, 340
    s = head(W, H, "Figure 3. Between-subject distance is invariant; "
                   "within-subject distance is not",
             "Mean Bray-Curtis distance in strata matched on age and interval.")
    s.append(f'<text x="30" y="26" font-size="11.5" font-weight="600" '
             f'fill="{INK}">Between- and within-subject distance against interval</text>')
    s.append(f'<text x="30" y="40" font-size="8.8" fill="{MUTED}">'
             f'Between-subject distance (dashed) barely moves with interval or age; '
             f'the within-subject distance (solid) does</text>')
    panels = [("Between-subject", "between"), ("Within-subject", "within")]
    pw, ph = 244, 190
    for pi, (title, key) in enumerate(panels):
        ox = 66 + pi * (pw + 86)
        oy = 74
        ticks = [(1, "1"), (7, "7"), (30, "30"), (90, "90"), (365, "365")]
        sx, fx, fy = axis(ox, oy, pw, ph, ticks, [0, 0.25, 0.5, 0.75, 1.0],
                          "Interval (days)", "Bray-Curtis distance",
                          logx=True, xr=(1, 500), yr=(0, 1))
        s += sx
        s.append(f'<text x="{ox}" y="{oy-12}" font-size="9.6" font-weight="600" '
                 f'fill="{INK}">{title}</text>')
        for bi, (lo, hi, lab) in enumerate(BANDS):
            pts = [c for c in cells if (c["age_lo"], c["age_hi"]) == (lo, hi)]
            if len(pts) < 2:
                continue
            col = BAND_COLOR[bi]
            d = " ".join(
                f"{'M' if i == 0 else 'L'}{fx(math.sqrt(c['dt_lo']*min(c['dt_hi'],500))):.1f},"
                f"{fy(min(math.exp(c[key]), 1.0)):.1f}"
                for i, c in enumerate(sorted(
                    pts, key=lambda c: math.sqrt(c["dt_lo"] * min(c["dt_hi"], 500)))))
            dash = ' stroke-dasharray="3 2.5"' if key == "between" else ""
            s.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.7"'
                     f'{dash} opacity="0.9"/>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig3_dist.svg"), "w").write("\n".join(s))


# ---------------------------------------------------------------- figure 4
def fig_icc():
    rows = list(csv.DictReader(open(os.path.join(OUT, "table_taxon.csv"))))
    cols = [c for c in rows[0] if c in ORDER]
    rows.sort(key=lambda r: -float(r["icc_median"]))
    W = 680
    ch, top = 15.5, 96
    H = top + len(rows) * ch + 58
    s = head(W, H, "Figure 4. Individual signature by species",
             "Intraclass correlation of centred-log-ratio abundance after "
             "removing the population age trend, per cohort.")
    s.append(f'<text x="30" y="26" font-size="11.5" font-weight="600" '
             f'fill="{INK}">Species-level individual signature</text>')
    s.append(f'<text x="30" y="40" font-size="8.8" fill="{MUTED}">'
             f'Intraclass correlation of CLR abundance after removing the '
             f'population age curve; blank = prevalence below 50% in that cohort</text>')
    x0, y0 = 214, top
    cw = (W - x0 - 46) / len(cols)
    for j, c in enumerate(cols):
        s.append(f'<text x="{x0+cw*(j+0.5):.1f}" y="{y0-8}" font-size="7.8" '
                 f'fill="{INK}" text-anchor="middle">{NAME[c].split(" (")[0]}</text>')
    for i, r in enumerate(rows):
        yy = y0 + i * ch
        if i % 2 == 0:
            s.append(f'<rect x="{x0}" y="{yy}" width="{W-x0-46}" height="{ch}" '
                     f'fill="#f6f7f6"/>')
        s.append(f'<text x="{x0-9}" y="{yy+ch*0.7:.1f}" font-size="8.4" '
                 f'fill="{INK}" text-anchor="end" font-style="italic">'
                 f'{r["taxon"]}</text>')
        for j, c in enumerate(cols):
            v = r[c]
            if v == "":
                continue
            val = float(v)
            op = 0.10 + 0.88 * min(val / 0.8, 1.0)
            s.append(f'<rect x="{x0+cw*j+1.5:.1f}" y="{yy+1.6:.1f}" '
                     f'width="{cw-3:.1f}" height="{ch-3:.1f}" rx="1.6" '
                     f'fill="#0F6E56" opacity="{op:.2f}"/>')
            if val >= 0.25:
                s.append(f'<text x="{x0+cw*(j+0.5):.1f}" y="{yy+ch*0.7:.1f}" '
                         f'font-size="7.4" fill="#ffffff" text-anchor="middle">'
                         f'{val:.2f}</text>')
        s.append(f'<text x="{W-40}" y="{yy+ch*0.7:.1f}" font-size="8.2" '
                 f'fill="{MUTED}">{float(r["icc_median"]):.2f}</text>')
    s.append(f'<text x="{W-40}" y="{y0-8}" font-size="7.8" fill="{INK}" '
             f'text-anchor="middle">median</text>')
    s.append('</g></svg>')
    open(os.path.join(OUT, "fig4_icc.svg"), "w").write("\n".join(s))


if __name__ == "__main__":
    fig_cohorts()
    fig_ratio()
    fig_dist()
    fig_icc()
    print("wrote fig1_cohorts.svg fig2_ratio.svg fig3_dist.svg fig4_icc.svg")
