#!/usr/bin/env python3
"""Separating age from recall window in the individual signature.

The descriptive ratio (between-subject / within-subject Bray-Curtis) confounds
two things. Early infancy is sampled densely, so "distance from myself" is
measured over short gaps; later infancy is sampled sparsely, so it is measured
over long gaps. A rising within-subject distance can mean the signature is
fading, or simply that we looked further back in time.

Every sample pair contributes one row

    log(D) = b0 + b_study + b1*log(age_later) + b2*log(dt) + e

with `age_later` the age of the older sample in the pair and `dt` the gap,
fitted separately to within- and between-subject pairs. b1 is the age effect at
a fixed recall window, and

    decay = b1_between - b1_within

is the quantity of interest: decay < 0 means between-subject distance grows
more slowly than within-subject distance, i.e. individuals become harder to
tell apart as they age.

Fitting per cohort does not work here: inside one cohort `log(age)` and
`log(dt)` are nearly collinear (ShaoY samples 4, 7, 12, 21 days and little
else; Yassour samples 0, 14, 30, 60, 90), so b1 and b2 trade off almost
exactly. The cohorts differ in sampling design, though, which is exactly the
variation needed to identify both terms. The primary analysis therefore pools
pairs across cohorts with study fixed effects, and the per-cohort fits are
reported as a heterogeneity check.

Uncertainty: cluster bootstrap over subjects (pairs sharing a subject are not
independent), refitting both models in the same replicate so their covariance
is carried into decay.

    python3 pipeline/decay_model.py --boot 1000
"""
import argparse
import csv
import json
import math
import os
import random
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MIN_DT = 7
N_BETWEEN = 40000
STUDIES = ["ShaoY_2019", "VatanenT_2016", "BackhedF_2015", "YassourM_2018",
           "KosticAD_2015", "FerrettiP_2018", "BrooksB_2017"]
# Dense-sampling cohorts: median >=4 visits per subject or <=15 d between visits.
# Listed so the manuscript can name them without re-deriving the rule.
DENSE = ["BrooksB_2017", "FerrettiP_2018", "KosticAD_2015"]


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def load(study):
    d = os.path.join(ROOT, "data", study)
    sp = read_csv(os.path.join(d, "community.csv"))
    meta = {r["sample_id"]: r for r in read_csv(os.path.join(d, "meta.csv"))}
    names = [c for c in sp[0] if c != "sample_id"]
    rel, age, subj = [], [], []
    for r in sp:
        m = meta.get(r["sample_id"])
        if not m:
            continue
        try:
            a = float(m["days"])
        except (KeyError, TypeError, ValueError):
            continue
        v = [float(r[n] or 0.0) for n in names]
        t = sum(v)
        if t <= 0:
            continue
        rel.append([x / t for x in v])
        age.append(a)
        subj.append(m["subject_id"])
    return rel, age, subj


def bray(a, b):
    num = den = 0.0
    for x, y in zip(a, b):
        d = x - y
        num += d if d >= 0 else -d
        den += x + y
    return num / den if den else 0.0


def pairs(rel, age, subj, seed=7, n_between=N_BETWEEN):
    by = {}
    for i, s in enumerate(subj):
        by.setdefault(s, []).append(i)
    within = []
    for s, ii in by.items():
        for a in range(len(ii)):
            for b in range(a + 1, len(ii)):
                i, j = ii[a], ii[b]
                dt = abs(age[i] - age[j])
                if dt < MIN_DT:
                    continue
                d = bray(rel[i], rel[j])
                if d > 0:
                    within.append((math.log(d), math.log(max(age[i], age[j])),
                                   math.log(dt), s))
    rng = random.Random(seed)
    keys = list(by)
    between = []
    for _ in range(n_between):
        s1, s2 = rng.sample(keys, 2)
        i = rng.choice(by[s1])
        j = rng.choice(by[s2])
        dt = abs(age[i] - age[j])
        if dt < MIN_DT:
            continue
        d = bray(rel[i], rel[j])
        if d > 0:
            between.append((math.log(d), math.log(max(age[i], age[j])),
                            math.log(dt), s1, s2))
    return within, between, by


# ------------------------------------------------------------ linear algebra


def solve_sym(M, v):
    """Gaussian elimination with partial pivoting on a small dense system."""
    n = len(v)
    A = [row[:] + [v[i]] for i, row in enumerate(M)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(A[r][c]))
        if abs(A[p][c]) < 1e-12:
            return None
        A[c], A[p] = A[p], A[c]
        piv = A[c][c]
        for r in range(c + 1, n):
            f = A[r][c] / piv
            if f:
                for k in range(c, n + 1):
                    A[r][k] -= f * A[c][k]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        acc = A[r][n] - sum(A[r][k] * x[k] for k in range(r + 1, n))
        x[r] = acc / A[r][r]
    return x


def wls3(rows, w):
    """Weighted LS of y on (1, x1, x2). rows = (y, x1, x2, ...)."""
    XtWX = [[0.0] * 3 for _ in range(3)]
    XtWy = [0.0] * 3
    for r, wi in zip(rows, w):
        if not wi:
            continue
        y = r[0]
        x1, x2 = r[1], r[2]
        XtWX[0][0] += wi
        XtWX[0][1] += wi * x1
        XtWX[0][2] += wi * x2
        XtWX[1][1] += wi * x1 * x1
        XtWX[1][2] += wi * x1 * x2
        XtWX[2][2] += wi * x2 * x2
        XtWy[0] += wi * y
        XtWy[1] += wi * x1 * y
        XtWy[2] += wi * x2 * y
    XtWX[1][0] = XtWX[0][1]
    XtWX[2][0] = XtWX[0][2]
    XtWX[2][1] = XtWX[1][2]
    if abs(XtWX[1][1]) < 1e-12:
        return None
    return solve_sym(XtWX, XtWy)


def wls_fe(rows, w, n_study=4):
    """Same model plus study fixed effects (study 0 as reference)."""
    p = 3 + (n_study - 1)
    XtWX = [[0.0] * p for _ in range(p)]
    XtWy = [0.0] * p
    for r, wi in zip(rows, w):
        if not wi:
            continue
        x = [1.0, r[1], r[2]] + [0.0] * (n_study - 1)
        si = r[3]
        if si > 0:
            x[2 + si] = 1.0
        y = r[0]
        for a in range(p):
            if x[a] == 0.0:
                continue
            xa = x[a] * wi
            XtWy[a] += xa * y
            for b in range(a, p):
                if x[b]:
                    XtWX[a][b] += xa * x[b]
    for a in range(p):
        for b in range(a):
            XtWX[a][b] = XtWX[b][a]
    return solve_sym(XtWX, XtWy)


def corr(xs, ys):
    mx, my = statistics.fmean(xs), statistics.fmean(ys)
    sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    sxx = math.sqrt(sum((a - mx) ** 2 for a in xs))
    syy = math.sqrt(sum((b - my) ** 2 for b in ys))
    return sxy / (sxx * syy) if sxx and syy else None


def dl(effects):
    e = [(l, y, s) for l, y, s in effects if s and s > 0]
    k = len(e)
    if k == 0:
        return None
    w = [1.0 / s ** 2 for _, _, s in e]
    sw = sum(w)
    yf = sum(wi * y for wi, (_, y, _) in zip(w, e)) / sw
    Q = sum(wi * (y - yf) ** 2 for wi, (_, y, _) in zip(w, e))
    df = k - 1
    C = sw - sum(wi * wi for wi in w) / sw
    tau2 = max(0.0, (Q - df) / C) if C > 0 else 0.0
    ws = [1.0 / (s ** 2 + tau2) for _, _, s in e]
    sws = sum(ws)
    p = sum(wi * y for wi, (_, y, _) in zip(ws, e)) / sws
    se = math.sqrt(1.0 / sws)
    I2 = max(0.0, (Q - df) / Q) if Q > 0 else 0.0
    if df > 0 and Q > 0:
        z = ((Q / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
        qp = math.erfc(abs(z) / math.sqrt(2))
    else:
        qp = 1.0
    return {"k": k, "pooled": p, "se": se, "ci95": [p - 1.96 * se, p + 1.96 * se],
            "p": math.erfc(abs(p / se) / math.sqrt(2)) if se else 1.0,
            "Q": Q, "Q_df": df, "Q_p": qp, "I2": I2, "tau2": tau2,
            "weights_pct": [100 * wi / sws for wi in ws],
            "labels": [l for l, _, _ in e]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", default=STUDIES)
    ap.add_argument("--boot", type=int, default=1000)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    W_rows, W_lab = [], []
    B_rows, B_a, B_b = [], [], []
    info = {}
    for si, study in enumerate(args.studies):
        rel, age, subj = load(study)
        wi, be, by = pairs(rel, age, subj)
        for (y, x1, x2, s) in wi:
            W_rows.append((y, x1, x2, si))
            W_lab.append((si, s))
        for (y, x1, x2, s1, s2) in be:
            B_rows.append((y, x1, x2, si))
            B_a.append((si, s1))
            B_b.append((si, s2))
        info[study] = {"n_samples": len(age), "n_subjects": len(by),
                       "n_within": len(wi), "n_between": len(be),
                       "age_min": min(age), "age_max": max(age)}
        print(f"== {study}: {len(age)} samples, {len(by)} subjects, "
              f"{len(wi)} within, {len(be)} between pairs "
              f"(age {min(age):.0f}-{max(age):.0f} d)", flush=True)

    ax = [r[1] for r in W_rows]
    ad = [r[2] for r in W_rows]
    bx = [r[1] for r in B_rows]
    bd = [r[2] for r in B_rows]
    print(f"\ncorr(log age, log dt): within {corr(ax, ad):+.3f} (n={len(ax)}), "
          f"between {corr(bx, bd):+.3f} (n={len(bx)})")

    ones_w = [1.0] * len(W_rows)
    ones_b = [1.0] * len(B_rows)
    cw = wls_fe(W_rows, ones_w, n_study=len(args.studies))
    cb = wls_fe(B_rows, ones_b, n_study=len(args.studies))
    if cw is None or cb is None:
        raise SystemExit("model did not converge")
    cw0 = wls3([(r[0], r[1], 0.0, r[3]) for r in W_rows], ones_w)
    cb0 = wls3([(r[0], r[1], 0.0, r[3]) for r in B_rows], ones_b)

    print("\npooled, study fixed effects, adjusted for recall window:")
    print(f"  within : b_age = {cw[1]:+.4f}  b_dt = {cw[2]:+.4f}")
    print(f"  between: b_age = {cb[1]:+.4f}  b_dt = {cb[2]:+.4f}")
    point = cb[1] - cw[1]
    print(f"  decay  = {point:+.4f}")

    # ---- cluster bootstrap over subjects; both models in the same replicate
    subj_all = list(dict.fromkeys([l for l in W_lab] + [a for a in B_a] +
                                  [b for b in B_b]))
    pos = {s: i for i, s in enumerate(subj_all)}
    k = len(subj_all)
    wi_a = [pos[l] for l in W_lab]
    bi_a = [pos[a] for a in B_a]
    bi_b = [pos[b] for b in B_b]

    rng = random.Random(99)
    boot = []
    for it in range(args.boot):
        m = [0] * k
        for _ in range(k):
            m[rng.randrange(k)] += 1
        rw = wls_fe(W_rows, [m[i] for i in wi_a], n_study=len(args.studies))
        rb = wls_fe(B_rows, [1.0 if (m[i] and m[j]) else 0.0
                             for i, j in zip(bi_a, bi_b)],
                    n_study=len(args.studies))
        if rw and rb:
            boot.append(rb[1] - rw[1])
        if (it + 1) % 200 == 0:
            print(f"  bootstrap {it + 1}/{args.boot}", flush=True)

    if len(boot) < 50:
        raise SystemExit("too few bootstrap replicates")
    se = statistics.pstdev(boot)
    qs = statistics.quantiles(boot, n=40)
    lo, hi = qs[0], qs[-1]
    pval = math.erfc(abs(point / se) / math.sqrt(2))
    print(f"\npooled decay = {point:+.4f}, bootstrap SE {se:.4f}, "
          f"95% CI [{lo:+.4f}, {hi:+.4f}], p = {pval:.4g}")
    print(f"  per doubling of age the between/within distance ratio changes by "
          f"{100 * (2 ** point - 1):+.1f}% "
          f"[{100 * (2 ** lo - 1):+.1f}, {100 * (2 ** hi - 1):+.1f}]")

    # ---- per-cohort fits, for heterogeneity only
    per = {}
    for si, study in enumerate(args.studies):
        wr = [r for r in W_rows if r[3] == si]
        br = [r for r in B_rows if r[3] == si]
        if len(wr) < 20 or len(br) < 500:
            continue
        labs = [l for l in W_lab if l[0] == si]
        ba = [a for a in B_a if a[0] == si]
        bb = [b for b in B_b if b[0] == si]
        uniq = list(dict.fromkeys(labs + ba + bb))
        p2 = {s: i for i, s in enumerate(uniq)}
        wa = [p2[l] for l in labs]
        xa = [p2[x] for x in ba]
        xb = [p2[x] for x in bb]
        rng2 = random.Random(1000 + si)
        bs = []
        for _ in range(max(200, args.boot // 2)):
            m = [0] * len(uniq)
            for _ in range(len(uniq)):
                m[rng2.randrange(len(uniq))] += 1
            rw = wls3(wr, [m[i] for i in wa])
            rb = wls3(br, [1.0 if (m[i] and m[j]) else 0.0
                           for i, j in zip(xa, xb)])
            if rw and rb:
                bs.append(rb[1] - rw[1])
        cw1 = wls3(wr, [1.0] * len(wr))
        cb1 = wls3(br, [1.0] * len(br))
        if not bs or not cw1 or not cb1:
            continue
        per[study] = {"b_within": cw1[1], "b_between": cb1[1],
                      "decay": cb1[1] - cw1[1],
                      "se": statistics.pstdev(bs), "n_boot": len(bs),
                      "b_dt_within": cw1[2], "b_dt_between": cb1[2],
                      "n_within": len(wr), "n_between": len(br)}
        print(f"  [cohort] {study}: b_within {cw1[1]:+.3f}, "
              f"b_between {cb1[1]:+.3f}, decay {cb1[1] - cw1[1]:+.3f} "
              f"+/- {statistics.pstdev(bs):.3f}")

    pooled = dl([(s, v["decay"], v["se"]) for s, v in per.items()])

    out = {"pooled_model": {"b_age_within": cw[1], "b_age_between": cb[1],
                            "b_dt_within": cw[2], "b_dt_between": cb[2],
                            "decay": point, "se": se, "ci95": [lo, hi],
                            "per_doubling": 2 ** point - 1,
                            "per_doubling_ci95": [2 ** lo - 1, 2 ** hi - 1],
                            "p": pval,
                            "n_within": len(W_rows), "n_between": len(B_rows),
                            "n_subjects": k, "n_boot": len(boot),
                            "corr_age_dt_within": corr(ax, ad),
                            "corr_age_dt_between": corr(bx, bd),
                            "unadjusted": {"b_age_within": cw0[1] if cw0 else None,
                                           "b_age_between": cb0[1] if cb0 else None}},
           "per_cohort": per, "heterogeneity": pooled, "cohorts": info}

    with open(os.path.join(args.out_dir, "decay_model.json"), "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    with open(os.path.join(args.out_dir, "decay_model.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["study", "n_within", "n_between", "b_age_within",
                    "b_age_between", "b_dt_within", "b_dt_between",
                    "decay", "se", "lo95", "hi95", "per_doubling"])
        for s, v in per.items():
            w.writerow([s, v["n_within"], v["n_between"],
                        round(v["b_within"], 4), round(v["b_between"], 4),
                        round(v["b_dt_within"], 4), round(v["b_dt_between"], 4),
                        round(v["decay"], 4), round(v["se"], 4),
                        round(v["decay"] - 1.96 * v["se"], 4),
                        round(v["decay"] + 1.96 * v["se"], 4),
                        round(2 ** v["decay"] - 1, 4)])
        w.writerow(["POOLED_MODEL", len(W_rows), len(B_rows),
                    round(cw[1], 4), round(cb[1], 4), round(cw[2], 4),
                    round(cb[2], 4), round(point, 4), round(se, 4),
                    round(lo, 4), round(hi, 4), round(2 ** point - 1, 4)])
        if pooled:
            w.writerow(["POOLED_RE", "", "", "", "", "", "",
                        round(pooled["pooled"], 4), round(pooled["se"], 4),
                        round(pooled["ci95"][0], 4), round(pooled["ci95"][1], 4),
                        round(2 ** pooled["pooled"] - 1, 4)])
    print(f"\nwrote {args.out_dir}/decay_model.json and decay_model.csv")
    if pooled:
        print(f"random-effects over cohorts: {pooled['pooled']:+.4f} "
              f"[{pooled['ci95'][0]:+.4f}, {pooled['ci95'][1]:+.4f}], "
              f"I2 = {100 * pooled['I2']:.0f}%")


if __name__ == "__main__":
    main()
