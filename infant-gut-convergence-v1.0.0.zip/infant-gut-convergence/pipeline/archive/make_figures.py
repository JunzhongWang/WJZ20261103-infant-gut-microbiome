#!/usr/bin/env python3
"""Generate the three result figures as standalone SVG (no plotting library)."""

import importlib.util
import json
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("ip", os.path.join(HERE, "infant_pipeline.py"))
ip = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ip)

INK = "#22221F"
MUTED = "#5F5E5A"
GRID = "#E2E0D8"
TEAL = "#0F6E56"
TEAL_MID = "#5DCAA5"
TEAL_LT = "#9FE1CB"
GRAY = "#888780"
AMBER = "#BA7517"


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def axes(x0, y0, w, h, xticks, yticks, xlabel, ylabel, xfmt=None, yfmt=None):
    out = [f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" stroke="{INK}" stroke-width="0.8"/>',
           f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y0+h}" stroke="{INK}" stroke-width="0.8"/>']
    for xv, xp, lab in xticks:
        out.append(f'<line x1="{xp:.1f}" y1="{y0+h}" x2="{xp:.1f}" y2="{y0+h+4}" stroke="{GRAY}" stroke-width="0.5"/>')
        out.append(f'<text x="{xp:.1f}" y="{y0+h+17}" text-anchor="middle" font-size="10" fill="{MUTED}">{esc(lab)}</text>')
    for yv, yp, lab in yticks:
        out.append(f'<line x1="{x0-4}" y1="{yp:.1f}" x2="{x0}" y2="{yp:.1f}" stroke="{GRAY}" stroke-width="0.5"/>')
        out.append(f'<text x="{x0-7}" y="{yp+3.5:.1f}" text-anchor="end" font-size="10" fill="{MUTED}">{esc(lab)}</text>')
        out.append(f'<line x1="{x0}" y1="{yp:.1f}" x2="{x0+w}" y2="{yp:.1f}" stroke="{GRID}" stroke-width="0.5" stroke-dasharray="2 3"/>')
    out.append(f'<text x="{x0+w/2:.1f}" y="{y0+h+36}" text-anchor="middle" font-size="10.5" fill="{MUTED}">{esc(xlabel)}</text>')
    out.append(f'<text x="{x0-38}" y="{y0+h/2:.1f}" font-size="10.5" fill="{MUTED}" transform="rotate(-90 {x0-38} {y0+h/2:.1f})" text-anchor="middle">{esc(ylabel)}</text>')
    return "\n".join(out)


def fig_trajectory(path):
    meta = [r for r in ip.read_csv(os.path.join(HERE, os.pardir, "infant_samples.csv"))
            if r.get("study_name") == "VatanenT_2016"]
    ids, names, counts, mrows, _ = ip.simulate_cohort(meta, seed=1, reads=20000)
    days = [m["days"] for m in mrows]
    y = [ip.shannon(c) for c in counts]
    subj = [m["subject_id"] for m in mrows]
    knots = [0.0, 180.0, 540.0]
    fit = ip.fit_population_curve(days, y, knots)

    W, H = 680, 300
    x0, y0, w, h = 78, 34, 552, 200
    xmax = 1100.0
    ymin, ymax = 1.0, 3.0

    def px(t):
        return x0 + min(t, xmax) / xmax * w

    def py(v):
        return y0 + h - (v - ymin) / (ymax - ymin) * h

    # binned means
    bins = [(0, 30), (30, 90), (90, 180), (180, 365), (365, 730), (730, 1100)]
    pts = []
    for lo, hi in bins:
        vals = [v for d, v in zip(days, y) if lo <= d < hi]
        if len(vals) >= 3:
            pts.append((px((lo + hi) / 2), py(statistics.fmean(vals)), len(vals),
                        statistics.fmean(vals)))

    grid = [i * 10 for i in range(0, 111)]
    curve = " ".join(f"{px(g):.1f},{py(fit['coef'][0] + sum(b * v for b, v in zip(fit['coef'][1:], ip.rcs_basis(g, knots)))):.1f}" for g in grid)

    xt = [(0, px(0), "0"), (182, px(182), "6 月"), (365, px(365), "1 年"), (730, px(730), "2 年"), (1095, px(1095), "3 年")]
    yt = [(v, py(v), f"{v:.1f}") for v in (1.0, 1.5, 2.0, 2.5, 3.0)]

    svg = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" role="img">',
           '<title>婴幼儿肠道菌群 Shannon 多样性的发育曲线</title>',
           '<desc>散点为单次采样，曲线为受限三次样条拟合的人群平均发育轨迹。</desc>',
           f'<g font-family="PingFang SC, sans-serif">']
    svg.append(axes(x0, y0, w, h, xt, yt, "采样时年龄", "Shannon 多样性"))
    for d, v in zip(days, y):
        svg.append(f'<circle cx="{px(d):.1f}" cy="{py(v):.1f}" r="1.6" fill="{GRAY}" opacity="0.30"/>')
    svg.append(f'<polyline points="{curve}" fill="none" stroke="{TEAL}" stroke-width="2.2"/>')
    for x, yy, n, v in pts:
        svg.append(f'<circle cx="{x:.1f}" cy="{yy:.1f}" r="4" fill="{TEAL_MID}" stroke="{TEAL}" stroke-width="0.8"/>')
    st = " ".join(f"{x:.0f},{yy:.0f}" for x, yy, n, v in pts)
    svg.append(f'<polyline points="{st}" fill="none" stroke="{TEAL_MID}" stroke-width="1.4" stroke-dasharray="4 3"/>')
    svg.append(f'<text x="{x0+8}" y="{y0+16}" font-size="10.5" fill="{MUTED}">n = {len(y)} 份样本 · {len(set(subj))} 名婴幼儿</text>')
    svg.append('</g></svg>')
    open(path, "w", encoding="utf-8").write("\n".join(svg))
    return {"n": len(y), "n_subj": len(set(subj)),
            "shannon_first": statistics.fmean([v for d, v in zip(days, y) if d < 30]),
            "slope": fit["coef"][1]}


def fig_recovery(path, vd):
    runs = [r for r in vd["runs"] if r.get("icc_adj_est") is not None]
    W, H = 680, 290
    panels = [("icc_adj_est", "icc_adj_true", "个体一致性 ICC（年龄校正）", 1),
              ("abx_est", "abx_true", "抗生素对 Shannon 的效应", 2)]
    svg = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" role="img">',
           '<title>30 次独立模拟中两个关键估计量的分布与真值</title>',
           '<desc>每个点为一次模拟的估计值，水平线为真实参数，阴影带为正负一个估计标准差。</desc>',
           f'<g font-family="PingFang SC, sans-serif">']
    for key, tkey, title, idx in panels:
        ox = 40 if idx == 1 else 352
        x0, y0, w, h = ox + 42, 52, 200, 150
        vals = [r[key] for r in runs if r.get(key) is not None]
        true = next((r[tkey] for r in runs if r.get(tkey) is not None), None)
        lo = min(vals + [true]) - 0.06
        hi = max(vals + [true]) + 0.06
        span = hi - lo

        def PY(v):
            return y0 + h - (v - lo) / span * h
        svg.append(f'<text x="{ox+18}" y="28" font-size="11" font-weight="500" fill="{INK}">{title}</text>')
        mean = statistics.fmean(vals)
        sd = statistics.pstdev(vals) if len(vals) > 1 else 0.0
        svg.append(f'<rect x="{x0}" y="{PY(mean+sd):.1f}" width="{w}" height="{max(PY(mean-sd)-PY(mean+sd),2):.1f}" fill="{TEAL_LT}" fill-opacity="0.45"/>')
        svg.append(f'<line x1="{x0}" y1="{PY(true):.1f}" x2="{x0+w}" y2="{PY(true):.1f}" stroke="{AMBER}" stroke-width="1.6"/>')
        svg.append(f'<text x="{x0+w-3}" y="{PY(true)-5:.1f}" text-anchor="end" font-size="9" fill="{AMBER}">真值 {true:.3f}</text>')
        svg.append(f'<rect x="{x0}" y="{y0}" width="{w}" height="{h}" fill="none" stroke="{INK}" stroke-width="0.8"/>')
        for k in range(1, 4):
            yy = y0 + h * k / 4
            svg.append(f'<text x="{x0-6}" y="{yy+3.5:.1f}" text-anchor="end" font-size="9.5" fill="{MUTED}">{lo+span*(4-k)/4:.2f}</text>')
        for i, v in enumerate(vals):
            svg.append(f'<circle cx="{x0+10+(i%(len(vals)//2+1))*((w-20)/max(1,len(vals)//2+1)):.1f}" cy="{PY(v):.1f}" r="3" fill="{TEAL_MID}" fill-opacity="0.8" stroke="{TEAL}" stroke-width="0.3"/>')
        svg.append(f'<text x="{x0+w/2}" y="{y0+h+32}" text-anchor="middle" font-size="10" fill="{MUTED}">每次模拟的估计值（{len(vals)} 次）</text>')
        svg.append(f'<text x="{ox+18}" y="{y0+h+52}" font-size="9.5" fill="{MUTED}">偏差 {mean-true:+.3f} · RMSE {(statistics.fmean([(v-true)**2 for v in vals]))**0.5:.3f}</text>')
    svg.append(f'<text x="40" y="{H-8}" font-size="9.5" fill="{MUTED}">琥珀色横线为真实参数，绿点为 30 次独立模拟的估计值，阴影带为估计值的标准差。</text>')
    svg.append('</g></svg>')
    open(path, "w", encoding="utf-8").write("\n".join(svg))


def fig_bray(path, est):
    bm = est.get("bray_matched") or {}
    order = ["0-7d", "30-90d", "90-365d", "365-1000000000.0d"]
    labels = {"0-7d": "0–7 天", "30-90d": "30–90 天", "90-365d": "90–365 天",
              "365-1000000000.0d": ">365 天"}
    items = [(labels[k], bm[k]["within"], bm[k]["between"], bm[k]["ratio"])
             for k in order if k in bm]
    W, H = 680, 250
    x0, y0, w, h = 78, 34, 540, 150
    vmax = 0.85
    svg = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" role="img">',
           '<title>同一时间间隔下类内与类间 Bray-Curtis 距离</title>',
           '<desc>四个时间区间内，同一个体两次采样与不同个体间的群落距离对比。</desc>',
           f'<g font-family="PingFang SC, sans-serif">']
    xt = [(i, x0 + (i + 0.5) * w / len(items), it[0]) for i, it in enumerate(items)]
    yt = [(v, y0 + h - v / vmax * h, f"{v:.1f}") for v in (0.0, 0.2, 0.4, 0.6, 0.8)]
    svg.append(axes(x0, y0, w, h, xt, yt, "", "Bray-Curtis 距离"))
    bw = w / len(items) * 0.28
    for i, (lab, wi, be, ratio) in enumerate(items):
        cx = x0 + (i + 0.5) * w / len(items)
        for j, (val, col) in enumerate([(wi, TEAL_LT), (be, TEAL)]):
            bx = cx - bw + j * bw * 1.05
            by = y0 + h - val / vmax * h
            svg.append(f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bw:.1f}" height="{y0+h-by:.1f}" fill="{col}" stroke="{TEAL}" stroke-width="0.5"/>')
            svg.append(f'<text x="{bx+bw/2:.1f}" y="{by-4:.1f}" text-anchor="middle" font-size="9.5" fill="{TEAL}">{val:.2f}</text>')
        svg.append(f'<text x="{cx:.1f}" y="{y0+h+30}" text-anchor="middle" font-size="10" fill="{AMBER}">×{ratio:.2f}</text>')
    svg.append(f'<rect x="{x0+w-150}" y="14" width="10" height="10" fill="{TEAL_LT}" stroke="{TEAL}" stroke-width="0.5"/>')
    svg.append(f'<text x="{x0+w-135}" y="23" font-size="9.5" fill="{MUTED}">同一个体</text>')
    svg.append(f'<rect x="{x0+w-70}" y="14" width="10" height="10" fill="{TEAL}" stroke="{TEAL}" stroke-width="0.5"/>')
    svg.append(f'<text x="{x0+w-55}" y="23" font-size="9.5" fill="{MUTED}">不同个体</text>')
    svg.append('</g></svg>')
    open(path, "w", encoding="utf-8").write("\n".join(svg))


if __name__ == "__main__":
    outdir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, os.pardir, "results")
    os.makedirs(outdir, exist_ok=True)
    vd_path = os.path.join(outdir, "val_default", "validation.json")
    vd = json.load(open(vd_path)) if os.path.exists(vd_path) else {"runs": [], "n_valid": 0}
    info = fig_trajectory(os.path.join(outdir, "fig1_trajectory.svg"))
    if vd["runs"]:
        fig_recovery(os.path.join(outdir, "fig2_recovery.svg"), vd)
    # single cohort analysis for the bray panel
    meta = [r for r in ip.read_csv(os.path.join(HERE, os.pardir, "infant_samples.csv"))
            if r.get("study_name") == "VatanenT_2016"]
    ids, names, counts, mrows, _ = ip.simulate_cohort(meta, seed=1, reads=20000)
    tmp = os.path.join(outdir, "single")
    os.makedirs(tmp, exist_ok=True)
    ip.write_csv(os.path.join(tmp, "species.csv"),
                 [dict({"sample_id": s}, **{n: v for n, v in zip(names, c)})
                  for s, c in zip(ids, counts)], ["sample_id"] + names)
    ip.write_csv(os.path.join(tmp, "meta.csv"), mrows,
                 ["sample_id", "subject_id", "study", "days", "abx"])
    est = ip.analyze(os.path.join(tmp, "meta.csv"), os.path.join(tmp, "species.csv"))
    fig_bray(os.path.join(outdir, "fig3_bray.svg"), est)
    print(json.dumps({"trajectory": info,
                      "icc": est.get("icc_shannon"),
                      "icc_adj": est.get("icc_shannon_ageadj"),
                      "abx": est.get("abx", {}).get("beta_abx"),
                      "bray": {k: round(v["ratio"], 3) for k, v in (est.get("bray_matched") or {}).items()}},
                     indent=1, ensure_ascii=False))
