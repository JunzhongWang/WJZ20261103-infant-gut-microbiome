#!/usr/bin/env python3
"""Screen candidate infant-gut MGnify studies for usable taxonomy profiles."""
import csv, json, re, sys, urllib.request, time

API = "https://www.ebi.ac.uk/metagenomics/api/v1"
KW = re.compile(r"infant|neonat|preterm|premature|baby|babies|newborn|"
                r"birth|mother.?infant|children|child|toddler|weaning", re.I)
EXCL = re.compile(r"lung|airway|sputum|oral|dental|skin|vagina|asd|autism|"
                  r"cystic|pneumonia|dairy|cow|mouse|pig|broncho", re.I)

def get(url, tries=3):
    for k in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=45) as r:
                return json.loads(r.read().decode())
        except Exception:
            if k == tries - 1:
                return None
            time.sleep(1 + k)

rows = list(csv.DictReader(open("data/mgnify_studies.tsv"), delimiter="\t"))
cands = [r for r in rows if r.get("name") and KW.search(r["name"]) and not EXCL.search(r["name"])]
print("candidates:", len(cands), flush=True)
out = []
for r in cands:
    mg = r["mgys"]
    d = get(f"{API}/studies/{mg}/downloads")
    labels = []
    if d:
        for it in d.get("data", []):
            lab = it["attributes"].get("description", {}).get("label", "")
            labels.append(lab)
    tax = [l for l in labels if "taxonomic assignments" in l.lower()]
    d2 = get(f"{API}/studies/{mg}")
    n_an = None
    if d2:
        a = d2["data"]["attributes"]
        n_an = a.get("analyses-count")
    out.append((mg, r["bioproject"], r["n_samples"], len(tax),
                labels[:3], (r.get("name") or "")[:58]))
    print(f"  {mg} n={r['n_samples']:>5} taxfiles={len(tax)} "
          f"labels={labels[:2]} | {(r.get('name') or '')[:50]}", flush=True)
with open("data/mgnify_candidates.tsv", "w", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(["mgys", "bioproject", "n_samples", "n_taxfiles", "labels", "name"])
    for o in out:
        w.writerow([o[0], o[1], o[2], o[3], "|".join(o[4]), o[5]])
print("\nwith study-level taxonomy:", sum(1 for o in out if o[3] > 0))
