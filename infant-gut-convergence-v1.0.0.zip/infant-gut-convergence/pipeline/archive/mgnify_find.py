#!/usr/bin/env python3
"""Enumerate MGnify studies and match our ENA BioProjects."""
import json, sys, os, urllib.request, time

TARGETS = {"PRJNA290380": "VatanenT_2016", "PRJEB6456": "BackhedF_2015",
           "PRJEB32631": "ShaoY_2019", "PRJNA475246": "YassourM_2018"}
BASE = "https://www.ebi.ac.uk/metagenomics/api/v1/studies"

def get(url):
    for k in range(3):
        try:
            with urllib.request.urlopen(url, timeout=40) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if k == 2:
                raise
            time.sleep(1 + k)

first = get(f"{BASE}?page=1&page_size=100")
total = first["links"]["last"].split("page=")[-1].split("&")[0]
nps = first["links"].get("last", "")
import re
pages = int(re.search(r"page=(\d+)", nps).group(1))
print("pages:", pages, flush=True)
found, allrows = [], []
for p in range(1, pages + 1):
    d = get(f"{BASE}?page={p}&page_size=100")
    for it in d.get("data", []):
        a = it.get("attributes", {})
        bp = str(a.get("bioproject", ""))
        allrows.append((it["id"], bp, a.get("samples-count"), a.get("study-name", "")[:70]))
        if bp in TARGETS:
            found.append(allrows[-1])
    if p % 10 == 0:
        print(f"  page {p}/{pages} matched={len(found)}", flush=True)
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
with open(os.path.join(ROOT, "data", "mgnify_studies.tsv"), "w") as f:
    f.write("mgys\tbioproject\tn_samples\tname\n")
    for r in allrows:
        f.write("\t".join(str(x) for x in r) + "\n")
print("\nTOTAL studies:", len(allrows))
print("MATCHED:")
for r in found:
    print("  ", r)
