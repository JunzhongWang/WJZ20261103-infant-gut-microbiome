#!/usr/bin/env python3
"""Fetch one MGnify study's taxonomic profile and convert it to the
sample x species TSV format that infant_pipeline.py consumes.

    python3 pipeline/mgnify_fetch.py MGYS00001234 [--name VatanenT_2016]

Output under data/<name>/ :
    species.tsv   sample_id + relative abundances (species level)
    meta.tsv      sample_id, subject_id, study, days, abx
    mapping.tsv   mg_analysis_accession -> run_accession

Why MGnify instead of curatedMetagenomicData: ExperimentHub (Azure blob) is
unreachable from this sandbox, while EBI is reachable and provides the same
kind of species-level table, processed by one uniform pipeline (MAP v5).
"""
import argparse
import json
import os
import re
import subprocess
import time
import urllib.request
import csv

API = "https://www.ebi.ac.uk/metagenomics/api/v1"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_json(url, tries=3):
    for k in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                return json.loads(r.read().decode())
        except Exception:
            if k == tries - 1:
                raise
            time.sleep(1 + 2 * k)


def download(url, dest, chunk=8 << 20):
    """Chunked download; the sandbox proxy truncates long single responses."""
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        start = 0
        while True:
            end = start + chunk - 1
            cmd = ["curl", "-sL", "--max-time", "180", "-r", f"{start}-{end}", url]
            out = subprocess.run(cmd, capture_output=True)
            data = out.stdout
            if not data:
                break
            f.write(data)
            if len(data) < chunk:
                break
            start = end + 1
    os.replace(tmp, dest)
    return dest


def pick_taxonomy_file(mgys):
    d = get_json(f"{API}/studies/{mgys}/downloads")
    cands = []
    for it in d.get("data", []):
        label = it["attributes"].get("description", {}).get("label", "")
        url = it["links"]["self"]
        if "taxonomic assignments" in label.lower():
            cands.append((label, url, it["attributes"].get("file-format", {})))
    if not cands:
        return None
    # prefer SSU (16S), then highest pipeline version
    def rank(c):
        return (("ssu" in c[0].lower()), c[1])
    cands.sort(key=rank, reverse=True)
    return cands[0]


def parse_taxonomy(path):
    """Return (analysis_accs, species_names, rows) at species level."""
    accs, rows = [], []
    with open(path, newline="") as f:
        rd = csv.reader(f, delimiter="\t", quoting=csv.QUOTE_NONE)
        header = next(rd)
        accs = [h.strip() for h in header[1:]]
        for rec in rd:
            if len(rec) < 2:
                continue
            parts = [p for p in rec[0].split(";")]
            genus = next((p[3:] for p in parts if p.startswith("g__") and len(p) > 3), "")
            sp = next((p[3:] for p in parts if p.startswith("s__") and len(p) > 3), "")
            if sp and genus and not sp.startswith(genus):
                name = f"{genus} {sp}"
            elif sp:
                name = sp
            elif genus:
                name = f"{genus} (genus)"
            else:
                continue
            name = name.replace("_", " ")
            counts = []
            ok = False
            for v in rec[1:]:
                try:
                    x = float(v)
                except ValueError:
                    x = 0.0
                counts.append(x)
                if x:
                    ok = True
            if ok:
                rows.append((name, counts))
    return accs, rows


def er2run(bioproject):
    """ERZ analysis accession -> run accession, via ENA analysis filereport."""
    url = ("https://www.ebi.ac.uk/ena/portal/api/filereport"
           f"?accession={bioproject}&result=analysis&format=tsv")
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            txt = r.read().decode()
    except Exception:
        return {}
    out = {}
    for line in txt.splitlines()[1:]:
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        m = re.search(r"([SED]RR\d+)", parts[1])
        if m:
            out[parts[0]] = m.group(1)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mgys")
    ap.add_argument("--name", default=None)
    ap.add_argument("--bioproject", default=None)
    args = ap.parse_args()
    name = args.name or args.mgys

    info = get_json(f"{API}/studies/{args.mgys}")
    at = info["data"]["attributes"]
    bp = args.bioproject or at.get("bioproject", "")
    print(f"{name}: {at.get('study-name', '')[:70]} | bioproject={bp} | "
          f"samples={at.get('samples-count')}")

    tf = pick_taxonomy_file(args.mgys)
    if tf is None:
        print("  no taxonomic assignments available")
        return 1
    label, url, fmt = tf
    print(f"  file: {label} ({fmt.get('extension')})")

    outdir = os.path.join(ROOT, "data", name)
    os.makedirs(outdir, exist_ok=True)
    local = os.path.join(outdir, "taxonomy.tsv")
    download(url, local)
    print(f"  downloaded {os.path.getsize(local)/1e6:.2f} MB")

    accs, rows = parse_taxonomy(local)
    print(f"  parsed: {len(accs)} analyses x {len(rows)} taxa")

    # collapse duplicate species names
    agg = {}
    order = []
    for sp, cnt in rows:
        if sp not in agg:
            agg[sp] = [0.0] * len(accs)
            order.append(sp)
        a = agg[sp]
        for i, v in enumerate(cnt):
            a[i] += v
    mat = [agg[sp] for sp in order]

    # relative abundance per sample
    n = len(accs)
    tot = [0.0] * n
    for vec in mat:
        for i, v in enumerate(vec):
            tot[i] += v
    for vec in mat:
        for i in range(n):
            vec[i] = vec[i] / tot[i] if tot[i] > 0 else 0.0

    mapping = er2run(bp) if bp else {}
    print(f"  run mapping: {len(mapping)} / {n}")

    with open(os.path.join(outdir, "species.tsv"), "w", newline="") as f:
        w = csv.writer(f, delimiter="\t", lineterminator="\n")
        w.writerow(["sample_id"] + order)
        for i, acc in enumerate(accs):
            rid = mapping.get(acc, acc)
            w.writerow([rid] + [f"{mat[j][i]:.6g}" for j in range(len(order))])
    with open(os.path.join(outdir, "mapping.tsv"), "w", newline="") as f:
        w = csv.writer(f, delimiter="\t", lineterminator="\n")
        w.writerow(["analysis", "run"])
        for acc in accs:
            w.writerow([acc, mapping.get(acc, "")])
    print(f"  wrote {outdir}/species.tsv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
