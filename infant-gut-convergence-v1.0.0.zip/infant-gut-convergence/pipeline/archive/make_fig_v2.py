#!/usr/bin/env python3
"""Figures for the corrected-age analysis.

fig1  apparent decay of the within/between distance ratio with age (4 panels)
fig2  forest plot: decay after adjusting for the recall window
fig3  per-family individual signature (CLR ICC) distribution
"""
import csv
import glob
import json
import math
import os
import re
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "real")
INK, MUTED, GRID, PAPER = "#1a1a18", "#6b6a65", "#e3e6e4", "#ffffff"
SERIES = {
    "VatanenT_2016": ("Vatanen 2016", "芬兰 · DIABIMMUNE", "#0F6E56"),
    "ShaoY_2019": ("Shao 2019", "中国 · 母婴队列", "#C2703A"),
    "BackhedF_2015": ("Bäckhed 2015", "瑞典 · 母婴队列", "#3C6E9F"),
    "YassourM_2018": ("Yassour 2018", "芬兰 · DIABIMMUNE", "#8A6FA8"),
}
ORDER = ["VatanenT_2016", "ShaoY_2019", "BackhedF_2015", "YassourM_2018"]
FONT = "PingFang SC, Hiragino Sans GB, Microsoft YaHei, sans-serif"


def head(w, h, title, desc):
    return [f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
            f'role="img" width="100%">',
            f'<rect width="{w}" height="{h}" fill="{PAPER}"/>',
            f'<title>{title}</title><desc>{desc}</desc>',
            f'<g font-family="{FONT}">']


# ------------------------------------------------------------------ fig 1


def fig1():
    rows = list(csv.DictReader(open(os.path.join(OUT, "meta_buckets.csv"))))
    by = {}
    for r in rows:
        by.setdefault(r["study"], []).append(r)

    W, H = 680, 470
    ncol, nrow = 2, 2
    pw, ph = 250, 130
    gx, gy = 78, 92
    xgap, ygap = 60, 74
    lo, hi = 0.85, 1.9
    a, b = math.log10(8), math.log10(1200)

    def px(v, ox):
        return ox + (math.log10(max(v, 8)) - a) / (b - a) * pw

    def py(v, oy):
        return oy + ph - (v - lo) / (hi - lo) * ph

    svg = head(W, H, "图 1　表观的个体相似度随月龄下降",
               "四个队列中，同龄他人与自己的 Bray-Curtis 距离比随月龄变化；"
               "误差线为按受试者整群重抽样的 95% 置信区间。")

    svg.append(f'<text x="{gx}" y="30" font-size="13" font-weight="600" '
               f'fill="{INK}">表观的个体相似度随月龄下降</text>')
    svg.append(f'<text x="{gx}" y="48" font-size="9.5" fill="{MUTED}">'
               f'纵轴 = 同龄两名婴儿之间的距离 ÷ 同一婴儿两次采样之间的距离；'
               f'1.0 表示自己与他人一样远</text>')

    for i, study in enumerate(ORDER):
        cx, cy = i % ncol, i // ncol
        ox = gx + cx * (pw + xgap)
        oy = gy + cy * (ph + ygap)
        label, sub, color = SERIES[study]
        svg.append(f'<text x="{ox}" y="{oy-30}" font-size="10.5" font-weight="600" '
                   f'fill="{INK}">{label}</text>')
        svg.append(f'<text x="{ox}" y="{oy-19}" font-size="8.5" '
                   f'fill="{MUTED}">{sub}</text>')
        for k in range(0, 5):
            v = lo + (hi - lo) * k / 4
            svg.append(f'<line x1="{ox}" y1="{py(v, oy):.1f}" x2="{ox+pw}" '
                       f'y2="{py(v, oy):.1f}" stroke="{GRID}" stroke-width="0.5"/>')
            if cx == 0:
                svg.append(f'<text x="{ox-7}" y="{py(v, oy)+3.2:.1f}" '
                           f'text-anchor="end" font-size="8.5" fill="{MUTED}">'
                           f'{v:.1f}</text>')
        svg.append(f'<line x1="{ox}" y1="{py(1.0, oy):.1f}" x2="{ox+pw}" '
                   f'y2="{py(1.0, oy):.1f}" stroke="#a9a7a0" stroke-width="0.9" '
                   f'stroke-dasharray="4 3"/>')
        pts = []
        for r in sorted(by.get(study, []), key=lambda x: float(x["age_mid_days"])):
            x = float(r["age_mid_days"])
            y = float(r["ratio"])
            yl, yh = float(r["ratio_lo"]), float(r["ratio_hi"])
            pxv = px(x, ox)
            pts.append((pxv, py(y, oy)))
            svg.append(f'<line x1="{pxv:.1f}" y1="{py(yl, oy):.1f}" '
                       f'x2="{pxv:.1f}" y2="{py(yh, oy):.1f}" stroke="{color}" '
                       f'stroke-width="1.1" opacity="0.45"/>')
            for yy in (yl, yh):
                svg.append(f'<line x1="{pxv-2.2:.1f}" y1="{py(yy, oy):.1f}" '
                           f'x2="{pxv+2.2:.1f}" y2="{py(yy, oy):.1f}" '
                           f'stroke="{color}" stroke-width="1.1" opacity="0.45"/>')
        if len(pts) > 1:
            svg.append('<polyline points="' +
                       " ".join(f"{x:.1f},{y:.1f}" for x, y in pts) +
                       f'" fill="none" stroke="{color}" stroke-width="1.6" '
                       f'opacity="0.85" stroke-linejoin="round"/>')
        for x, y in pts:
            svg.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.2" '
                       f'fill="{PAPER}" stroke="{color}" stroke-width="1.7"/>')
        svg.append(f'<line x1="{ox}" y1="{oy+ph}" x2="{ox+pw}" y2="{oy+ph}" '
                   f'stroke="{INK}" stroke-width="0.8"/>')
        for tick, lab in [(14, "2周"), (60, "2月"), (180, "6月"), (365, "1岁"), (1095, "3岁")]:
            xx = px(tick, ox)
            if gx <= xx <= ox + pw:
                svg.append(f'<line x1="{xx:.1f}" y1="{oy+ph}" x2="{xx:.1f}" '
                           f'y2="{oy+ph+3}" stroke="{INK}" stroke-width="0.8"/>')
                svg.append(f'<text x="{xx:.1f}" y="{oy+ph+14}" text-anchor="middle" '
                           f'font-size="8.5" fill="{MUTED}">{lab}</text>')

    svg.append(f'<text x="{gx+pw*2+xgap}" y="{gy+ph+ygap+ph+40}" text-anchor="end" '
               f'font-size="9" fill="{MUTED}">月龄（对数刻度）</text>')
    svg.append('</g></svg>')
    open(os.path.join(OUT, "fig1_apparent_decay.svg"), "w",
         encoding="utf-8").write("\n".join(svg))
    print("fig1 ok")


# ------------------------------------------------------------------ fig 2


def fig2():
    d = json.load(open(os.path.join(OUT, "decay_model.json")))
    per = d["per_cohort"]
    pm = d["pooled_model"]

    W, H = 680, 316
    x0, y0, w = 190, 74, 380
    rows = [(s, per[s]["decay"], per[s]["se"], per[s]["n_within"],
             per[s]["n_between"]) for s in ORDER if s in per]
    lim = 0.62
    overflow = [s for s, e, se, _, _ in rows if e + 1.96 * se > lim]
    rows = [r for r in rows if r[0] not in overflow]

    def px(v):
        return x0 + (v + lim) / (2 * lim) * w

    svg = head(W, H, "图 2　控制观察间隔后，衰减消失",
               "每队列的衰减量 = 类间距离的年龄斜率 − 类内距离的年龄斜率；"
               "负值表示个体独特性随月龄减弱。")
    svg.append(f'<text x="40" y="30" font-size="13" font-weight="600" fill="{INK}">'
               f'控制观察间隔后，衰减消失</text>')
    svg.append(f'<text x="40" y="48" font-size="9.5" fill="{MUTED}">'
               f'衰减 = β(类间,年龄) − β(类内,年龄)，两模型均含研究固定效应与 log(间隔) 协变量</text>')

    for k in range(-3, 4):
        v = k * 0.2
        svg.append(f'<line x1="{px(v):.1f}" y1="{y0-8}" x2="{px(v):.1f}" '
                   f'y2="{y0+len(rows)*30+18}" stroke="{GRID}" stroke-width="0.5"/>')
        svg.append(f'<text x="{px(v):.1f}" y="{y0+len(rows)*30+32}" '
                   f'text-anchor="middle" font-size="8.5" fill="{MUTED}">'
                   f'{v:+.1f}</text>')
    svg.append(f'<line x1="{px(0):.1f}" y1="{y0-8}" x2="{px(0):.1f}" '
               f'y2="{y0+len(rows)*30+18}" stroke="#9b9992" stroke-width="1"/>')

    for i, (s, est, se, nw, nb) in enumerate(rows):
        yy = y0 + i * 30
        label = SERIES[s][0]
        svg.append(f'<text x="{x0-16}" y="{yy+3.5}" text-anchor="end" font-size="9.5" '
                   f'fill="{INK}">{label}</text>')
        svg.append(f'<text x="{x0-16}" y="{yy+14}" text-anchor="end" font-size="7.5" '
                   f'fill="{MUTED}">{nw} 对 / {nb:,} 对</text>')
        c = SERIES[s][2]
        svg.append(f'<line x1="{px(est-1.96*se):.1f}" y1="{yy}" '
                   f'x2="{px(est+1.96*se):.1f}" y2="{yy}" stroke="{c}" '
                   f'stroke-width="1.4" opacity="0.5"/>')
        svg.append(f'<rect x="{px(est-1.96*se):.1f}" y="{yy-3}" '
                   f'width="{max(px(est+1.96*se)-px(est-1.96*se),1):.1f}" height="6" '
                   f'fill="{c}" opacity="0.16"/>')
        svg.append(f'<circle cx="{px(est):.1f}" cy="{yy}" r="4" fill="{c}" '
                   f'stroke="{PAPER}" stroke-width="1"/>')

    yy = y0 + len(rows) * 30 + 6
    svg.append(f'<line x1="{x0-10}" y1="{yy-14}" x2="{px(lim):.1f}" y2="{yy-14}" '
               f'stroke="{GRID}" stroke-width="0.8"/>')
    est, lo, hi = pm["decay"], pm["ci95"][0], pm["ci95"][1]
    svg.append(f'<text x="{x0-16}" y="{yy+3.5}" text-anchor="end" font-size="9.5" '
               f'font-weight="600" fill="{INK}">汇总模型</text>')
    svg.append(f'<text x="{x0-16}" y="{yy+14}" text-anchor="end" font-size="7.5" '
               f'fill="{MUTED}">{pm["n_subjects"]} 名婴儿</text>')
    svg.append(f'<line x1="{px(lo):.1f}" y1="{yy}" x2="{px(hi):.1f}" y2="{yy}" '
               f'stroke="{INK}" stroke-width="1.6"/>')
    for xx in (lo, hi):
        svg.append(f'<line x1="{px(xx):.1f}" y1="{yy-5}" x2="{px(xx):.1f}" '
                   f'y2="{yy+5}" stroke="{INK}" stroke-width="1.4"/>')
    svg.append(f'<rect x="{px(est)-4.5:.1f}" y="{yy-4.5}" width="9" height="9" '
               f'fill="{INK}"/>')
    svg.append(f'<text x="{px(hi)+10:.1f}" y="{yy+3.5}" font-size="9" fill="{INK}">'
               f'{est:+.3f} [{lo:+.3f}, {hi:+.3f}]，p = {pm["p"]:.2f}</text>')

    oy = yy + 24
    for s in overflow:
        v = per[s]
        oy += 17
        svg.append(f'<line x1="{px(lim-0.06):.1f}" y1="{oy}" x2="{px(lim):.1f}" '
                   f'y2="{oy}" stroke="{SERIES[s][2]}" stroke-width="1.6"/>')
        svg.append(f'<polygon points="{px(lim):.1f},{oy-3.4} {px(lim):.1f},{oy+3.4} '
                   f'{px(lim)+6:.1f},{oy}" fill="{SERIES[s][2]}"/>')
        svg.append(f'<text x="{x0-16}" y="{oy+3.5}" text-anchor="end" font-size="9.5" '
                   f'fill="{INK}">{SERIES[s][0]}</text>')
        svg.append(f'<text x="{px(lim)-8:.1f}" y="{oy+3.5}" text-anchor="end" '
                   f'font-size="8.5" fill="{MUTED}">{v["decay"]:+.2f} '
                   f'[{v["decay"]-1.96*v["se"]:+.2f}, {v["decay"]+1.96*v["se"]:+.2f}]'
                   f'（超出范围*）</text>')

    svg.append(f'<text x="{x0+w/2}" y="{H-40}" text-anchor="middle" font-size="9" '
               f'fill="{MUTED}">负值 = 个体独特性随月龄减弱；0 = 无变化</text>')
    if overflow:
        svg.append(f'<text x="40" y="{H-14}" font-size="8" fill="{MUTED}">'
                   f'* 超出范围的队列（Shao、Yassour）在单队列内 log(年龄) 与 log(间隔) 近乎共线'
                   f'（r = 0.90），单队列估计不可单独解释，故以汇总模型为准。</text>')
    svg.append('</g></svg>')
    open(os.path.join(OUT, "fig2_forest.svg"), "w",
         encoding="utf-8").write("\n".join(svg))
    print("fig2 ok")


# ------------------------------------------------------------------ fig 3


def fig3():
    fam = {}
    for f in glob.glob(os.path.join(ROOT, "data", "*", "taxon_icc.tsv")):
        study = f.split(os.sep)[-2]
        vals = []
        for r in csv.DictReader(open(f), delimiter="\t"):
            if "[f]" in r["taxon"]:
                vals.append(float(r["icc"]))
        if vals:
            fam[study] = vals

    W, H = 680, 290
    x0, y0, w, h = 120, 78, 430, 130
    lim = 0.8

    def px(v):
        return x0 + (v + lim) / (2 * lim) * w

    svg = head(W, H, "图 3　组成的个体签名稳定存在",
               "科级分类单元的对数比丰度（CLR）个体内相关系数 ICC；"
               "流行率 ≥50% 的科，每点为一个科。")
    svg.append(f'<text x="40" y="30" font-size="13" font-weight="600" fill="{INK}">'
               f'组成的个体签名稳定存在</text>')
    svg.append(f'<text x="40" y="48" font-size="9.5" fill="{MUTED}">'
               f'逐科 CLR 丰度的个体内相关系数；正值表示同一婴儿的丰度比同龄他人更接近自己</text>')

    for k in range(-4, 5):
        v = k * 0.2
        svg.append(f'<line x1="{px(v):.1f}" y1="{y0-12}" x2="{px(v):.1f}" '
                   f'y2="{y0+h+8}" stroke="{GRID}" stroke-width="0.5"/>')
        svg.append(f'<text x="{px(v):.1f}" y="{y0+h+22}" text-anchor="middle" '
                   f'font-size="8.5" fill="{MUTED}">{v:+.1f}</text>')
    svg.append(f'<line x1="{px(0):.1f}" y1="{y0-12}" x2="{px(0):.1f}" '
               f'y2="{y0+h+8}" stroke="#9b9992" stroke-width="1"/>')

    step = h / max(len(fam), 1)
    for i, study in enumerate([s for s in ORDER if s in fam]):
        vals = sorted(fam[study])
        yy = y0 + i * step + step / 2
        c = SERIES[study][2]
        for j, v in enumerate(vals):
            jitter = ((j * 37) % 11 - 5) / 5.0 * (step * 0.19)
            svg.append(f'<circle cx="{px(v):.1f}" cy="{yy+jitter:.1f}" r="2.6" '
                       f'fill="{c}" opacity="0.55"/>')
        med = statistics.median(vals)
        svg.append(f'<line x1="{px(med):.1f}" y1="{yy-step*0.34:.1f}" '
                   f'x2="{px(med):.1f}" y2="{yy+step*0.34:.1f}" stroke="{c}" '
                   f'stroke-width="2"/>')
        svg.append(f'<text x="{x0-14}" y="{yy+3.5}" text-anchor="end" font-size="9.5" '
                   f'fill="{INK}">{SERIES[study][0]}</text>')
        svg.append(f'<text x="{x0-14}" y="{yy+14}" text-anchor="end" font-size="7.5" '
                   f'fill="{MUTED}">中位 {med:.2f} · n={len(vals)}</text>')

    svg.append(f'<text x="{x0+w/2}" y="{H-24}" text-anchor="middle" font-size="9" '
               f'fill="{MUTED}">个体内相关系数 ICC（0 = 与随机两名婴儿无异）</text>')
    svg.append('</g></svg>')
    open(os.path.join(OUT, "fig3_icc.svg"), "w", encoding="utf-8").write("\n".join(svg))
    print("fig3 ok")


if __name__ == "__main__":
    fig1()
    fig2()
    fig3()
