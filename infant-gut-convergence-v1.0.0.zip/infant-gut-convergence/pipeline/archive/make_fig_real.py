#!/usr/bin/env python3
"""Figure: individual distinctiveness decays with infant age, four cohorts.

Ratio = (Bray-Curtis distance between different infants of the same age)
      / (distance between two samples of the same infant, same age gap)

A ratio of 1 means "a stranger looks like your future self"; higher means the
infant still has a distinguishable personal microbiota.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "real", "fig_maturation.svg")

BINS = [(0, 7, 3.5), (7, 30, 14), (30, 90, 52), (90, 365, 200), (365, 4000, 730)]
LABELS = ["0–7d", "7–30d", "30–90d", "90–365d", ">365d"]
SERIES = [
    ("VatanenT_2016", "Vatanen 2016（芬兰）", "#0F6E56"),
    ("ShaoY_2019", "Shao 2019（英国）", "#C2703A"),
    ("BackhedF_2015", "Bäckhed 2015（瑞典）", "#3C6E9F"),
    ("YassourM_2018", "Yassour 2018（芬兰）", "#8A6FA8"),
]
INK, MUTED, GRID = "#1a1a18", "#6b6a65", "#e2e6e3"

W, H = 680, 340
x0, y0, w, h = 78, 54, 500, 210
ylo, yhi = 0.90, 1.85


def px(days):
    import math
    a, b = math.log10(3.5), math.log10(730)
    return x0 + (math.log10(days) - a) / (b - a) * w


def py(v):
    return y0 + h - (v - ylo) / (yhi - ylo) * h


def load(study):
    p = os.path.join(ROOT, "results", "real", f"{study}.json")
    t = open(p).read()
    d = json.loads(t[: t.rindex("}") + 1])
    out = {}
    for k, v in d["bray_ratio_matched"].items():
        lo = float(k.split("-")[0].replace("d", ""))
        for i, (blo, bhi, mid) in enumerate(BINS):
            if abs(lo - blo) < 1e-6:
                out[i] = v
    return d, out


svg = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" role="img">',
       '<title>婴幼儿肠道菌群的个体独特性随月龄衰减</title>',
       '<desc>四个独立队列中，同龄他人与自己的距离比随月龄变化。</desc>',
       '<g font-family="PingFang SC, sans-serif">']

# y grid
for k in range(0, 6):
    v = ylo + (yhi - ylo) * k / 5
    svg.append(f'<line x1="{x0}" y1="{py(v):.1f}" x2="{x0+w}" y2="{py(v):.1f}" '
               f'stroke="{GRID}" stroke-width="0.5"/>')
    svg.append(f'<text x="{x0-8}" y="{py(v)+3.5:.1f}" text-anchor="end" font-size="9.5" '
               f'fill="{MUTED}">{v:.1f}</text>')

# reference line at 1.0
svg.append(f'<line x1="{x0}" y1="{py(1.0):.1f}" x2="{x0+w}" y2="{py(1.0):.1f}" '
           f'stroke="#9b9992" stroke-width="1.1" stroke-dasharray="5 3"/>')
svg.append(f'<text x="{x0+6}" y="{py(1.0)-8:.1f}" text-anchor="start" font-size="9.5" '
           f'fill="{MUTED}">比值 = 1：他与“未来的你”无异</text>')

# x ticks
for i, (blo, bhi, mid) in enumerate(BINS):
    svg.append(f'<text x="{px(mid):.1f}" y="{y0+h+16}" text-anchor="middle" '
               f'font-size="9.5" fill="{MUTED}">{LABELS[i]}</text>')
svg.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" stroke="{INK}" stroke-width="0.8"/>')

# series
for study, label, color in SERIES:
    d, pts = load(study)
    xs = [(px(BINS[i][2]), py(v)) for i, v in sorted(pts.items())]
    if len(xs) > 1:
        svg.append('<polyline points="' + " ".join(f"{a:.1f},{b:.1f}" for a, b in xs) +
                   f'" fill="none" stroke="{color}" stroke-width="1.8" '
                   f'stroke-linejoin="round" opacity="0.9"/>')
    for a, b in xs:
        svg.append(f'<circle cx="{a:.1f}" cy="{b:.1f}" r="3.6" fill="#ffffff" '
                   f'stroke="{color}" stroke-width="1.8"/>')

# legend
lx, ly = x0 + 8, 18
for i, (study, label, color) in enumerate(SERIES):
    cx = lx + (i % 2) * 250
    cy = ly + (i // 2) * 16
    svg.append(f'<line x1="{cx}" y1="{cy}" x2="{cx+14}" y2="{cy}" stroke="{color}" stroke-width="2"/>')
    svg.append(f'<circle cx="{cx+7}" cy="{cy}" r="3" fill="#fff" stroke="{color}" stroke-width="1.6"/>')
    svg.append(f'<text x="{cx+20}" y="{cy+3.5}" font-size="9.5" fill="{INK}">{label}</text>')

svg.append(f'<text x="{x0+w/2}" y="{H-24}" text-anchor="middle" font-size="9.5" '
           f'fill="{MUTED}">采样间隔（对数刻度）· 数值 &gt; 1 表示同一婴儿的两次采样比同龄两个婴儿更相似</text>')
svg.append('</g></svg>')

os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, "w", encoding="utf-8").write("\n".join(svg))
print("wrote", OUT)
