#!/usr/bin/env python3
"""Rebuild data/<study>/meta.csv using a defensible age axis.

Why this exists
---------------
The first pass used `days_from_first_collection` as age. That column is the
offset from a subject's *first* stool sample, not age at sampling. In
VatanenT_2016 the median gap between the two is 139 days, so the first pass
was plotting time-since-enrolment against a birth-anchored axis.

cMD3 defines `infant_age` as the infant's age in days at sampling. We use that
as the primary axis. `dffc` is carried alongside so the previous analysis can be
re-run as a sensitivity check rather than silently discarded.

    python3 pipeline/rebuild_meta.py --studies VatanenT_2016 ShaoY_2019 ...
"""
import argparse
import csv
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "data", "cache", "sample_metadata.csv")


def num(v):
    v = (v or "").strip()
    if v in ("", "NA", "nan"):
        return None
    try:
        return float(v)
    except ValueError:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", required=True)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    meta = {}
    by_study = {}
    with open(CACHE, newline="") as f:
        for r in csv.DictReader(f):
            meta[r["sample_id"]] = r
            by_study.setdefault(r["study_name"], []).append(r)

    for study in args.studies:
        d = os.path.join(ROOT, "data", study)

        # Anchor constant per subject: days between birth and that subject's
        # first stool sample. It is a subject-level constant, so any sample with
        # a known infant_age pins it exactly; leave-one-out error is 0 days in
        # all four cohorts. This recovers the post-infancy visits of Vatanen,
        # where cMD3 only annotates infant_age on the newborn-labelled samples.
        anchors = {}
        for r in by_study.get(study, []):
            ia, dd = num(r.get("infant_age")), num(r.get("days_from_first_collection"))
            if ia is not None and dd is not None:
                anchors.setdefault(r["subject_id"], []).append(ia - dd)
        anchors = {s: sorted(v)[len(v) // 2] for s, v in anchors.items()}

        sp_path = os.path.join(d, "species.csv")
        with open(sp_path, newline="") as f:
            rd = list(csv.reader(f))
        header, rows = rd[0], [r for r in rd[1:] if r and r[0]]

        kept, age_src, dropped, dropped_body = [], {}, 0, 0
        for r in rows:
            m = meta.get(r[0])
            if m is None:
                dropped += 1
                continue
            if (m.get("body_site") or "stool") not in ("stool", ""):
                dropped_body += 1
                continue
            ia = num(m.get("infant_age"))
            if ia is not None:
                age_src[r[0]] = ("measured", ia)
                kept.append(r)
                continue
            dd = num(m.get("days_from_first_collection"))
            if dd is not None and m["subject_id"] in anchors:
                age_src[r[0]] = ("anchored", dd + anchors[m["subject_id"]])
                kept.append(r)
                continue
            dropped += 1

        subj = {}
        for r in kept:
            m = meta[r[0]]
            subj.setdefault(m["subject_id"], 0)
            subj[m["subject_id"]] += 1
        multi = sum(1 for v in subj.values() if v >= 2)
        cnt = {}
        for r in kept:
            s = meta[r[0]]["subject_id"]
            cnt[s] = cnt.get(s, 0) + 1
        pairs = sum(v * (v - 1) // 2 for v in cnt.values())
        n_meas = sum(1 for r in kept if age_src[r[0]][0] == "measured")
        n_anch = len(kept) - n_meas

        print(f"{study}: {len(rows)} -> {len(kept)} samples "
              f"({n_meas} measured + {n_anch} anchored), {len(subj)} subjects, "
              f"{multi} with >=2 visits, {pairs} within pairs "
              f"(dropped {dropped} no age, {dropped_body} non-stool)")
        if args.dry_run or not kept:
            continue

        with open(sp_path, "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(header)
            w.writerows(kept)

        old = os.path.join(d, "meta.csv")
        prev = {}
        if os.path.exists(old):
            with open(old, newline="") as f:
                prev = {r["sample_id"]: r for r in csv.DictReader(f)}
        with open(old + ".dffc", "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["sample_id", "subject_id", "study", "days", "abx"])
            for r in kept:
                if r[0] in prev:
                    w.writerow([prev[r[0]][k] for k in
                                ("sample_id", "subject_id", "study", "days", "abx")])

        with open(old, "w", newline="") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["sample_id", "subject_id", "study", "days", "abx",
                        "dffc", "age_source"])
            for r in kept:
                m = meta[r[0]]
                abx = 1 if str(m.get("antibiotics_current_use", "")).strip().lower() \
                    in ("true", "yes", "1") else 0
                src, age = age_src[r[0]]
                w.writerow([r[0], f"{study}::{m['subject_id']}", study,
                            int(round(age)), abx,
                            m.get("days_from_first_collection", ""), src])
        print(f"  wrote meta.csv (age = infant_age, anchored where missing) "
              f"and meta.csv.dffc (previous axis, for sensitivity analysis)")


if __name__ == "__main__":
    main()
