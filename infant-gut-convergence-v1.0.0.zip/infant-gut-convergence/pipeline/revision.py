#!/usr/bin/env python3
"""Revision analyses requested by the referee-level review of the manuscript.

Four things the first draft could not answer:

1. Does between-infant distance really stay flat as infants age (the draft's
   claim), or does it fall while within-infant distance falls with it?  The
   ratio R cannot tell the two apart, so estimate both trends separately at
   matched interval, with cluster-robust variance, and test their difference.

2. Is the interval effect an artefact of the fact that the densely sampled
   cohorts are preterm NICU infants?  Recompute the headline curve without
   them, and cohort by cohort.

3. Could the published "convergence" be produced by the sampling designs alone,
   with no age effect at all?  Simulate log-distances on the real designs with
   the true age effect set to zero and run the interval-blind estimator.

4. Does the interval-driven fall of R survive a change of distance metric
   (Jaccard, Aitchison)?

    python3 pipeline/revision.py
"""
import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from decay_model import load, bray, STUDIES  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AGE_EDGES = [(0, 30), (30, 90), (90, 180), (180, 365), (365, 800), (800, 1e9)]
DT_EDGES = [(1, 7), (7, 14), (14, 30), (30, 60), (60, 120), (120, 240),
            (240, 500), (500, 1e9)]
PRETERM = {"BrooksB_2017"}
N_BETWEEN = 20000
MIN_DT = 1


def band(x, edges):
    for lo, hi in edges:
        if lo <= x < hi:
            return (lo, hi)
    return None


def jaccard(p, q):
    inter = union = 0
    for a, b in zip(p, q):
        a = a > 0
        b = b > 0
        if a or b:
            union += 1
            if a and b:
                inter += 1
    return 1.0 - inter / union if union else 0.0


def clr_euclid(p, q, eps=1e-6):
    lp = [math.log(x + eps) for x in p]
    lq = [math.log(x + eps) for x in q]
    mp = sum(lp) / len(lp)
    mq = sum(lq) / len(lq)
    return math.sqrt(sum(((a - mp) - (b - mq)) ** 2 for a, b in zip(lp, lq)))


# --------------------------------------------------------------------------
# design: collect pairs once
# --------------------------------------------------------------------------
def collect(studies, n_between=N_BETWEEN):
    """Return (within, between, meta) where every record is
    (study_index, cluster1, cluster2, log_age_later, log_dt, log_distance).
    cluster2 is -1 for within-subject pairs."""
    within, between, info = [], [], {}
    for si, study in enumerate(studies):
        rel, age, subj = load(study)
        by = {}
        for i, s in enumerate(subj):
            by.setdefault(s, []).append(i)
        ids = {s: k for k, s in enumerate(sorted(by))}
        for s, ii in by.items():
            ii = sorted(ii, key=lambda k: age[k])
            for a in range(len(ii)):
                for b in range(a + 1, len(ii)):
                    i, j = ii[a], ii[b]
                    dt = age[j] - age[i]
                    if dt < MIN_DT:
                        continue
                    d = bray(rel[i], rel[j])
                    if d <= 0:
                        continue
                    within.append((si, ids[s], -1, math.log(max(age[j], 1.0)),
                                   math.log(dt + 1.0), math.log(d)))
        rng = random.Random(731 + si)
        keys = list(by)
        if len(keys) >= 2:
            for _ in range(n_between):
                s1, s2 = rng.sample(keys, 2)
                i, j = rng.choice(by[s1]), rng.choice(by[s2])
                if age[i] > age[j]:
                    i, j = j, i
                dt = age[j] - age[i]
                if dt < MIN_DT:
                    continue
                d = bray(rel[i], rel[j])
                if d <= 0:
                    continue
                between.append((si, ids[s1], ids[s2], math.log(max(age[j], 1.0)),
                                math.log(dt + 1.0), math.log(d)))
        info[study] = {"n_samples": len(age), "n_subjects": len(by),
                       "age_min": round(min(age)), "age_max": round(max(age))}
    return within, between, info


# --------------------------------------------------------------------------
# fixed-effects regression with cluster-robust covariance
# --------------------------------------------------------------------------
def _demean(rows, n_study):
    """rows = (study, c1, c2, log_age, log_dt, log_distance).

    Returns centred (cluster1, x, y) triples and the centred sum of squares."""
    sy = [0.0] * n_study
    sx = [0.0] * n_study
    n = [0] * n_study
    for r in rows:
        sx[r[0]] += r[3]
        sy[r[0]] += r[5]
        n[r[0]] += 1
    out = []
    for r in rows:
        si = r[0]
        if n[si] == 0:
            continue
        out.append((r[1], r[3] - sx[si] / n[si], r[5] - sy[si] / n[si]))
    sxx = sum(t[1] * t[1] for t in out)
    return out, sxx


def fe_slope_joint(within, between, n_study):
    """Slope of log distance on log age, separately for within and between
    pairs, both with study fixed effects.  Returns the two slopes and their
    joint cluster-robust covariance (clusters keyed on the first infant)."""
    cw, sxx_w = _demean(within, n_study)
    cb, sxx_b = _demean(between, n_study)
    bw = sum(r[1] * r[2] for r in cw) / sxx_w
    bb = sum(r[1] * r[2] for r in cb) / sxx_b

    score = {}
    for c1, x, y in cw:
        e = y - bw * x
        v = score.get(c1, [0.0, 0.0])
        v[0] += x * e
        score[c1] = v
    for c1, x, y in cb:
        e = y - bb * x
        v = score.get(c1, [0.0, 0.0])
        v[1] += x * e
        score[c1] = v

    m11 = m12 = m22 = 0.0
    for a, b in score.values():
        m11 += a * a
        m12 += a * b
        m22 += b * b
    v11 = m11 / (sxx_w * sxx_w)
    v22 = m22 / (sxx_b * sxx_b)
    v12 = m12 / (sxx_w * sxx_b)
    return {"b_within": bw, "b_between": bb, "se_within": math.sqrt(v11),
            "se_between": math.sqrt(v22),
            "slope_diff": bb - bw,
            "se_diff": math.sqrt(max(v11 + v22 - 2 * v12, 0.0))}


def fe_slope_single(rows, n_study):
    c, sxx = _demean(rows, n_study)
    if not c or sxx <= 1e-9:
        return None
    b = sum(r[1] * r[2] for r in c) / sxx
    score = {}
    for c1, x, y in c:
        e = y - b * x
        score[c1] = score.get(c1, 0.0) + x * e
    v = sum(s * s for s in score.values()) / (sxx * sxx)
    return {"slope": b, "se": math.sqrt(v)}


def z_p(z):
    return math.erfc(abs(z) / math.sqrt(2))


# --------------------------------------------------------------------------
# analyses
# --------------------------------------------------------------------------
def _cohort_slopes(rows_w, rows_b, n_study, min_spread=0.30):
    """Per-cohort slopes with cluster-robust SEs, for one interval band.

    A slope in log-log space is only identified if log(age) actually varies;
    inside one interval band a cohort can sample a single narrow age window,
    in which case the slope is numerically arbitrary (and the cluster-robust
    variance can collapse).  Cohorts whose log(age) spread is below
    `min_spread` (an age ratio of about 1.35) are therefore dropped."""
    out = {}
    for si in range(n_study):
        w = [r for r in rows_w if r[0] == si]
        b = [r for r in rows_b if r[0] == si]
        if len(w) < 15 or len(b) < 80:
            continue
        la_w = [r[3] for r in w]
        la_b = [r[3] for r in b]
        if statistics.pstdev(la_w) < min_spread or statistics.pstdev(la_b) < min_spread:
            continue
        fw = fe_slope_single([(0, r[1], r[2], r[3], r[4], r[5]) for r in w], 1)
        fb = fe_slope_single([(0, r[1], r[2], r[3], r[4], r[5]) for r in b], 1)
        if not fw or not fb:
            continue
        if not (0 < fw["se"] < 3 and 0 < fb["se"] < 3):
            continue
        out[si] = {"b_within": fw["slope"], "se_within": fw["se"],
                   "b_between": fb["slope"], "se_between": fb["se"],
                   "n_within": len(w), "n_between": len(b),
                   "sd_log_age": round(statistics.pstdev(la_w), 3)}
    return out


def _dl_pool(eff, se):
    """DerSimonian-Laird random effects on a vector of effects and SEs."""
    k = len(eff)
    if k == 0:
        return None
    w = [1.0 / s ** 2 for s in se]
    mu = sum(wi * e for wi, e in zip(w, eff)) / sum(w)
    q = sum(wi * (e - mu) ** 2 for wi, e in zip(w, eff))
    c = sum(w) - sum(wi ** 2 for wi in w) / sum(w)
    tau2 = max(0.0, (q - (k - 1)) / c) if c > 1e-12 and k > 1 else 0.0
    wr = [1.0 / (s ** 2 + tau2) for s in se]
    mu = sum(wi * e for wi, e in zip(wr, eff)) / sum(wr)
    se = math.sqrt(1.0 / sum(wr))
    i2 = max(0.0, (q - (k - 1)) / q) * 100 if q > 1e-12 else 0.0
    return {"effect": mu, "se": se, "tau2": tau2, "I2": i2, "k": k,
            "p": z_p(mu / se)}


def matched_trends(within, between, n_study, min_cohorts=3):
    """Age slope of within- and between-infant distance inside each interval
    band, estimated cohort by cohort and pooled with random effects.

    Pooling pairs across cohorts with only a study intercept would let the
    between-cohort contrast (dense preterm NICU vs sparse community cohorts)
    drive the result, which is the confounding this analysis exists to
    remove.  Estimating inside each cohort first and meta-analysing keeps every
    contrast within a cohort."""
    out = []
    for db in DT_EDGES:
        w = [r for r in within if db[0] <= math.exp(r[4]) - 1 < db[1]]
        b = [r for r in between if db[0] <= math.exp(r[4]) - 1 < db[1]]
        if len(w) < 40 or len(b) < 400:
            continue
        one = fe_slope_joint(w, b, n_study)   # one-stage, study fixed effects
        per = _cohort_slopes(w, b, n_study)
        if len(per) < min_cohorts:
            continue
        keys = sorted(per)
        diff = [per[s]["b_between"] - per[s]["b_within"] for s in keys]
        dse = [math.sqrt(per[s]["se_between"] ** 2 + per[s]["se_within"] ** 2)
               for s in keys]
        pool = _dl_pool(diff, dse)
        bw = _dl_pool([per[s]["b_within"] for s in keys],
                      [per[s]["se_within"] for s in keys])
        bb = _dl_pool([per[s]["b_between"] for s in keys],
                      [per[s]["se_between"] for s in keys])
        out.append({"dt_lo": db[0], "dt_hi": db[1],
                    "n_within": len(w), "n_between": len(b),
                    "k_cohorts": len(keys),
                    "within": bw, "between": bb, "diff": pool,
                    "one_stage": one,
                    "per_cohort": {k: per[k] for k in keys},
                    "p_within": z_p(bw["effect"] / bw["se"]),
                    "p_between": z_p(bb["effect"] / bb["se"])})
    return out


def cell_means(within, between, ages_edges=AGE_EDGES):
    """R plus its two components in age x interval cells (point estimates)."""
    cells = []
    for ab in ages_edges:
        for db in DT_EDGES:
            w, b = [], []
            for r in within:
                if ab[0] <= math.exp(r[3]) < ab[1] and \
                        db[0] <= math.exp(r[4]) - 1 < db[1]:
                    w.append(r[5])
            for r in between:
                if ab[0] <= math.exp(r[3]) < ab[1] and \
                        db[0] <= math.exp(r[4]) - 1 < db[1]:
                    b.append(r[5])
            if len(w) < 12 or len(b) < 60:
                continue
            mw, mb = statistics.fmean(w), statistics.fmean(b)
            cells.append({"age_lo": ab[0], "age_hi": ab[1],
                          "dt_lo": db[0], "dt_hi": db[1],
                          "n_within": len(w), "n_between": len(b),
                          "within": math.exp(mw), "between": math.exp(mb),
                          "R": math.exp(mb - mw)})
    return cells


def cohort_R_by_dt(studies, n_between=25000):
    """R against interval inside each cohort, pooling ages (heterogeneity check)."""
    out = {}
    for si, study in enumerate(studies):
        rel, age, subj = load(study)
        by = {}
        for i, s in enumerate(subj):
            by.setdefault(s, []).append(i)
        bins = [(1, 14), (14, 60), (60, 1e9)]
        acc = {b: [[], []] for b in bins}
        for s, ii in by.items():
            ii = sorted(ii, key=lambda k: age[k])
            for a in range(len(ii)):
                for b in range(a + 1, len(ii)):
                    i, j = ii[a], ii[b]
                    dt = age[j] - age[i]
                    for bb in bins:
                        if bb[0] <= dt < bb[1]:
                            d = bray(rel[i], rel[j])
                            if d > 0:
                                acc[bb][0].append(math.log(d))
                            break
        rng = random.Random(99 + si)
        keys = list(by)
        if len(keys) >= 2:
            for _ in range(n_between):
                s1, s2 = rng.sample(keys, 2)
                i, j = rng.choice(by[s1]), rng.choice(by[s2])
                dt = abs(age[i] - age[j])
                for bb in bins:
                    if bb[0] <= dt < bb[1]:
                        d = bray(rel[i], rel[j])
                        if d > 0:
                            acc[bb][1].append(math.log(d))
                        break
        rows = []
        for bb in bins:
            w, b = acc[bb]
            if len(w) >= 15 and len(b) >= 100:
                rows.append({"dt_lo": bb[0], "dt_hi": bb[1] if bb[1] < 1e8 else None,
                             "n_within": len(w), "n_between": len(b),
                             "within": math.exp(statistics.fmean(w)),
                             "between": math.exp(statistics.fmean(b)),
                             "R": math.exp(statistics.fmean(b) - statistics.fmean(w))})
        out[study] = rows
    return out


def metric_robustness(studies, n_between=6000):
    """R by interval band under three distances, per cohort, then pooled."""
    res = {}
    for si, study in enumerate(studies):
        rel, age, subj = load(study)
        by = {}
        for i, s in enumerate(subj):
            by.setdefault(s, []).append(i)
        bins = [(1, 14), (14, 60), (60, 1e9)]
        acc = {(b, m): [[], []] for b in bins for m in ("bray", "jac", "ait")}
        for s, ii in by.items():
            ii = sorted(ii, key=lambda k: age[k])
            for a in range(len(ii)):
                for b in range(a + 1, len(ii)):
                    i, j = ii[a], ii[b]
                    dt = age[j] - age[i]
                    for bb in bins:
                        if bb[0] <= dt < bb[1]:
                            for m, fn in (("bray", bray), ("jac", jaccard),
                                          ("ait", clr_euclid)):
                                d = fn(rel[i], rel[j])
                                if d > 0:
                                    acc[(bb, m)][0].append(math.log(d))
                            break
        rng = random.Random(1234 + si)
        keys = list(by)
        if len(keys) >= 2:
            for _ in range(n_between):
                s1, s2 = rng.sample(keys, 2)
                i, j = rng.choice(by[s1]), rng.choice(by[s2])
                dt = abs(age[i] - age[j])
                for bb in bins:
                    if bb[0] <= dt < bb[1]:
                        for m, fn in (("bray", bray), ("jac", jaccard),
                                      ("ait", clr_euclid)):
                            d = fn(rel[i], rel[j])
                            if d > 0:
                                acc[(bb, m)][1].append(math.log(d))
                        break
        rows = []
        for bb in bins:
            for m in ("bray", "jac", "ait"):
                w, b = acc[(bb, m)]
                if len(w) >= 15 and len(b) >= 100:
                    rows.append({"metric": m, "dt_lo": bb[0],
                                 "dt_hi": bb[1] if bb[1] < 1e8 else None,
                                 "R": math.exp(statistics.fmean(b) - statistics.fmean(w))})
        res[study] = rows
        print(f"  metric robustness {study} done", flush=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    studies = STUDIES
    n_study = len(studies)

    print("collecting pairs ...", flush=True)
    within, between, info = collect(studies)
    print(f"  {len(within)} within, {len(between)} between pairs", flush=True)

    print("matched age trends ...", flush=True)
    trends = matched_trends(within, between, n_study)
    for t in trends:
        w, b, d = t["within"], t["between"], t["diff"]
        print(f"  dt {t['dt_lo']:>4g}-{t['dt_hi']:<5g} k={d['k']}  "
              f"within {w['effect']:+.3f} ({w['se']:.3f})  "
              f"between {b['effect']:+.3f} ({b['se']:.3f})  "
              f"diff {d['effect']:+.3f} ({d['se']:.3f}) p={d['p']:.3g} "
              f"I2={d['I2']:.0f}%")

    print("cells ...", flush=True)
    cells = cell_means(within, between)

    print("cohort R by interval ...", flush=True)
    cohort_R = cohort_R_by_dt(studies)

    robust = None if args.quick else metric_robustness(studies)

    # term-only replication of the headline
    term_idx = [i for i, s in enumerate(studies) if s not in PRETERM]
    keep = {i: k for k, i in enumerate(term_idx)}
    w_t = [(keep[r[0]], r[1], r[2], r[3], r[4], r[5]) for r in within
           if r[0] in keep]
    b_t = [(keep[r[0]], r[1], r[2], r[3], r[4], r[5]) for r in between
           if r[0] in keep]
    print("term-only matched trends ...", flush=True)
    trends_term = matched_trends(w_t, b_t, len(keep))
    cells_term = cell_means(w_t, b_t)

    out = {"cohorts": info, "trends": trends, "cells": cells,
           "cohort_R": cohort_R,
           "trends_term_only": trends_term, "cells_term_only": cells_term,
           "metric_robustness": robust,
           "preterm_excluded": sorted(PRETERM)}
    with open(os.path.join(args.out_dir, "revision.json"), "w") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"wrote {args.out_dir}/revision.json")


if __name__ == "__main__":
    main()
