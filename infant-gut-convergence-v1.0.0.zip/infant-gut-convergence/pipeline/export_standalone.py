#!/usr/bin/env python3
"""Export the 5 figures and 3 tables of manuscript v3 as standalone files."""
import json, csv, re, os, shutil

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES  = os.path.join(BASE, "results", "real")
OUT  = os.path.join(BASE, "figures_tables_standalone")
os.makedirs(OUT, exist_ok=True)

# ---------------- figures: copy svg + png with clean names ----------------
figs = [
    ("fig1_cohorts",     "Figure1_sampling_design"),
    ("fig2_ratio",       "Figure2_R_vs_interval"),
    ("fig3_agetrends",   "Figure3_age_trends"),
    ("fig4_cohortmetric","Figure4_cohorts_and_distances"),
    ("fig5_icc",         "Figure5_species_ICC"),
]
for src, dst in figs:
    for ext in ("svg", "png"):
        s = os.path.join(RES, src + "." + ext)
        if not os.path.exists(s):
            s = os.path.join(RES, "png", src + "." + ext)
        d = os.path.join(OUT, dst + "." + ext)
        shutil.copy2(s, d)
        print("copied", d)

# ---------------- shared formatting helpers (mirror manuscript JS) ----------------
def band(lo, hi):
    if lo >= 800: return ">2 y"
    if lo >= 365: return "1-2 y"
    if lo >= 180: return "6-12 mo"
    if lo >= 90:  return "3-6 mo"
    if lo >= 30:  return "1-3 mo"
    return "0-1 mo"

def dtband(lo, hi):
    if hi is None or hi >= 1e8: return f">{lo}"
    return f"{lo}-{hi}"

def fmt(x, d=3):
    return "—" if x is None else f"{x:.{d}f}"

CSS = """
  body { background:#fff; margin:24px; font-family:"Times New Roman", Georgia, serif; color:#111; }
  h1 { font-size:15px; font-weight:600; margin:0 0 14px; }
  table { width:100%; border-collapse:collapse; font-size:10px; margin:8px 0 4px; }
  th, td { padding:4px 7px; border-bottom:0.5px solid #bbb; text-align:left; }
  th { border-bottom:1.2px solid #222; font-weight:600; }
  td.n, th.n { text-align:right; }
  .caption { font-size:10.5px; line-height:1.55; color:#333; margin-bottom:6px; }
"""

def write_table(name, title, caption, header, rows, csv_rows):
    # CSV
    with open(os.path.join(OUT, name + ".csv"), "w", newline="") as f:
        w = csv.writer(f)
        for r in csv_rows:
            w.writerow(r)
    # standalone HTML
    html = [f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>{title}</title><style>{CSS}
  @page {{ size: A4; margin: 0; }}</style></head><body>
<h1>{title}</h1><div class="caption"><strong>{caption}</strong></div>
<table>"""]
    html.append("<tr>" + "".join(
        f"<th class='n'>{h}</th>" if n else f"<th>{h}</th>"
        for h, n in header) + "</tr>")
    for r in rows:
        html.append("<tr>" + "".join(
            f"<td class='n'>{c}</td>" if n else f"<td>{c}</td>"
            for c, n in r) + "</tr>")
    html.append("</table></body></html>")
    with open(os.path.join(OUT, name + ".html"), "w") as f:
        f.write("\n".join(html))
    print("wrote", os.path.join(OUT, name + ".html"), "and .csv")

# ---------------- Table 1: cohorts ----------------
with open(os.path.join(RES, "table1.csv")) as f:
    t1 = list(csv.reader(f))
hdr = t1[0]
rows1, csv1 = [], [["Cohort", "Accession", "Country", "Design", "Samples", "Infants",
                    "Median visits", "Median interval (d)", "Age range (d)"]]
for r in t1[1:]:
    m = dict(zip(hdr, r))
    row = [(m["label"], 0), (m["accession"], 0), (m["country"], 0), (m["design"], 0),
           (m["n_samples"], 1), (m["n_subjects"], 1), (m["visits_median"], 1),
           (m["gap_median_d"], 1), (f"{m['age_min_d']}–{m['age_max_d']}", 1)]
    rows1.append(row)
    csv1.append([c for c, _ in row])
write_table(
    "Table1_cohorts", "Table 1. The seven cohorts",
    "Table 1. The seven cohorts. All abundance tables and metadata were retrieved from "
    "curatedMetagenomicData (ExperimentHub); BioProject accessions are listed per cohort; "
    "infant ages were re-anchored within each subject (see Methods).",
    [("Cohort",0),("Accession",0),("Country",0),("Design",0),("Samples",1),("Infants",1),
     ("Median visits",1),("Median interval (d)",1),("Age range (d)",1)],
    rows1, csv1)

# ---------------- Table 2: strata ----------------
with open(os.path.join(RES, "strata.json")) as f:
    d2 = json.load(f)
rows2, csv2 = [], [["Age", "Interval (d)", "n within", "n between",
                    "within", "between", "R", "95% CI"]]
for c in d2["cells"]:
    row = [(band(c["age_lo"], c["age_hi"]), 0),
           (dtband(c["dt_lo"], c["dt_hi"]), 0),
           (f"{c['n_within']:,}", 1), (f"{c['n_between']:,}", 1),
           (fmt(c["within"]), 1), (fmt(c["between"]), 1),
           (f"<strong>{fmt(c['ratio'],2)}</strong>", 1),
           (f"{fmt(c['lo'],2)}–{fmt(c['hi'],2)}", 1)]
    rows2.append(row)
    csv2.append([re.sub("<[^>]+>", "", x) for x, _ in row])
write_table(
    "Table2_strata_R", "Table 2. R in strata matched on age and interval",
    "Table 2. R in strata matched on age and interval (leaf partition, Bray–Curtis). Within and "
    "between are mean distances; R is their ratio. CIs are 95% cluster-bootstrap intervals over "
    "infants. Cells with fewer than 12 within-infant or 60 between-infant pairs are omitted. "
    "R = 1 means an infant is exactly as far from itself as from a stranger.",
    [("Age",0),("Interval (d)",0),("n within",1),("n between",1),
     ("within",1),("between",1),("R",1),("95% CI",1)],
    rows2, csv2)

# ---------------- Table 3: age slopes ----------------
with open(os.path.join(RES, "age_trends_primary.json")) as f:
    p = json.load(f)
with open(os.path.join(RES, "age_trends_term_only.json")) as f:
    q = json.load(f)

def cirow(e, s):
    return f"{fmt(e)} ({fmt(e-1.96*s)}, {fmt(e+1.96*s)})"

def pooled_row(t, v):
    return [(t, 0), (cirow(v["pooled_between"]["effect"], v["pooled_between"]["se"]), 1),
            (cirow(v["pooled_within"]["effect"], v["pooled_within"]["se"]), 1),
            (cirow(v["pooled_R"]["effect"], v["pooled_R"]["se"]), 1)]

rows3, csv3 = [], [["Interval band (d)", "d log between / d log age (95% CI)",
                    "d log within (95% CI)", "d log R (95% CI)"]]
for r in p["rows"]:
    row = [(dtband(r["dt_lo"], r["dt_hi"]), 0),
           (cirow(r["between_slope"], r["between_se"]), 1),
           (cirow(r["within_slope"], r["within_se"]), 1),
           (cirow(r["R_slope"], r["R_se"]), 1)]
    rows3.append(row)
    csv3.append([re.sub("<[^>]+>", "", x) for x, _ in row])
for t, v in [("Pooled, all seven cohorts", p), ("Pooled, six term cohorts", q)]:
    rows3.append(pooled_row(f"<strong>{t}</strong>", v))
    csv3.append([t, cirow(v["pooled_between"]["effect"], v["pooled_between"]["se"]),
                 cirow(v["pooled_within"]["effect"], v["pooled_within"]["se"]),
                 cirow(v["pooled_R"]["effect"], v["pooled_R"]["se"])])
write_table(
    "Table3_age_slopes", "Table 3. Age slopes at matched interval",
    "Table 3. Age slopes at matched interval (per e-fold of age), from weighted regression on the "
    "matched cells, pooled across interval bands with random effects. All seven cohorts (primary) "
    "or the six term cohorts (sensitivity).",
    [("Interval band (d)",0),("d log between / d log age (95% CI)",1),
     ("d log within (95% CI)",1),("d log R (95% CI)",1)],
    rows3, csv3)

print("done")
