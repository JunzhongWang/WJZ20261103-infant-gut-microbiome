#!/usr/bin/env python3
"""Supplementary Figure S1: functional (pathway) robustness of R.

Panel A: R against sampling interval, pathway-based (HUMAnN), one line per age
         band, with 95% cluster-bootstrap shadows — the functional analogue of
         Figure 2.
Panel B: the same age-pooled comparison under the taxonomic (species,
         MetaPhlAn) and the functional (pathway, HUMAnN) profile, per interval
         band.
"""
import json
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "real")
INK, MUTED, GRID, PAPER = "#1a1a18", "#6b6a65", "#e6e8e6", "#ffffff"
FONT = "'Helvetica Neue', Arial, sans-serif"
BANDS = [(0, 30, "0–1 mo"), (30, 90, "1–3 mo"), (90, 180, "3–6 mo"),
         (180, 365, "6–12 mo"), (365, 800, "1–2 y"), (800, 1e9, ">2 y")]
BAND_COLOR = ["#0F6E56", "#3C6E9F", "#7A8B2F", "#C2703A", "#8A6FA8", "#4C4C4C"]


def head(w, h, title, desc):
    return [f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
            f'role="img" width="100%">',
            f'<rect width="{w}" height="{h}" fill="{PAPER}"/>',
            f'<title>{title}</title><desc>{desc}</desc>',
            f'<g font-family="{FONT}">']


def axis(x0, y0, w, h, xticks, yticks, xlab, ylab, xr=(1, 1000), yr=(0.4, 3.0)):
    s = []
    s.append(f'<line x1="{x0}" y1="{y0+h}" x2="{x0+w}" y2="{y0+h}" '
             f'stroke="{MUTED}" stroke-width="0.8"/>')
    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y0+h}" '
             f'stroke="{MUTED}" stroke-width="0.8"/>')
    a, b = math.log10(xr[0]), math.log10(xr[1])
    f = lambda v: x0 + (math.log10(max(v, xr[0])) - a) / (b - a) * w
    g = lambda v: y0 + h - (v - yr[0]) / (yr[1] - yr[0]) * h
    for t in yticks:
        s.append(f'<line x1="{x0}" y1="{g(t):.1f}" x2="{x0+w}" y2="{g(t):.1f}" '
                 f'stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{x0-7}" y="{g(t)+3:.1f}" font-size="8.5" '
                 f'fill="{MUTED}" text-anchor="end">{t:g}</text>')
    for t, lab in xticks:
        s.append(f'<line x1="{f(t):.1f}" y1="{y0+h}" x2="{f(t):.1f}" '
                 f'y2="{y0+h+3.5}" stroke="{MUTED}" stroke-width="0.8"/>')
        s.append(f'<text x="{f(t):.1f}" y="{y0+h+15}" font-size="8.5" '
                 f'fill="{MUTED}" text-anchor="middle">{lab}</text>')
    s.append(f'<text x="{x0+w/2}" y="{y0+h+32}" font-size="9.5" fill="{INK}" '
             f'text-anchor="middle">{xlab}</text>')
    s.append(f'<text transform="translate({x0-40},{y0+h/2}) rotate(-90)" '
             f'font-size="9.5" fill="{INK}" text-anchor="middle">{ylab}</text>')
    return s, f, g


def main():
    d = json.load(open(os.path.join(OUT, "functional_R.json")))
    cells = d["cells"]
    func_bands = d["func_bands"]
    tax_bands = d["tax_bands"]

    W, H = 680, 300
    s = head(W, H, "Supplementary Figure S1",
             "Functional-level robustness of R under pathway profiles")
    # ---- Panel A (x 60..360), Panel B (x 420..640)
    xticks = [(1, "1"), (7, "7"), (30, "30"), (90, "90"), (180, "180"),
              (365, "1 y"), (730, "2 y")]
    yticks = [0.5, 1, 1.5, 2, 2.5, 3]

    s.append('<text x="60" y="16" font-size="10" font-weight="600" fill="ink">'
             '</text>')
    s.append(f'<text x="60" y="18" font-size="10" font-weight="600" '
             f'fill="{INK}">A   R(interval), pathway profile</text>')
    ax, f, g = axis(60, 34, 300, 210, xticks, yticks,
                    "Interval between samples (days, log scale)",
                    "R (between ÷ within)", xr=(1, 800), yr=(0.4, 3.0))
    s += ax
    s.append(f'<line x1="60" y1="{g(1):.1f}" x2="360" y2="{g(1):.1f}" '
             f'stroke="{MUTED}" stroke-width="0.9" stroke-dasharray="4 3"/>')

    for bi, (alo, ahi, lab) in enumerate(BANDS):
        pts = []
        for c in cells:
            if c["age_lo"] != alo:
                continue
            lo, hi = c["dt_lo"], c["dt_hi"]
            mid = math.sqrt(lo * hi) if hi and hi < 1e8 else lo * 1.9
            pts.append((mid, c))
        if not pts:
            continue
        pts.sort()
        col = BAND_COLOR[bi]
        # CI shadow
        up = [(f(m), g(c["hi"])) for m, c in pts if c.get("hi")]
        dn = [(f(m), g(c["lo"])) for m, c in pts if c.get("lo")]
        if len(up) >= 2:
            poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in up) + " " + \
                   " ".join(f"{x:.1f},{y:.1f}" for x, y in reversed(dn))
            s.append(f'<polygon points="{poly}" fill="{col}" fill-opacity="0.13"/>')
        line = " ".join(f"{f(m):.1f},{g(c['ratio']):.1f}" for m, c in pts)
        s.append(f'<polyline points="{line}" fill="none" stroke="{col}" '
                 f'stroke-width="1.6"/>')
        for m, c in pts:
            s.append(f'<circle cx="{f(m):.1f}" cy="{g(c["ratio"]):.1f}" r="2.4" '
                     f'fill="{col}"/>')

    # legend for age bands (right of panel A, stacked left of panel B)
    ly = 44
    for bi, (alo, ahi, lab) in enumerate(BANDS):
        if bi == 0:
            s.append(f'<text x="376" y="{ly-6}" font-size="7.5" fill="{MUTED}">'
                     f'Age band</text>')
        s.append(f'<line x1="376" y1="{ly}" x2="390" y2="{ly}" '
                 f'stroke="{BAND_COLOR[bi]}" stroke-width="2"/>')
        s.append(f'<text x="394" y="{ly+2.5}" font-size="7.5" fill="{INK}">'
                 f'{lab}</text>')
        ly += 11

    # ---- Panel B: functional vs taxonomic, band-level
    s.append(f'<text x="470" y="18" font-size="10" font-weight="600" '
             f'fill="{INK}">B   Taxonomic vs functional</text>')
    bx0, by0, bw, bh = 470, 34, 170, 210
    cats = [b for b in func_bands]
    labels = {"1": "1–14 d", "14": "14–60 d", "60": ">60 d"}
    ymax = 3.0
    slot = bw / max(len(cats), 1)
    s += [f'<line x1="{bx0}" y1="{by0+bh}" x2="{bx0+bw}" y2="{by0+bh}" '
          f'stroke="{MUTED}" stroke-width="0.8"/>']
    s += [f'<line x1="{bx0}" y1="{by0}" x2="{bx0}" y2="{by0+bh}" '
          f'stroke="{MUTED}" stroke-width="0.8"/>']
    for t in [1, 2, 3]:
        gy = by0 + bh - (t / ymax) * bh
        s.append(f'<line x1="{bx0}" y1="{gy:.1f}" x2="{bx0+bw}" y2="{gy:.1f}" '
                 f'stroke="{GRID}" stroke-width="0.7"/>')
        s.append(f'<text x="{bx0-7}" y="{gy+3:.1f}" font-size="8.5" fill="{MUTED}" '
                 f'text-anchor="end">{t}</text>')
    # dashed R=1
    gy1 = by0 + bh - (1 / ymax) * bh
    s.append(f'<line x1="{bx0}" y1="{gy1:.1f}" x2="{bx0+bw}" y2="{gy1:.1f}" '
             f'stroke="{MUTED}" stroke-width="0.9" stroke-dasharray="4 3"/>')
    taxmap = {b["dt_lo"]: b["R"] for b in tax_bands}
    for i, b in enumerate(cats):
        cx = bx0 + slot * i + slot / 2
        r_t = taxmap.get(b["dt_lo"])
        r_f = b["R"]
        w = 20
        if r_t:
            h1 = (r_t / ymax) * bh
            s.append(f'<rect x="{cx-w-3:.1f}" y="{by0+bh-h1:.1f}" width="{w}" '
                     f'height="{h1:.1f}" fill="#4C4C4C"/>')
        h2 = (r_f / ymax) * bh
        s.append(f'<rect x="{cx+3:.1f}" y="{by0+bh-h2:.1f}" width="{w}" '
                 f'height="{h2:.1f}" fill="#0F6E56"/>')
        s.append(f'<text x="{cx:.1f}" y="{by0+bh+15}" font-size="8.5" '
                 f'fill="{MUTED}" text-anchor="middle">'
                 f'{labels.get(str(b["dt_lo"]), b["dt_lo"])}</text>')
        s.append(f'<text x="{cx-w-3+w/2:.1f}" y="{by0+bh-h1-3:.1f}" font-size="7.5" '
                 f'fill="{INK}" text-anchor="middle">{r_t:.2f}</text>')
        s.append(f'<text x="{cx+3+w/2:.1f}" y="{by0+bh-h2-3:.1f}" font-size="7.5" '
                 f'fill="{INK}" text-anchor="middle">{r_f:.2f}</text>')
    s.append(f'<rect x="{bx0}" y="{by0-16}" width="10" height="8" fill="#4C4C4C"/>')
    s.append(f'<text x="{bx0+14}" y="{by0-9}" font-size="7.5" fill="{INK}">'
             f'species (MetaPhlAn)</text>')
    s.append(f'<rect x="{bx0+110}" y="{by0-16}" width="10" height="8" '
             f'fill="#0F6E56"/>')
    s.append(f'<text x="{bx0+124}" y="{by0-9}" font-size="7.5" fill="{INK}">'
             f'pathway (HUMAnN)</text>')
    s.append(f'<text x="{bx0+bw/2}" y="{by0+bh+32}" font-size="9.5" fill="{INK}" '
             f'text-anchor="middle">Interval band</text>')

    s.append("</g></svg>")
    path = os.path.join(OUT, "figS1_functional.svg")
    with open(path, "w") as fh:
        fh.write("\n".join(s))
    print("wrote", path)


if __name__ == "__main__":
    main()
