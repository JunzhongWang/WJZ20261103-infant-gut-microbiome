#!/usr/bin/env python3
"""Per-taxon individual signature: variance partition on CLR abundances.

    python3 pipeline/taxon_icc.py --dir data/BackhedF_2015 [--min-prev 0.5]

For every taxon we ask: how much of its variance is between infants rather
than within an infant over time? That is the quantity a "microbial individual
signature" claim actually rests on — a diversity index throws it away.

Output: taxon_icc.tsv (all taxa) + a short console summary.
"""
import argparse
import csv
import importlib.util
import math
import os
import statistics

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("ip", os.path.join(HERE, "infant_pipeline.py"))
ip = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ip)


def clr(vec):
    """Centred log-ratio with a multiplicative-style pseudocount."""
    pos = [v for v in vec if v > 0]
    pc = (min(pos) / 2) if pos else 1e-6
    lg = [math.log(v + pc) for v in vec]
    m = statistics.fmean(lg)
    return [x - m for x in lg]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--min-prev", type=float, default=0.5)
    ap.add_argument("--top", type=int, default=15)
    args = ap.parse_args()

    ids, names, counts = ip.load_table(os.path.join(args.dir, "community.csv"))
    meta = {r["sample_id"]: r for r in ip.read_csv(os.path.join(args.dir, "meta.csv"))}
    keep = [i for i, s in enumerate(ids) if s in meta]
    ids = [ids[i] for i in keep]
    counts = [counts[i] for i in keep]
    subj = [meta[s]["subject_id"] for s in ids]
    days = [ip.to_float(meta[s].get("days"), 0.0) for s in ids]
    print(f"{args.dir}: {len(ids)} samples, {len(set(subj))} subjects, {len(names)} taxa")

    # CLR per sample
    rel = [[max(v, 0.0) for v in row] for row in counts]
    tot = [sum(r) for r in rel]
    rel = [[v / t if t else 0.0 for v in r] for r, t in zip(rel, tot)]
    mat = [clr(r) for r in rel]

    # de-trend each taxon on the population curve so that age is not counted
    # as an individual signature
    knots = [0.0, 180.0, 540.0]
    rows = []
    for j, name in enumerate(names):
        y = [m[j] for m in mat]
        prev = sum(1 for r in rel if r[j] > 0) / len(rel)
        if prev < args.min_prev:
            continue
        curve = ip.fit_population_curve(days, y, knots)
        if curve.get("ok"):
            res = [a - b for a, b in zip(y, curve["fitted"])]
        else:
            res = y
        groups = {}
        for s, r in zip(subj, res):
            groups.setdefault(s, []).append(r)
        icc = ip.icc_oneway(list(groups.values()))
        if icc is None:
            continue
        allv = [v for g in groups.values() for v in g]
        rows.append({
            "taxon": name, "prevalence": prev, "icc": icc,
            "mean_clr_sd": statistics.pstdev(allv),
            "between_sd": statistics.pstdev([statistics.fmean(g) for g in groups.values()]),
            "n_subjects": len(groups),
        })

    rows.sort(key=lambda r: -r["icc"])
    out = os.path.join(args.dir, "taxon_icc.tsv")
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter="\t", lineterminator="\n")
        w.writeheader()
        for r in rows:
            w.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in r.items()})

    print(f"\ntaxa tested (prevalence >= {args.min_prev:.0%}): {len(rows)}")
    print(f"median ICC: {statistics.median([r['icc'] for r in rows]):.3f}   "
          f"share with ICC > 0.3: {sum(1 for r in rows if r['icc'] > 0.3)/len(rows):.1%}")
    print(f"\ntop {args.top} individual signatures:")
    for r in rows[: args.top]:
        print(f"  {r['taxon'][:44]:46s} ICC={r['icc']:.2f}  prev={r['prevalence']:.2f}")
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
