#!/bin/bash
set -e
cd "$(dirname "$0")/.."
STUDIES="VatanenT_2016 ShaoY_2019 BackhedF_2015 YassourM_2018"
python3 pipeline/fetch_cmd3_direct.py --study $STUDIES
mkdir -p results/real
for s in $STUDIES; do
  echo "=== analyze $s ==="
  python3 pipeline/infant_pipeline.py analyze --dir data/$s > results/real/$s.json 2>&1 || true
  python3 pipeline/taxon_icc.py --dir data/$s > results/real/$s.taxon.txt 2>&1 || true
  tail -1 results/real/$s.taxon.txt
done
echo ALLDONE
