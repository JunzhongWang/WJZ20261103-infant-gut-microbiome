#!/bin/bash
# ---------------------------------------------------------------------------
# check_network.sh — what does this machine actually need to reach cMD3?
#
#   bash pipeline/check_network.sh
#
# Reports, for every host in the chain: DNS, TLS/HTTP, HTTP range support and
# whether a large file arrives intact. Exit code 0 means the direct fetch will
# work; non-zero names the failing link.
# ---------------------------------------------------------------------------

set -u
fail=0

say() { printf '%-46s %s\n' "$1" "$2"; }

check_host() {          # host, url, min_bytes
  local host="$1" url="$2" min="${3:-0}"

  if ! python3 -c "import socket,sys; socket.gethostbyname(sys.argv[1])" "$host" 2>/dev/null; then
    say "$host" "DNS FAIL"; fail=1; return
  fi
  local ip
  ip=$(python3 -c "import socket,sys; print(socket.gethostbyname(sys.argv[1]))" "$host")

  local code
  code=$(curl -sI -o /dev/null -w '%{http_code}' --max-time 25 "$url" 2>/dev/null || echo 000)
  if [ "$code" = "000" ]; then
    say "$host" "DNS ok ($ip)  HTTP FAIL"; fail=1; return
  fi

  local ranges
  ranges=$(curl -sI --max-time 25 "$url" 2>/dev/null | tr -d '\r' | grep -i '^accept-ranges' | awk '{print $2}')
  say "$host" "DNS ok ($ip)  HTTP $code  ranges=${ranges:-none}"

  if [ "$min" -gt 0 ]; then
    # one shot download: does the full body arrive?
    local got
    got=$(curl -sL --max-time 90 "$url" -o /tmp/_cn.bin -w '%{size_download}' 2>/dev/null || echo 0)
    if [ "$got" -ge "$min" ]; then
      say "  full-body test" "$got bytes  OK"
    else
      say "  full-body test" "$got / $min bytes  TRUNCATED (need range/resume)"
    fi
  fi
}

echo "== cMD3 fetch chain =="
check_host "experimenthub.bioconductor.org" \
           "https://experimenthub.bioconductor.org/metadata/experimenthub.sqlite3" 10378240
check_host "mghp.osn.xsede.org" \
           "https://mghp.osn.xsede.org/bir190004-bucket01/ExperimentHub/curatedMetagenomicData/2021-03-31/VatanenT_2016/2021-03-31.VatanenT_2016.relative_abundance.rda" 336000

echo
echo "== R =="
if command -v Rscript >/dev/null 2>&1; then
  say "Rscript" "$(Rscript -e 'cat(R.version.string)' 2>/dev/null)"
  say "  Bioconductor packages" "not required (base R reads the .rda)"
else
  say "Rscript" "MISSING - needed only to unpack .rda"; fail=1
fi

echo
echo "== summary =="
if [ "$fail" -eq 0 ]; then
  echo "OK: run  python3 pipeline/fetch_cmd3_direct.py --study VatanenT_2016"
else
  echo "BLOCKED: see failing line above."
  echo "If DNS fails, the host is filtered — try another network (phone hotspot),"
  echo "or set a resolver, then re-run. If only bodies truncate, the resume loop"
  echo "in fetch_cmd3_direct.py already handles it."
fi
exit "$fail"
