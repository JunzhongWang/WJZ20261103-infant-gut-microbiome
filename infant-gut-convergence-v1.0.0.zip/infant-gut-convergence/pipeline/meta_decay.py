#!/usr/bin/env python3
"""How fast does the individual signature decay with age?

For every cohort we bucket sample pairs by elapsed time, compute the
within-/between-subject Bray-Curtis ratio in each bucket, attach a
cluster-bootstrap confidence interval (resampling *subjects*, not pairs --
pairs are not independent), fit log(ratio) against log(age), and then pool the
per-cohort slopes with a DerSimonian-Laird random-effects model.

    python3 pipeline/meta_decay.py --studies VatanenT_2016 ShaoY_2019 \
                                   BackhedF_2015 YassourM_2018 --boot 2000

Outputs
    results/real/meta_decay.json     full record (per-bucket ratios + CIs, slopes)
    results/real/meta_buckets.csv    tidy table, one row per cohort-bucket
    results/real/meta_slopes.csv     one row per cohort slope + pooled estimate

Design notes
------------
* Pairs are pooled once, per (bucket, subject-pair) for between-subject pairs
  and per (bucket, subject) for within-subject pairs. A bootstrap replicate is
  then just a reweighting of those pools: a within pair keeps weight m_s and a
  between pair keeps weight m_s1 * m_s2, where m is the number of times that
  subject was drawn. This is the exact cluster bootstrap for a pair-mean
  statistic and it costs O(#pairs), not O(#pairs x #bootstrap).
* Only balanced buckets (>= 8 within pairs and >= 200 between pairs) enter the
  slope fit; the within side is the noisy one in small cohorts.
* The slope is in log(ratio) per log(day), so the effect size reported to the
  reader is 2**slope - 1 == the multiplicative change in the ratio per doubling
  of age. Negative = the signature decays.
"""
import argparse
import csv
import json
import math
import os
import random
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Buckets are age strata, not interval strata: the pair is placed on the axis at
# the age of its LATER sample, so every bucket answers "at this age, how similar
# is an infant to itself dt days back, versus to another infant of the same age".
# A minimum interval keeps same-visit duplicates from inflating the within side.
BUCKETS = [(0, 14), (14, 60), (60, 180), (180, 365), (365, 1e9)]
MIN_DT = 7
MIN_WITHIN = 8
MIN_BETWEEN = 200
N_BETWEEN_DRAWS = 80000


# ------------------------------------------------------------------ io


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def load_cohort(study):
    d = os.path.join(ROOT, "data", study)
    sp = read_csv(os.path.join(d, "species.csv"))
    meta = {r["sample_id"]: r for r in read_csv(os.path.join(d, "meta.csv"))}
    names = [c for c in sp[0] if c != "sample_id"]
    ids, rel = [], []
    for r in sp:
        sid = r["sample_id"]
        if sid not in meta:
            continue
        v = [float(r[n] or 0.0) for n in names]
        tot = sum(v)
        if tot <= 0:
            continue
        ids.append(sid)
        rel.append([x / tot for x in v])
    keep = [i for i, s in enumerate(ids) if s in meta]
    meta_ok = []
    for i in keep:
        days = meta[ids[i]].get("days", "")
        if days in ("", "NA"):
            continue
        meta_ok.append(i)
    ids = [ids[i] for i in meta_ok]
    rel = [rel[i] for i in meta_ok]
    days = [float(meta[s]["days"]) for s in ids]
    subj = [meta[s]["subject_id"] for s in ids]
    return ids, rel, days, subj


def bray(a, b):
    num = den = 0.0
    for x, y in zip(a, b):
        d = x - y
        if d < 0:
            d = -d
        num += d
        den += x + y
    return num / den if den else 0.0


def blabel(bk):
    hi = "inf" if bk[1] >= 1e9 else f"{bk[1]:g}"
    return f"{bk[0]:g}-{hi}d"


def bucket_of(age):
    for b in BUCKETS:
        if b[0] <= age < b[1]:
            return b
    return None


# ------------------------------------------------------- pair pooling


def pool_pairs(rel, days, subj, seed=20261102, n_draws=N_BETWEEN_DRAWS):
    """Aggregate pairwise distances into (bucket, subject) cells."""
    by_subj = {}
    for i, s in enumerate(subj):
        by_subj.setdefault(s, []).append(i)
    keys = list(by_subj)

    within = {}          # (bucket, subject) -> [sum_dist, n, sum_of_later_age]
    for s, idx in by_subj.items():
        for a in range(len(idx)):
            for b in range(a + 1, len(idx)):
                dt = abs(days[idx[a]] - days[idx[b]])
                if dt < MIN_DT:
                    continue          # (near-)same-day repeats carry no elapsed-time info
                bk = bucket_of(max(days[idx[a]], days[idx[b]]))
                if bk is None:
                    continue
                cell = within.get((bk, s))
                dv = bray(rel[idx[a]], rel[idx[b]])
                # the later sample anchors the pair on the age axis: "how
                # similar is this infant to itself, looking back dt days"
                am = max(days[idx[a]], days[idx[b]])
                if cell is None:
                    within[(bk, s)] = [dv, 1, am]
                else:
                    cell[0] += dv
                    cell[1] += 1
                    cell[2] += am

    rng = random.Random(seed)
    between = {}         # (bucket, s1, s2) -> [sum, n]
    n_drawn = 0
    for _ in range(n_draws):
        s1, s2 = rng.sample(keys, 2)
        i = rng.choice(by_subj[s1])
        j = rng.choice(by_subj[s2])
        if abs(days[i] - days[j]) < MIN_DT:
            continue
        bk = bucket_of(max(days[i], days[j]))
        if bk is None:
            continue
        n_drawn += 1
        cell = between.get((bk, s1, s2))
        dv = bray(rel[i], rel[j])
        if cell is None:
            between[(bk, s1, s2)] = [dv, 1]
        else:
            cell[0] += dv
            cell[1] += 1
    return keys, within, between, n_drawn


def point_estimate(bk, keys, within, between):
    ws = wn = wam = bs = bn = 0.0
    for s in keys:
        c = within.get((bk, s))
        if c:
            ws += c[0]
            wn += c[1]
            wam += c[2]
    for (b, s1, s2), c in between.items():
        if b is bk:
            bs += c[0]
            bn += c[1]
    if wn <= 0 or bn <= 0:
        return None
    w = ws / wn
    bw = bs / bn
    return {"within": w, "between": bw, "ratio": bw / w if w > 0 else None,
            "n_within": int(wn), "n_between": int(bn),
            "age_mid": wam / wn if wn else None}


def bootstrap_ratio(bk, keys, within, between, B, rng):
    """Cluster bootstrap: resample subjects, reweight the pair pools."""
    # pre-slice this bucket once
    wtab = [(keys.index(s), c[0], c[1]) for s in keys
            for c in [within.get((bk, s))] if c]
    idx = {s: i for i, s in enumerate(keys)}
    btab = [(idx[s1], idx[s2], c[0], c[1])
            for (b, s1, s2), c in between.items() if b is bk]
    k = len(keys)
    out = []
    for _ in range(B):
        m = [0] * k
        for _ in range(k):
            m[rng.randrange(k)] += 1
        ws = wn = 0.0
        for a, sm, n in wtab:
            mult = m[a]
            if mult:
                ws += sm * mult
                wn += n * mult
        bs = bn = 0.0
        for a, b2, sm, n in btab:
            mult = m[a] * m[b2]
            if mult:
                bs += sm * mult
                bn += n * mult
        if wn <= 0 or bn <= 0:
            continue
        w = ws / wn
        if w <= 0:
            continue
        out.append((bs / bn) / w)
    return out


def quantile(v, q):
    if not v:
        return None
    s = sorted(v)
    pos = q * (len(s) - 1)
    lo = int(math.floor(pos))
    hi = min(lo + 1, len(s) - 1)
    frac = pos - lo
    return s[lo] * (1 - frac) + s[hi] * frac


# ------------------------------------------------------------ regression


def wls_slope(points):
    """Weighted least squares of log(ratio) on log(age_mid).

    points: list of (age_days, log_ratio, se_log_ratio)
    Returns slope, se, plus a plain unweighted check.
    """
    pts = [p for p in points if p[2] and p[2] > 0]
    if len(pts) < 2:
        return None
    xs = [math.log(p[0]) for p in pts]
    ys = [p[1] for p in pts]
    ws = [1.0 / (p[2] ** 2) for p in pts]
    sw = sum(ws)
    mx = sum(w * x for w, x in zip(ws, xs)) / sw
    my = sum(w * y for w, y in zip(ws, ys)) / sw
    sxx = sum(w * (x - mx) ** 2 for w, x in zip(ws, xs))
    if sxx <= 0:
        return None
    sxy = sum(w * (x - mx) * (y - my) for w, x, y in zip(ws, xs, ys))
    slope = sxy / sxx
    if len(pts) > 2:
        resid = [y - (my + slope * (x - mx)) for x, y in zip(xs, ys)]
        # weighted residual variance with the small-sample correction
        chi2 = sum(w * r * r for w, r in zip(ws, resid))
        dof = len(pts) - 2
        scale = max(1.0, chi2 / dof) if dof > 0 else 1.0
        se = math.sqrt(scale / sxx)
        has_dof = True
    else:
        # two points: propagate the two endpoint SEs
        (x1, _, s1), (x2, _, s2) = pts
        se = math.sqrt(s1 ** 2 + s2 ** 2) / abs(math.log(x2) - math.log(x1))
        has_dof = False
    return {"slope": slope, "se": se, "k": len(pts),
            "df_resid": len(pts) - 2 if has_dof else 0,
            "age_range": [min(p[0] for p in pts), max(p[0] for p in pts)],
            "per_doubling": 2 ** slope - 1}


def dersimonian_laird(effects):
    """effects: list of (label, slope, se). Returns the pooled summary."""
    e = [(l, y, s) for l, y, s in effects if s and s > 0]
    k = len(e)
    if k == 0:
        return None
    w = [1.0 / s ** 2 for _, _, s in e]
    sw = sum(w)
    yfix = sum(wi * y for wi, (_, y, _) in zip(w, e)) / sw
    Q = sum(wi * (y - yfix) ** 2 for wi, (_, y, _) in zip(w, e))
    df = k - 1
    C = sw - sum(wi * wi for wi in w) / sw
    tau2 = max(0.0, (Q - df) / C) if C > 0 else 0.0
    ws = [1.0 / (s ** 2 + tau2) for _, _, s in e]
    sws = sum(ws)
    pooled = sum(wi * y for wi, (_, y, _) in zip(ws, e)) / sws
    se = math.sqrt(1.0 / sws)
    I2 = max(0.0, (Q - df) / Q) if Q > 0 else 0.0
    # chi-square -> z via Wilson-Hilferty, then two-sided p from the normal
    if df > 0 and Q > 0:
        z = ((Q / df) ** (1.0 / 3.0) - (1 - 2.0 / (9 * df))) / math.sqrt(2.0 / (9 * df))
        p_q = math.erfc(abs(z) / math.sqrt(2))
    else:
        z, p_q = 0.0, 1.0
    # normal p for the pooled slope
    zpool = pooled / se if se > 0 else 0.0
    return {"k": k, "pooled_slope": pooled, "se": se,
            "ci95": [pooled - 1.96 * se, pooled + 1.96 * se],
            "per_doubling": 2 ** pooled - 1,
            "per_doubling_ci95": [2 ** (pooled - 1.96 * se) - 1,
                                  2 ** (pooled + 1.96 * se) - 1],
            "p": math.erfc(abs(zpool) / math.sqrt(2)),
            "Q": Q, "Q_df": df, "Q_p": p_q, "I2": I2, "tau2": tau2,
            "weights_pct": [100 * wi / sws for wi in ws],
            "pooled_fixed": yfix}


# ------------------------------------------------------------------ main


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--studies", nargs="+", required=True)
    ap.add_argument("--boot", type=int, default=2000)
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "results", "real"))
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    rng = random.Random(11)
    record, rows, slopes = {}, [], []

    for study in args.studies:
        print(f"== {study}", flush=True)
        ids, rel, days, subj = load_cohort(study)
        keys, within, between, n_drawn = pool_pairs(rel, days, subj)
        print(f"   {len(ids)} samples, {len(keys)} subjects, "
              f"{n_drawn} between draws", flush=True)

        cohort = {"n_samples": len(ids), "n_subjects": len(keys), "buckets": {}}
        pts = []
        for bk in BUCKETS:
            pe = point_estimate(bk, keys, within, between)
            if not pe or pe["n_within"] < MIN_WITHIN or pe["n_between"] < MIN_BETWEEN:
                continue
            if not pe["ratio"] or pe["ratio"] <= 0:
                continue
            boot = bootstrap_ratio(bk, keys, within, between, args.boot, rng)
            lr = [math.log(x) for x in boot if x > 0]
            if len(lr) < 100:
                continue
            lmean = sum(lr) / len(lr)
            lse = statistics.pstdev(lr) if len(lr) > 1 else None
            # bucket age = mean age of the later sample of each within pair
            age_mid = max(pe["age_mid"] or (bk[0] + min(bk[1], 3650)) / 2, 1.0)
            ent = {"label": blabel(bk), "age_mid": age_mid,
                   "within": pe["within"], "between": pe["between"],
                   "ratio": pe["ratio"], "log_ratio": math.log(pe["ratio"]),
                   "log_ratio_se": lse,
                   "ratio_ci95": [math.exp(quantile(lr, 0.025)),
                                  math.exp(quantile(lr, 0.975))],
                   "n_within": pe["n_within"], "n_between": pe["n_between"],
                   "n_boot": len(lr)}
            cohort["buckets"][ent["label"]] = ent
            pts.append((age_mid, math.log(pe["ratio"]), lse))
            rows.append([study, ent["label"], round(age_mid, 1),
                         round(pe["within"], 4), round(pe["between"], 4),
                         round(pe["ratio"], 4),
                         round(ent["ratio_ci95"][0], 4), round(ent["ratio_ci95"][1], 4),
                         f"{math.log(pe['ratio']):.4f}", f"{lse:.4f}" if lse else "",
                         pe["n_within"], pe["n_between"]])
            print(f"   {ent['label']:>14s} age={age_mid:6.0f}d "
                  f"ratio={pe['ratio']:.3f} "
                  f"[{ent['ratio_ci95'][0]:.3f},{ent['ratio_ci95'][1]:.3f}] "
                  f"se(log)={lse:.3f}", flush=True)

        sl = wls_slope(pts)
        if sl:
            cohort["slope"] = sl
            slopes.append([study, sl["k"], sl["slope"], sl["se"],
                           sl["slope"] - 1.96 * sl["se"], sl["slope"] + 1.96 * sl["se"],
                           sl["per_doubling"], sl["age_range"][0], sl["age_range"][1]])
            print(f"   slope={sl['slope']:.4f} +/- {sl['se']:.4f} "
                  f"-> {100 * sl['per_doubling']:+.1f}% per doubling", flush=True)
        record[study] = cohort

    pooled = dersimonian_laird([(r[0], r[2], r[3]) for r in slopes])
    if pooled:
        pooled["labels"] = [r[0] for r in slopes]
    record["_pooled"] = pooled
    if pooled:
        print("\n== random-effects pooled slope "
              f"{pooled['pooled_slope']:.4f} (95% CI {pooled['ci95'][0]:.4f},"
              f" {pooled['ci95'][1]:.4f}), p={pooled['p']:.3g}")
        print(f"   per doubling: {100 * pooled['per_doubling']:+.1f}% "
              f"[{100 * pooled['per_doubling_ci95'][0]:+.1f},"
              f" {100 * pooled['per_doubling_ci95'][1]:+.1f}]")
        print(f"   Q={pooled['Q']:.2f} df={pooled['Q_df']} p={pooled['Q_p']:.3g} "
              f"I2={100 * pooled['I2']:.1f}% tau2={pooled['tau2']:.5f}")

    with open(os.path.join(args.out_dir, "meta_decay.json"), "w") as f:
        json.dump(record, f, indent=2, ensure_ascii=False)

    with open(os.path.join(args.out_dir, "meta_buckets.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["study", "bucket", "age_mid_days", "bray_within", "bray_between",
                    "ratio", "ratio_lo", "ratio_hi", "log_ratio", "log_ratio_se",
                    "n_within_pairs", "n_between_pairs"])
        w.writerows(rows)

    with open(os.path.join(args.out_dir, "meta_slopes.csv"), "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["study", "k_buckets", "slope", "se", "lo95", "hi95",
                    "per_doubling", "age_min", "age_max"])
        w.writerows(slopes)
        if pooled:
            w.writerow(["POOLED_RE", pooled["k"], round(pooled["pooled_slope"], 4),
                        round(pooled["se"], 4), round(pooled["ci95"][0], 4),
                        round(pooled["ci95"][1], 4), round(pooled["per_doubling"], 4),
                        "", ""])
    print(f"\nwrote {args.out_dir}/meta_decay.json, meta_buckets.csv, meta_slopes.csv")


if __name__ == "__main__":
    main()
