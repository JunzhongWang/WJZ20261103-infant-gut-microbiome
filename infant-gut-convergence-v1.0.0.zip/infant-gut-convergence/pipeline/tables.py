#!/usr/bin/env python3
"""Manuscript tables from the built cohort tables.

    python3 pipeline/tables.py

table1.csv        cohort characteristics
table_taxon.csv   species x cohort ICC matrix (taxa called in >= 3 cohorts)
"""
import csv
import os
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STUDIES = ["ShaoY_2019", "VatanenT_2016", "BackhedF_2015", "YassourM_2018",
           "KosticAD_2015", "FerrettiP_2018", "BrooksB_2017"]
DENSE = {"BrooksB_2017", "FerrettiP_2018", "KosticAD_2015"}
LABEL = {
    "ShaoY_2019": ("Shao 2019", "China", "term infants, C-section vs vaginal"),
    "VatanenT_2016": ("Vatanen 2016 (DIABIMMUNE)", "Finland / Estonia / Russia",
                      "general population, T1D HLA risk"),
    "BackhedF_2015": ("Bäckhed 2015", "Sweden", "general population"),
    "YassourM_2018": ("Yassour 2018", "USA", "general population"),
    "KosticAD_2015": ("Kostic 2015 (TEDDY)", "Finland / Estonia", "T1D risk cohort"),
    "FerrettiP_2018": ("Ferretti 2018", "Italy", "mother-infant pairs, multiple sites"),
    "BrooksB_2017": ("Brooks 2017", "USA", "preterm infants, NICU"),
}


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


rows = []
for st in STUDIES:
    d = os.path.join(ROOT, "data", st)
    meta = list(csv.DictReader(open(os.path.join(d, "meta.csv"))))
    comm = next(csv.reader(open(os.path.join(d, "community.csv"))))
    ages = [float(m["days"]) for m in meta]
    by = {}
    for m in meta:
        by.setdefault(m["subject_id"], []).append(float(m["days"]))
    visits = [len(v) for v in by.values()]
    spans = [max(v) - min(v) for v in by.values() if len(v) > 1]
    gaps = []
    for v in by.values():
        v.sort()
        gaps += [b - a for a, b in zip(v, v[1:]) if b - a > 0]
    country = meta[0]["country"] if meta else ""
    rows.append({
        "study": st, "label": LABEL[st][0], "country": country or LABEL[st][1],
        "design": "dense" if st in DENSE else "sparse",
        "n_samples": len(meta), "n_subjects": len(by),
        "visits_median": statistics.median(visits),
        "visits_max": max(visits),
        "followup_median_d": statistics.median(spans) if spans else 0,
        "gap_median_d": statistics.median(gaps) if gaps else 0,
        "age_min_d": min(ages), "age_max_d": max(ages),
        "n_taxa": len(comm) - 1,
        "note": LABEL[st][2],
    })

with open(os.path.join(ROOT, "results", "real", "table1.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator="\n")
    w.writeheader()
    for r in rows:
        w.writerow({k: (f"{v:.0f}" if isinstance(v, float) else v) for k, v in r.items()})

tot_s = sum(r["n_samples"] for r in rows)
tot_p = sum(r["n_subjects"] for r in rows)
tot_t = sum(r["n_taxa"] for r in rows)
print(f"{'study':<28}{'samples':>8}{'subj':>6}{'medVis':>7}{'gap':>6}"
      f"{'age range':>14}{'taxa':>6}")
for r in rows:
    print(f"{r['label']:<28}{r['n_samples']:>8}{r['n_subjects']:>6}"
          f"{r['visits_median']:>7.0f}{r['gap_median_d']:>6.0f}"
          f"{r['age_min_d']:>7.0f}-{r['age_max_d']:<6.0f}{r['n_taxa']:>6}")
print(f"{'total':<28}{tot_s:>8}{tot_p:>6}")

# ---- species x cohort ICC
icc = {}
for st in STUDIES:
    p = os.path.join(ROOT, "data", st, "taxon_icc.tsv")
    if not os.path.exists(p):
        continue
    for r in csv.DictReader(open(p), delimiter="\t"):
        icc[(r["taxon"], st)] = (float(r["icc"]), float(r["prevalence"]))

taxa = sorted({t for (t, s) in icc if sum(1 for (tt, ss) in icc if tt == t) >= 3})
with open(os.path.join(ROOT, "results", "real", "table_taxon.csv"), "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["taxon"] + STUDIES + ["n_cohorts", "icc_median"])
    for t in taxa:
        vals = [icc.get((t, s), (None, None))[0] for s in STUDIES]
        ok = [v for v in vals if v is not None]
        w.writerow([t] + [("" if v is None else round(v, 3)) for v in vals]
                   + [len(ok), round(statistics.median(ok), 3)])
print(f"\nwrote table1.csv and table_taxon.csv ({len(taxa)} taxa in >=3 cohorts)")
