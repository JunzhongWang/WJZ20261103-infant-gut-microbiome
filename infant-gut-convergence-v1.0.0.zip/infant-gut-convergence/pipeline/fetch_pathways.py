#!/usr/bin/env python3
"""Fetch cMD3 pathway_abundance resources and extract per-cohort pathway tables.

Reuses the resumable downloader of fetch_cmd3_direct.py. For each study:
  1. find newest <study>.pathway_abundance resource in the local hub catalogue
  2. download its .rda into data/cache/
  3. Rscript rda_extract_pathway.R -> data/<study>/pathway.tsv
"""
import os
import sys
import sqlite3
import subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fetch_cmd3_direct import fetch_resumable, CACHE, ROOT  # noqa: E402

STUDIES = ["ShaoY_2019", "VatanenT_2016", "BackhedF_2015", "YassourM_2018",
           "KosticAD_2015", "FerrettiP_2018", "BrooksB_2017"]
PATTERN = "pathway_abundance"


def newest_pathway(con, study):
    q = """SELECT r.title, p.rdatapath, lp.location_prefix
      FROM resources r
      JOIN rdatapaths p          ON p.resource_id = r.id
      JOIN location_prefixes lp  ON lp.id = r.location_prefix_id
     WHERE r.title = ?"""
    rows = con.execute(q, (f"2021-03-31.{study}.{PATTERN}",)).fetchall()
    if not rows:
        rows = con.execute(q, (f"%{study}.{PATTERN}",)).fetchall()
    return rows[0] if rows else None


def main():
    con = sqlite3.connect(os.path.join(CACHE, "experimenthub.sqlite3"))
    for study in STUDIES:
        hit = newest_pathway(con, study)
        if hit is None:
            print(f"{study}: NO pathway resource", flush=True)
            continue
        title, rdatapath, prefix = hit
        url = prefix.rstrip("/") + "/" + rdatapath.lstrip("/")
        rda = os.path.join(CACHE, f"{study}.{PATTERN}.rda")
        print(f"{study}: {title}", flush=True)
        try:
            _, size = fetch_resumable(url, rda)
        except RuntimeError as exc:
            print(f"  download failed: {exc}", flush=True)
            continue
        print(f"  downloaded {size/1e6:.1f} MB", flush=True)
        outdir = os.path.join(ROOT, "data", study)
        r = subprocess.run(["Rscript",
                            os.path.join(ROOT, "pipeline", "rda_extract_pathway.R"),
                            rda, outdir, study], capture_output=True, text=True)
        sys.stdout.write("  " + (r.stdout.strip() or r.stderr.strip()[:400]) + "\n")


if __name__ == "__main__":
    main()
