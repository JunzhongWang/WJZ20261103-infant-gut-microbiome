#!/usr/bin/env python3
"""
Infant gut microbiome developmental trajectory — analysis pipeline.
Zero third-party dependencies (Python 3.12+ standard library only).

Subcommands
-----------
  simulate   generate a synthetic cohort driven by a real cMD3 visit schedule
  analyze    run the full analysis on a (simulated or real) abundance table
  validate   repeated simulation -> parameter recovery (bias / coverage)

Real-data usage: put a species-level relative abundance table (samples x species,
TSV, first column = sample_id) plus a metadata TSV next to it, then run `analyze`.
"""

import argparse
import csv
import json
import math
import os
import random
import statistics
import sys

# ---------------------------------------------------------------- utilities


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_csv(path, rows, fields):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def to_float(v, default=None):
    try:
        f = float(v)
        if math.isnan(f) or math.isinf(f):
            return default
        return f
    except (TypeError, ValueError):
        return default


def is_yes(v):
    return str(v).strip().lower() in ("yes", "true", "1", "y")


# ---------------------------------------------------------------- linear algebra


def solve(a, b):
    """Gaussian elimination with partial pivoting. a: n x n (list of lists), b: n."""
    n = len(a)
    m = [row[:] + [b[i]] for i, row in enumerate(a)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[piv][col]) < 1e-12:
            return [0.0] * n
        m[col], m[piv] = m[piv], m[col]
        pv = m[col][col]
        for r in range(col + 1, n):
            factor = m[r][col] / pv
            if factor:
                for c in range(col, n + 1):
                    m[r][c] -= factor * m[col][c]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        s = m[r][n] - sum(m[r][c] * x[c] for c in range(r + 1, n))
        x[r] = s / m[r][r]
    return x


def ols(x_rows, y):
    """Least squares via normal equations with tiny ridge (stabilises collinearity)."""
    p = len(x_rows[0])
    xtx = [[0.0] * p for _ in range(p)]
    xty = [0.0] * p
    for row, yi in zip(x_rows, y):
        for i in range(p):
            xty[i] += row[i] * yi
            for j in range(p):
                xtx[i][j] += row[i] * row[j]
    for i in range(p):
        xtx[i][i] += 1e-8 * (xtx[i][i] + 1e-8)
    return solve(xtx, xty)


def rcs_basis(t, knots):
    """Restricted (natural) cubic spline basis, Harrell's parameterisation."""
    k = len(knots)
    scale = (knots[-1] - knots[0]) ** 2
    out = [t]
    for j in range(k - 2):
        def cube(u):
            return u ** 3 if u > 0 else 0.0
        term = (
            cube(t - knots[j])
            - cube(t - knots[k - 2]) * (knots[k - 1] - knots[j]) / (knots[k - 1] - knots[k - 2])
            + cube(t - knots[k - 1]) * (knots[k - 2] - knots[j]) / (knots[k - 1] - knots[k - 2])
        )
        out.append(term / scale)
    return out


# ---------------------------------------------------------------- ecology


def shannon(counts):
    total = sum(counts)
    if total <= 0:
        return 0.0
    h = 0.0
    for c in counts:
        if c > 0:
            p = c / total
            h -= p * math.log(p)
    return h


def observed(counts):
    return sum(1 for c in counts if c > 0)


def bray_curtis(a, b):
    num = sum(abs(x - y) for x, y in zip(a, b))
    den = sum(x + y for x, y in zip(a, b))
    return num / den if den else 0.0


def relative(counts):
    total = sum(counts)
    return [c / total for c in counts] if total else [0.0] * len(counts)


def icc_oneway(groups):
    """One-way random effects ICC(1) from moment estimators."""
    groups = [g for g in groups if len(g) >= 1]
    k = len(groups)
    if k < 2:
        return None
    n_i = [len(g) for g in groups]
    n_tot = sum(n_i)
    if n_tot <= k:
        return None
    grand = sum(sum(g) for g in groups) / n_tot
    msb = sum(len(g) * (statistics.fmean(g) - grand) ** 2 for g in groups) / (k - 1)
    df_w = n_tot - k
    if df_w <= 0:
        return None
    msw = sum(sum((x - statistics.fmean(g)) ** 2 for x in g) for g in groups) / df_w
    n0 = (n_tot - sum(n * n for n in n_i) / n_tot) / (k - 1)
    if n0 <= 0 or (msb + (n0 - 1) * msw) <= 0:
        return None
    # keep the signed moment estimate: a negative value means within-subject
    # variance exceeds between-subject variance (ICC is not identifiable as a
    # proportion, so clipping to 0 would hide a real result)
    var_b = (msb - msw) / n0
    denom = var_b + msw
    return var_b / denom if denom > 0 else None


# ---------------------------------------------------------------- simulation

# Species archetypes: (name, logit midpoint in days, steepness, peak abundance, direction)
# direction +1 = coloniser rising with age, -1 = early-dominant declining with age
ARCHETYPES = [
    ("Bifidobacterium_longum", 120, 0.010, 0.28, -1),
    ("Bifidobacterium_breve", 90, 0.012, 0.12, -1),
    ("Bifidobacterium_infantis", 150, 0.008, 0.10, -1),
    ("Escherichia_coli", 200, 0.006, 0.06, -1),
    ("Klebsiella_pneumoniae", 240, 0.005, 0.03, -1),
    ("Enterococcus_faecalis", 180, 0.007, 0.04, -1),
    ("Streptococcus_salivarius", 160, 0.006, 0.03, -1),
    ("Staphylococcus_epidermidis", 60, 0.015, 0.02, -1),
    ("Lactobacillus_ruminis", 300, 0.005, 0.02, -1),
    ("Bacteroides_vulgatus", 400, 0.006, 0.08, 1),
    ("Bacteroides_fragilis", 450, 0.006, 0.06, 1),
    ("Faecalibacterium_prausnitzii", 600, 0.005, 0.07, 1),
    ("Roseburia_intestinalis", 620, 0.005, 0.04, 1),
    ("Eubacterium_rectale", 650, 0.005, 0.04, 1),
    ("Akkermansia_muciniphila", 700, 0.004, 0.03, 1),
    ("Clostridium_butyricum", 380, 0.006, 0.02, 1),
    ("Prevotella_copri", 520, 0.005, 0.03, 1),
    ("Ruminococcus_bromii", 560, 0.005, 0.03, 1),
    ("Blautia_massiliensis", 500, 0.005, 0.02, 1),
    ("Dorea_longicatena", 540, 0.005, 0.02, 1),
]


def logistic(x):
    return 1.0 / (1.0 + math.exp(-x))


def simulate_cohort(meta_rows, seed=1, abx_beta=-0.35, sigma_subj=0.55,
                    sigma_visit=0.15, reads=20000, abx_prob=0.06,
                    sd_tempo=0.30, sigma_axis=0.65):
    """Generate a compositional table driven by the real visit schedule in meta_rows.

    Biological structure:
      * age-dependent maturation of each species (logistic onset/decline)
      * subject-specific maturation tempo (some infants mature faster) -> between-
        subject differences that persist over time (this is what makes ICC > 0)
      * subject-specific early/late balance axis (a single latent gradient)
      * per-species idiosyncratic subject effects (compositional noise)
      * antibiotic pulses that suppress early-coloniser species
    """
    rng = random.Random(seed)
    subjects = {}
    for r in meta_rows:
        subjects.setdefault(r["subject_id"], []).append(r)

    subj_effect = {s: [rng.gauss(0, sigma_subj) for _ in ARCHETYPES] for s in subjects}
    tempo = {s: rng.gauss(0, sd_tempo) for s in subjects}
    axis = {s: rng.gauss(0, sigma_axis) for s in subjects}
    abx_pulse = {}
    for s in subjects:
        if rng.random() < abx_prob:
            start = rng.uniform(60, 900)
            abx_pulse[s] = (start, start + rng.uniform(7, 21))

    sample_ids, counts_by_sample, meta_out, latent_delta = [], [], [], []
    for sid, rows in subjects.items():
        rows = sorted(rows, key=lambda r: to_float(r["days_from_first_collection"], 0.0))
        for r in rows:
            t = to_float(r["days_from_first_collection"], 0.0)
            t_eff = t * math.exp(tempo[sid])
            effect = subj_effect[sid]
            props = []
            for idx, (name, mid, steep, peak, direction) in enumerate(ARCHETYPES):
                z = steep * (t_eff - mid)
                f = logistic(z) if direction > 0 else logistic(-z)
                logp = (math.log(max(peak, 1e-9)) + math.log(max(f, 1e-9))
                        + effect[idx] + axis[sid] * direction)
                props.append(logp)
            on_abx = is_yes(r.get("antibiotics_current_use"))
            if sid in abx_pulse and not on_abx:
                lo, hi = abx_pulse[sid]
                if lo <= t <= hi:
                    on_abx = True
            props_off = list(props)
            if on_abx:
                for idx, (name, mid, steep, peak, direction) in enumerate(ARCHETYPES):
                    if direction < 0:
                        props[idx] += abx_beta
            noise = [rng.gauss(0, sigma_visit) for _ in ARCHETYPES]
            props = [p + n for p, n in zip(props, noise)]
            props_off = [p + n for p, n in zip(props_off, noise)]

            def _weights(lp):
                mx = max(lp)
                return [math.exp(x - mx) for x in lp]

            # exact latent effect of the exposure (same noise, only beta differs)
            latent_delta.append(
                shannon(_weights(props)) - shannon(_weights(props_off)) if on_abx else 0.0
            )
            w = _weights(props)
            s = sum(w)
            p = [x / s for x in w]
            # Dirichlet-multinomial via gamma then conditional binomials
            conc = 60.0
            g = [rng.gammavariate(max(pi * conc, 1e-6), 1.0) for pi in p]
            gs = sum(g)
            q = [x / gs for x in g]
            remaining = reads
            counts = []
            cum = 1.0
            for i, qi in enumerate(q):
                if i == len(q) - 1:
                    counts.append(remaining)
                else:
                    if cum <= 0 or remaining <= 0:
                        counts.append(0)
                    else:
                        k = rng.binomialvariate(remaining, min(max(qi / cum, 0.0), 1.0))
                        counts.append(k)
                        remaining -= k
                    cum -= qi
            sample_ids.append(r["sample_id"])
            counts_by_sample.append(counts)
            meta_out.append({
                "sample_id": r["sample_id"],
                "subject_id": sid,
                "study": r.get("study_name", ""),
                "days": t,
                "abx": int(on_abx),
            })
    names = [a[0] for a in ARCHETYPES]
    return sample_ids, names, counts_by_sample, meta_out, latent_delta


def population_truth(meta_rows=None, n_subj=700, seed=99, abx_beta=-0.35,
                     sigma_subj=0.55, sigma_visit=0.15):
    """Population reference values for the two headline estimands.

    icc_raw        correlation of Shannon within subject (fixed visit ages)
    icc_ageadj     same, after removing the fitted developmental trajectory
    abx_effect     mean change in Shannon attributable to antibiotic exposure,
                   computed as a paired difference at the cohort's own schedule
    """
    rows = []
    for i in range(n_subj):
        for visit, t in enumerate([30, 90, 180, 365, 730]):
            rows.append({"sample_id": f"T{i}_{visit}", "subject_id": f"T{i}",
                         "days_from_first_collection": str(t),
                         "antibiotics_current_use": "no", "study_name": "truth"})
    ids, names, counts, meta, _ = simulate_cohort(
        rows, seed=seed, abx_beta=abx_beta, sigma_subj=sigma_subj,
        sigma_visit=sigma_visit, reads=20000, abx_prob=0.0)
    days = [to_float(m["days"], 0.0) for m in meta]
    subj = [m["subject_id"] for m in meta]
    y = [shannon(c) for c in counts]

    groups = {}
    for s, h in zip(subj, y):
        groups.setdefault(s, []).append(h)
    icc_raw = icc_oneway(list(groups.values()))

    knots = [30.0, 180.0, 540.0]
    icc_adj = None
    curve = fit_population_curve(days, y, knots)
    if curve.get("ok"):
        resid = [yi - fi for yi, fi in zip(y, curve["fitted"])]
        rg = {}
        for s, r in zip(subj, resid):
            rg.setdefault(s, []).append(r)
        icc_adj = icc_oneway(list(rg.values()))

    abx_effect = None
    if meta_rows:
        _, _, _, m_abx, lat = simulate_cohort(
            meta_rows, seed=seed, abx_beta=abx_beta, sigma_subj=sigma_subj,
            sigma_visit=sigma_visit, reads=20000, abx_prob=0.06)
        exposed = [d for d, m in zip(lat, m_abx) if m["abx"] == 1]
        if exposed:
            abx_effect = statistics.fmean(exposed)
    return {"icc_shannon": icc_raw, "icc_ageadj": icc_adj,
            "abx_delta_shannon": abx_effect}


# ---------------------------------------------------------------- analysis


def load_table(species_path):
    rows = read_csv(species_path)
    names = [c for c in rows[0].keys() if c != "sample_id"]
    ids, counts = [], []
    for r in rows:
        ids.append(r["sample_id"])
        counts.append([to_float(r[n], 0.0) for n in names])
    return ids, names, counts


def analyze(meta_path, species_path, out_json=None, label=""):
    ids, names, counts = load_table(species_path)
    meta = {r["sample_id"]: r for r in read_csv(meta_path)}
    keep = [i for i, s in enumerate(ids) if s in meta]
    ids = [ids[i] for i in keep]
    counts = [counts[i] for i in keep]

    shan = [shannon(c) for c in counts]
    obs = [observed(c) for c in counts]
    days = [to_float(meta[s].get("days"), 0.0) for s in ids]
    subj = [meta[s]["subject_id"] for s in ids]
    abx = [int(meta[s].get("abx", 0) or 0) for s in ids]

    groups = {}
    for s, h in zip(subj, shan):
        groups.setdefault(s, []).append(h)
    icc = icc_oneway(list(groups.values()))

    # --- maturation trajectory: restricted cubic spline, subject fixed effects
    knots = [0.0, 180.0, 540.0]
    res_traj = fit_trajectory(days, shan, subj, knots)
    res_abx = fit_abx_effect(days, shan, subj, abx, knots)

    # individual consistency after removing the developmental trajectory.
    # NB: de-trending uses the population-average curve, not the within-subject
    # fit — the latter absorbs subject means and inflates the residual
    # between-subject variance, which biases ICC upward.
    icc_adj = None
    curve = fit_population_curve(days, shan, knots)
    if curve.get("ok"):
        resid = [y - f for y, f in zip(shan, curve["fitted"])]
        rg = {}
        for s, r in zip(subj, resid):
            rg.setdefault(s, []).append(r)
        icc_adj = icc_oneway(list(rg.values()))

    # --- beta diversity, matched on elapsed time (avoids the "everyone starts
    #     at birth" artefact that makes naive between-subject distances too small)
    rel = [relative(c) for c in counts]
    buckets = [(0, 7), (7, 30), (30, 90), (90, 365), (365, 1e9)]
    within = {b: [] for b in buckets}
    between = {b: [] for b in buckets}
    by_subj = {}
    for i, s in enumerate(subj):
        by_subj.setdefault(s, []).append(i)

    def bucket_of(dt):
        for b in buckets:
            if b[0] <= dt < b[1]:
                return b
        return None

    for s, idx in by_subj.items():
        for a in range(len(idx)):
            for b2 in range(a + 1, len(idx)):
                dt = abs(days[idx[a]] - days[idx[b2]])
                bk = bucket_of(dt)
                if bk:
                    within[bk].append(bray_curtis(rel[idx[a]], rel[idx[b2]]))

    rng = random.Random(7)
    subj_ids = list(by_subj)
    n_pairs = 0
    for _ in range(40000):
        s1, s2 = rng.sample(subj_ids, 2)
        i = rng.choice(by_subj[s1])
        j = rng.choice(by_subj[s2])
        dt = abs(days[i] - days[j])
        bk = bucket_of(dt)
        if bk:
            between[bk].append(bray_curtis(rel[i], rel[j]))
            n_pairs += 1
    matched = {}
    for b in buckets:
        if len(within[b]) >= 5 and len(between[b]) >= 5:
            w = statistics.fmean(within[b])
            bw = statistics.fmean(between[b])
            matched[f"{b[0]}-{b[1]}d"] = {
                "within": w, "between": bw, "ratio": bw / w if w > 0 else None,
                "n_within": len(within[b]), "n_between": len(between[b])}
    all_within = [d for v in within.values() for d in v]
    all_between = [d for v in between.values() for d in v]

    out = {
        "label": label,
        "n_samples": len(ids),
        "n_subjects": len(subj_ids),
        "shannon_mean": statistics.fmean(shan),
        "shannon_sd": statistics.pstdev(shan) if len(shan) > 1 else None,
        "observed_mean": statistics.fmean(obs),
        "icc_shannon": icc,
        "icc_shannon_ageadj": icc_adj,
        "bray_within_mean": statistics.fmean(all_within) if all_within else None,
        "bray_between_mean": statistics.fmean(all_between) if all_between else None,
        "bray_ratio_matched": ({k: v["ratio"] for k, v in matched.items()} or None),
        "bray_matched": matched,
        "trajectory": res_traj,
        "abx": res_abx,
    }
    if out_json:
        with open(out_json, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=2, ensure_ascii=False)
    return out


def fit_population_curve(days, y, knots):
    """Population-average restricted cubic spline (ignores subject structure)."""
    x_rows = [[1.0] + rcs_basis(d, knots) for d in days]
    beta = ols(x_rows, y)
    fitted = [sum(b * v for b, v in zip(beta, row)) for row in x_rows]
    return {"ok": True, "coef": beta, "fitted": fitted}


def fit_trajectory(days, y, subj, knots):
    """Within-subject (fixed effects) restricted cubic spline fit.

    Returns the fitted curve at a grid of ages plus the slope between day 90 and 365.
    """
    idx_by_subj = {}
    for i, s in enumerate(subj):
        idx_by_subj.setdefault(s, []).append(i)

    x_rows, yc = [], []
    for s, idx in idx_by_subj.items():
        if len(idx) < 2:
            continue
        my = statistics.fmean([y[i] for i in idx])
        for i in idx:
            b = rcs_basis(days[i], knots)
            mb = [statistics.fmean([rcs_basis(days[j], knots)[p] for j in idx])
                  for p in range(len(b))]
            x_rows.append([b[p] - mb[p] for p in range(len(b))])
            yc.append(y[i] - my)
    if len(x_rows) < len(knots):
        return {"ok": False}
    beta = ols(x_rows, yc)

    grid = [30, 60, 90, 120, 180, 270, 365, 540, 730, 900, 1095]
    # intercept from the centred model is not identified; anchor on overall mean curve
    base = statistics.fmean(y)
    xbar = [statistics.fmean([rcs_basis(d, knots)[p] for d in days])
            for p in range(len(beta))]
    intercept = base - sum(b * xv for b, xv in zip(beta, xbar))
    curve = []
    for g in grid:
        b = rcs_basis(g, knots)
        curve.append({"day": g, "shannon": intercept + sum(bb * vv for bb, vv in zip(beta, b))})
    fitted = [intercept + sum(bb * vv for bb, vv in zip(beta, rcs_basis(d, knots)))
              for d in days]
    y90 = next(c["shannon"] for c in curve if c["day"] == 90)
    y365 = next(c["shannon"] for c in curve if c["day"] == 365)
    return {"ok": True, "coef": beta, "curve": curve, "fitted": fitted,
            "slope_90_365": y365 - y90, "intercept": intercept}


def fit_abx_effect(days, y, subj, abx, knots):
    """Within-subject estimate of the antibiotic effect on Shannon, age-adjusted."""
    idx_by_subj = {}
    for i, s in enumerate(subj):
        idx_by_subj.setdefault(s, []).append(i)
    x_rows, yc = [], []
    for s, idx in idx_by_subj.items():
        if len(idx) < 2 or len({abx[i] for i in idx}) < 2:
            continue
        my = statistics.fmean([y[i] for i in idx])
        ma = statistics.fmean([abx[i] for i in idx])
        mb = [statistics.fmean([rcs_basis(days[j], knots)[p] for j in idx])
              for p in range(len(rcs_basis(0, knots)))]
        for i in idx:
            b = rcs_basis(days[i], knots)
            row = [abx[i] - ma] + [b[p] - mb[p] for p in range(len(b))]
            x_rows.append(row)
            yc.append(y[i] - my)
    if len(x_rows) < 4:
        return {"ok": False, "n_pairs": 0}
    beta = ols(x_rows, yc)
    return {"ok": True, "beta_abx": beta[0], "n_rows": len(x_rows),
            "n_switch_subjects": sum(1 for idx in idx_by_subj.values()
                                     if len(idx) > 1 and len({abx[i] for i in idx}) > 1)}


# ---------------------------------------------------------------- CLI


def cmd_simulate(args):
    meta = [r for r in read_csv(args.meta) if r.get("study_name") == args.study]
    if args.max_subjects:
        keep = sorted({r["subject_id"] for r in meta})[: args.max_subjects]
        meta = [r for r in meta if r["subject_id"] in keep]
    ids, names, counts, meta_out, _ = simulate_cohort(
        meta, seed=args.seed, abx_beta=args.abx_beta,
        sigma_subj=args.sigma_subj, reads=args.reads)
    rows = []
    for sid, c in zip(ids, counts):
        d = {"sample_id": sid}
        d.update({n: v for n, v in zip(names, c)})
        rows.append(d)
    outdir = args.out
    write_csv(os.path.join(outdir, "species.csv"), rows, ["sample_id"] + names)
    write_csv(os.path.join(outdir, "meta.csv"), meta_out,
              ["sample_id", "subject_id", "study", "days", "abx"])
    truth = population_truth(meta_rows=meta, seed=args.seed + 1000,
                             abx_beta=args.abx_beta, sigma_subj=args.sigma_subj)
    truth.update({"abx_beta_param": args.abx_beta, "sigma_subj": args.sigma_subj})
    with open(os.path.join(outdir, "truth.json"), "w", encoding="utf-8") as fh:
        json.dump(truth, fh, indent=2)
    print(f"simulated {len(ids)} samples / {len(set(m['subject_id'] for m in meta_out))} subjects -> {outdir}")
    return 0


def cmd_analyze(args):
    res = analyze(os.path.join(args.dir, "meta.csv"),
                  os.path.join(args.dir, "species.csv"),
                  out_json=os.path.join(args.dir, "estimate.json"),
                  label=args.dir)
    print(json.dumps({k: v for k, v in res.items() if k not in ("trajectory",)},
                     indent=2, ensure_ascii=False))
    if res.get("trajectory", {}).get("ok"):
        print("trajectory slope (90->365 d):",
              round(res["trajectory"]["slope_90_365"], 4))
    return 0


def cmd_validate(args):
    meta_all = read_csv(args.meta)
    meta = [r for r in meta_all if r.get("study_name") == args.study]
    if args.max_subjects:
        keep = sorted({r["subject_id"] for r in meta})[: args.max_subjects]
        meta = [r for r in meta if r["subject_id"] in keep]
    print("computing population truth ...", flush=True)
    truth = population_truth(meta_rows=meta, abx_beta=args.abx_beta,
                             sigma_subj=args.sigma_subj)
    print("  truth:", truth, flush=True)
    results = []
    for seed in range(1, args.n + 1):
        ids, names, counts, meta_out, _ = simulate_cohort(
            meta, seed=seed, abx_beta=args.abx_beta, sigma_subj=args.sigma_subj,
            reads=args.reads)
        rows = []
        for sid, c in zip(ids, counts):
            d = {"sample_id": sid}
            d.update({n: v for n, v in zip(names, c)})
            rows.append(d)
        tmp = os.path.join(args.out, f"sim_{seed}")
        write_csv(os.path.join(tmp, "species.csv"), rows, ["sample_id"] + names)
        write_csv(os.path.join(tmp, "meta.csv"), meta_out,
                  ["sample_id", "subject_id", "study", "days", "abx"])
        est = analyze(os.path.join(tmp, "meta.csv"),
                      os.path.join(tmp, "species.csv"))
        bm = est.get("bray_matched") or {}
        ratios = [v["ratio"] for v in bm.values() if v.get("ratio")]
        results.append({
            "seed": seed,
            "icc_est": est["icc_shannon"],
            "icc_true": truth["icc_shannon"],
            "icc_adj_est": est.get("icc_shannon_ageadj"),
            "icc_adj_true": truth.get("icc_ageadj"),
            "abx_est": est["abx"].get("beta_abx"),
            "abx_true": truth["abx_delta_shannon"],
            "slope_est": est["trajectory"].get("slope_90_365"),
            "bray_ratio": statistics.fmean(ratios) if ratios else None,
            "n_abx_switch": est["abx"].get("n_switch_subjects"),
        })
        print(f"  seed {seed}: icc={est['icc_shannon']:.3f} "
              f"icc_adj={est.get('icc_shannon_ageadj')} "
              f"abx={est['abx'].get('beta_abx')}", flush=True)
    ok = [r for r in results if r["icc_est"] is not None and r["abx_est"] is not None]

    def summ(est_key, true_val):
        vals = [r[est_key] for r in ok if r[est_key] is not None]
        if not vals:
            return None
        m = statistics.fmean(vals)
        sd = statistics.pstdev(vals) if len(vals) > 1 else 0.0
        out = {"n": len(vals), "mean_est": m, "sd_est": sd}
        if true_val is not None:
            tol = max(0.05, abs(true_val) * 0.5)
            out["true"] = true_val
            out["bias"] = m - true_val
            out["rmse"] = math.sqrt(statistics.fmean([(v - true_val) ** 2 for v in vals]))
            out["within_tol"] = sum(1 for v in vals if abs(v - true_val) <= tol) / len(vals)
            out["tol"] = tol
        return out

    report = {
        "n_runs": len(results),
        "n_valid": len(ok),
        "icc_raw": summ("icc_est", truth.get("icc_shannon")),
        "icc_ageadj": summ("icc_adj_est", truth.get("icc_ageadj")),
        "abx": summ("abx_est", truth.get("abx_delta_shannon")),
        "slope": summ("slope_est", None),
        "bray_ratio_mean": (statistics.fmean([r["bray_ratio"] for r in ok
                                              if r["bray_ratio"] is not None])
                            if any(r["bray_ratio"] for r in ok) else None),
        "runs": results,
    }
    with open(os.path.join(args.out, "validation.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, ensure_ascii=False)
    print(json.dumps({k: v for k, v in report.items() if k != "runs"},
                     indent=2, ensure_ascii=False))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("simulate")
    s.add_argument("--meta", required=True)
    s.add_argument("--study", default="VatanenT_2016")
    s.add_argument("--out", required=True)
    s.add_argument("--seed", type=int, default=1)
    s.add_argument("--reads", type=int, default=20000)
    s.add_argument("--max-subjects", type=int, default=None)
    s.add_argument("--abx-beta", type=float, default=-0.35)
    s.add_argument("--sigma-subj", type=float, default=0.55)
    s.set_defaults(func=cmd_simulate)

    a = sub.add_parser("analyze")
    a.add_argument("--dir", required=True)
    a.set_defaults(func=cmd_analyze)

    v = sub.add_parser("validate")
    v.add_argument("--meta", required=True)
    v.add_argument("--study", default="VatanenT_2016")
    v.add_argument("--out", required=True)
    v.add_argument("--n", type=int, default=20)
    v.add_argument("--reads", type=int, default=20000)
    v.add_argument("--max-subjects", type=int, default=None)
    v.add_argument("--abx-beta", type=float, default=-0.35)
    v.add_argument("--sigma-subj", type=float, default=0.55)
    v.set_defaults(func=cmd_validate)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
